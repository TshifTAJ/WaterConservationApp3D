# Water Conservation Challenge — 3D Desktop Build (v1.4, ISI Day final)

An educational 3D desktop game on South African household water-saving
techniques, built with Three.js and packaged as an Electron app. No game
engine is needed — just Node.js. It also runs offline by double-clicking
`index.html` in a browser (saving files then uses the browser instead of
Electron).

Group project by Tshifhiwa Tshitaka and Precious Masetla (NWU). Client: Dr Dumani Kunjuzwa.

## Run it

```
npm install
npm start
```

Requires [Node.js](https://nodejs.org) (LTS). The first `npm install`
downloads Electron (~150–200 MB, once). Three.js is vendored, so the game runs
fully offline afterwards. `npm run build` produces an installer in `dist/`.

## Controls

- **WASD / Arrow keys** — move (relative to the camera)
- **Z / X** (or right-mouse drag) — rotate the camera
- **E** — interact (talk, place/pick up, pour, collect, build, switch, fix)
- **F** — fit a filter trap (Greywater Stage 2)
- **1 / 2 / 3** — choose a material or decision where offered
- **J** — Journal (Facts / Progress / Controls) · **Esc** — pause menu

## What's new in v1.4 (final build)

- **Electron hardening**: renderer `sandbox`, a Content-Security-Policy (only
  `en.wikipedia.org` is allowed for network access), and blocked
  pop-ups/navigation.
- **CSV export of results** (Journal → Progress → "Export my results"). It
  contains the task history and quiz totals under the random anonymous player
  ID — never the player's name. The player chooses where it is saved; nothing
  is uploaded (POPIA-friendly).
- **Online check now probes Wikipedia** (the only source actually used) rather
  than an unrelated registry.
- **Toast fix**: "Certificate saved"/"Results exported" messages no longer
  carry a wrong "Badge earned:" prefix.
- README consolidated (duplicate headers and out-of-date notes removed).

## Game content

| FR | Feature | Where |
|----|---------|-------|
| FR-01 | Rainwater Collection | Water Warden — S1 Collect & Store, S2 First-Flush Diverter, S3 Storm Manager |
| FR-02 | Greywater Reuse | Pipe-Fitter Pete — S1 Pipe Connection (BFS-validated), S2 Source Sorting, S3 Diversion Valve |
| FR-03 | Filtration Build | Filter Fundi — S1 Build & Filter (turbidity vs WHO <5 NTU), S2 Disinfection Bench, S3 Fault Finder |
| FR-04 | NPC dialogue & quests | NPCs gate each stage; next step announced by voice and text |
| FR-05 | Gamification | Points, combo multiplier, penalties for mistakes, badges, particles/audio |
| FR-06 | Inventory | Contextual bottom HUD |
| FR-07 | Quizzes | 3 random questions per stage from a pool of 7–8, shuffled answers |
| FR-08 | Profile & auto-save | JSON profile via Electron main process + localStorage |
| FR-09 | Onboarding | First-launch welcome, pause menu, settings |

Extras: 3 round certificates (PDF), "My Certificates" list, Facts Journal with
optional Wikipedia fact updates, 7-language menus (English & Afrikaans fully
translated in-game), procedural audio, text-to-speech, personal music
playlist, difficulty and text-size settings, minimap and compass, hint system.

Stages are played in order: every NPC must finish its current stage before any
NPC offers the next. Points are paid once per stage; replays are practice.

## Known limitations

- Voice uses offline OS text-to-speech, not recorded actors.
- isiZulu, Sesotho, Setswana, isiXhosa and Tshivenda cover static menus only
  (AI-assisted drafts, not yet reviewed by home-language speakers); in-game
  instructions fall back to English.
- The personal music playlist lasts for the session only.
- Online facts are limited to a fixed list of Wikipedia topics, validated before
  being added; the game is fully functional offline.
- AI-generated quiz questions are not wired up (needs a user-supplied API key);
  `pickQuizSet()` in `js/game.js` is the insertion point.
- Pipe puzzle validates connectivity, not slope physics; turbidity numbers are
  illustrative (the WHO guideline is real).
- Characters are procedural low-poly humanoids, not imported rigged models.

## Project structure

```
main.js        Electron entry: window, save/load, certificate PDF, CSV export
preload.js     Secure bridge (window.api)
index.html     Page shell, HUD and all UI panels (with CSP)
style.css      UI styling
vendor/        three.min.js (offline)
js/i18n.js     Languages: t() menus, tx() dynamic text
js/audio.js    Procedural SFX, ambient pad, playlist, TTS
js/environment.js  Trees, village, villagers, birds
js/effects.js  Particles, reward popups, screen flash
js/game.js     Scene, characters, nine stages, scoring, quizzes, UI, main loop
```

## Extending it

Native-speaker translations; AI-assisted quiz path; glTF rigged characters
(replace `createHumanoid()` / `animateRig()`); goal-directed NPC agents
(`registerNpcInteractable()`, wanderer update in `environment.js`); extend the
combo system to pipe-routing and filtration moments.
