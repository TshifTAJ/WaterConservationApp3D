/* Service worker: makes the game installable (Android "Install app") and fully offline after the first load. */
const CACHE = 'water-challenge-v1.4';
const FILES = ['./', 'index.html', 'style.css', 'manifest.webmanifest', 'vendor/three.min.js',
  'js/i18n.js', 'js/audio.js', 'js/environment.js', 'js/effects.js', 'js/game.js', 'js/touch.js',
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request; const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return; // Wikipedia facts etc. go straight to the network
  e.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => hit || fetch(req).then((res) => {
    const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); return res;
  }).catch(() => caches.match('index.html'))));
});
