# Running the game on Android

## Option 1 — Install from Chrome (PWA, recommended)
1. Put the game folder online over HTTPS (for example drag it onto https://app.netlify.com/drop, or use GitHub Pages).
2. Open the link in Chrome on the phone and wait for it to load once.
3. Chrome menu (⋮) → **Install app** (or **Add to Home screen**). It then opens full-screen like an app and works offline.

## Option 2 — Real APK file (built with GitHub Actions)
1. Upload this folder to a GitHub repository.
2. Open the **Actions** tab → **Build Android APK** → **Run workflow**.
3. When it finishes, download the artifact `water-challenge-apk`, unzip it and copy `app-debug.apk` to the phone.
4. Open the file on the phone and allow "Install unknown apps" for your file manager or browser.
(Local build instead: install Node, JDK 17 and Android Studio, then run `npm i --no-save @capacitor/core @capacitor/cli @capacitor/android`, `node scripts/prepare-www.js`, `npx cap add android`, `npx cap sync android`, and build in `android/`.)

Controls on a phone: left joystick to move, big **E** button to interact, **F** and **1/2/3** buttons where needed, drag the world or use the rotate buttons to turn the camera. Landscape is best.
