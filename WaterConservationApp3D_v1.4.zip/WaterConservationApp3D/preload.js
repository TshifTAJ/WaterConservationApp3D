const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  saveProfile: (data) => ipcRenderer.invoke('save-profile', data),
  loadProfile: () => ipcRenderer.invoke('load-profile'),
  saveCertificate: (text) => ipcRenderer.invoke('save-certificate', text),
  exportCsv: (text, filename) => ipcRenderer.invoke('export-csv', text, filename),
  quitApp: () => ipcRenderer.invoke('quit-app')
});
