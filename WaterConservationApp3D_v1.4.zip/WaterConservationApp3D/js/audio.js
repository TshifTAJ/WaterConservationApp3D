/* =========================================================================
   Audio — procedurally generated sound effects and ambient pad (no external
   audio assets). Spoken instructions use the browser's offline TTS (Web
   Speech API). A PERSONAL PLAYLIST (songs the player adds in Settings) can
   replace the ambient pad; either way, music pauses whenever an instruction
   is spoken and resumes once it has finished.
   ========================================================================= */

const AudioSys = (() => {
  let ctx = null;
  let masterGain = null;
  let musicNodes = null;
  const settings = { volume: 0.6, musicOn: true, voiceOn: true };

  function ensureCtx() {
    if (!ctx) {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      masterGain = ctx.createGain();
      masterGain.gain.value = settings.volume;
      masterGain.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function customVolume() { return Math.max(0, Math.min(1, settings.volume * 0.7)); }

  function setVolume(v) {
    settings.volume = v;
    if (masterGain) masterGain.gain.value = v;
    if (playlist.el) playlist.el.volume = customVolume();
  }

  function noiseBurst(duration, filterFreq, gainPeak) {
    const c = ensureCtx();
    const bufferSize = c.sampleRate * duration;
    const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);

    const src = c.createBufferSource();
    src.buffer = buffer;
    const filter = c.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = filterFreq;
    const gain = c.createGain();
    gain.gain.setValueAtTime(gainPeak, c.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration);

    src.connect(filter).connect(gain).connect(masterGain);
    src.start();
  }

  function tone(freq, duration, type, gainPeak, delay) {
    const c = ensureCtx();
    const osc = c.createOscillator();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    const gain = c.createGain();
    const t0 = c.currentTime + (delay || 0);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(gainPeak, t0 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + duration + 0.05);
  }

  function footstep() { noiseBurst(0.09, 300, 0.22); }
  function splash() { noiseBurst(0.35, 1800, 0.35); }
  function pipePlace() { tone(220, 0.12, 'square', 0.15); }
  function pickup() { tone(660, 0.1, 'triangle', 0.2); tone(880, 0.1, 'triangle', 0.15, 0.08); }
  function corrective() { tone(180, 0.25, 'sawtooth', 0.15); }
  function success() {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.28, 'triangle', 0.22, i * 0.11));
  }
  function fail() { tone(200, 0.4, 'sawtooth', 0.18); tone(140, 0.5, 'sawtooth', 0.15, 0.15); }
  function badge() {
    [784, 988, 1318].forEach((f, i) => tone(f, 0.22, 'sine', 0.2, i * 0.09));
  }
  function tick() { tone(1000, 0.05, 'square', 0.12); }
  function fanfare() {
    [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, 0.32, 'triangle', 0.24, i * 0.1));
    tone(1568, 0.6, 'sine', 0.2, 0.55);
  }

  /* ------------------------------ Music -----------------------------------
     Two sources: the built-in procedural pad, or the player's OWN playlist
     (songs added in Settings for this session). Either way, music PAUSES
     whenever a spoken instruction starts and RESUMES once it has finished. */

  const PAD_LEVEL = 0.05;
  let ambientStarted = false;
  let instructionActive = false;
  let useCustom = false;
  const playlist = { tracks: [], index: 0, el: null, wantPlaying: false, onChange: null };

  function startAmbient() {
    if (ambientStarted) { applyMusicState(); return; }
    ambientStarted = true;
    const c = ensureCtx();
    const gain = c.createGain();
    gain.gain.value = 0;
    gain.connect(masterGain);

    const notes = [130.8, 164.8, 196.0, 246.9];
    const oscs = notes.map((f) => {
      const o = c.createOscillator();
      o.type = 'sine';
      o.frequency.value = f;
      const lfo = c.createOscillator();
      lfo.frequency.value = 0.05 + Math.random() * 0.05;
      const lfoGain = c.createGain();
      lfoGain.gain.value = 3;
      lfo.connect(lfoGain).connect(o.detune);
      lfo.start();
      o.connect(gain);
      o.start();
      return o;
    });
    musicNodes = { gain, oscs };
    applyMusicState();
  }

  function ensurePlaylistEl() {
    if (playlist.el) return playlist.el;
    const el = new Audio();
    el.preload = 'auto';
    el.addEventListener('ended', () => nextTrack(true));
    el.addEventListener('error', () => { if (playlist.tracks.length > 1) nextTrack(true); });
    playlist.el = el;
    return el;
  }

  function loadTrack(i) {
    if (!playlist.tracks.length) return false;
    playlist.index = ((i % playlist.tracks.length) + playlist.tracks.length) % playlist.tracks.length;
    const el = ensurePlaylistEl();
    el.src = playlist.tracks[playlist.index].url;
    el.volume = customVolume();
    return true;
  }

  function nextTrack() {
    if (!playlist.tracks.length) return;
    loadTrack(playlist.index + 1);
    if (playlist.wantPlaying && !instructionActive) playlist.el.play().catch(() => {});
    if (playlist.onChange) playlist.onChange();
  }

  function applyMusicState() {
    const customOn = settings.musicOn && useCustom && playlist.tracks.length > 0;
    const padOn = settings.musicOn && !customOn && !instructionActive;
    if (musicNodes) musicNodes.gain.gain.value = padOn ? PAD_LEVEL : 0;

    if (customOn) {
      playlist.wantPlaying = true;
      const el = ensurePlaylistEl();
      if (!el.src) loadTrack(playlist.index);
      el.volume = customVolume();
      if (instructionActive) el.pause();
      else el.play().catch(() => { /* needs a user gesture first */ });
    } else {
      playlist.wantPlaying = false;
      if (playlist.el) playlist.el.pause();
    }
  }

  function setMusic(on) {
    settings.musicOn = on;
    if (on) startAmbient(); else applyMusicState();
  }

  /** Called by speak(): true = an instruction started (pause music), false = it finished (resume). */
  function musicDuck(active) {
    if (instructionActive === active) return;
    instructionActive = active;
    applyMusicState();
  }

  function setCustomMusic(on) { useCustom = !!on; applyMusicState(); }
  function setPlaylist(tracks) {
    const currentUrl = playlist.tracks[playlist.index] && playlist.tracks[playlist.index].url;
    playlist.tracks = tracks.slice();
    const keep = playlist.tracks.findIndex((t) => t.url === currentUrl);
    playlist.index = keep >= 0 ? keep : 0;
    if (playlist.el) playlist.el.removeAttribute('src');
    applyMusicState();
  }
  function currentTrackName() {
    const t = playlist.tracks[playlist.index];
    return t ? t.name : '';
  }

  /* ------------------------------ Rain loop ------------------------------ */

  let rainNode = null;
  function startRain() {
    if (rainNode) return;
    const c = ensureCtx();
    const bufferSize = c.sampleRate * 2;
    const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * 0.5;

    const src = c.createBufferSource();
    src.buffer = buffer;
    src.loop = true;
    const filter = c.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 3200;
    filter.Q.value = 0.6;
    const gain = c.createGain();
    gain.gain.value = 0.09;

    src.connect(filter).connect(gain).connect(masterGain);
    src.start();
    rainNode = { src, gain };
  }
  function stopRain() {
    if (!rainNode) return;
    try { rainNode.src.stop(); } catch (e) { /* already stopped */ }
    rainNode = null;
  }

  /* --------------------------- Text-to-speech ----------------------------- */
  /* Speaks in the language chosen in Settings. If no matching voice is
     installed, the closest available voice is used, and the UI separately
     tells the player this (see refreshVoiceInfo in game.js). */

  const npcVoiceProfiles = {
    npc1: { pitch: 0.75, rate: 0.95 },
    npc2: { pitch: 1.05, rate: 1.05 },
    npc3: { pitch: 1.2, rate: 0.98 }
  };
  const SPEECH_LANG = { en: 'en-ZA', af: 'af-ZA', zu: 'zu-ZA', st: 'st-ZA', tn: 'tn-ZA', xh: 'xh-ZA', ve: 've-ZA' };
  let speechLang = 'en';
  let speakId = 0;
  let watchdog = null;

  function allVoices() {
    try { return (window.speechSynthesis && window.speechSynthesis.getVoices()) || []; } catch (e) { return []; }
  }
  function pickVoice() {
    const voices = allVoices();
    const want = SPEECH_LANG[speechLang] || 'en-ZA';
    const base = want.split('-')[0].toLowerCase();
    const exact = voices.find((v) => v.lang && v.lang.toLowerCase() === want.toLowerCase());
    if (exact) return { voice: exact, exact: true };
    const sameLang = voices.find((v) => v.lang && v.lang.toLowerCase().startsWith(base));
    if (sameLang) return { voice: sameLang, exact: true };
    const en = voices.find((v) => v.lang && /^en[-_]za/i.test(v.lang)) || voices.find((v) => v.lang && /^en/i.test(v.lang));
    return { voice: en || null, exact: false };
  }
  function voiceInfo() {
    const supported = !!window.speechSynthesis;
    const pv = supported ? pickVoice() : { voice: null, exact: false };
    return { supported, hasVoice: !!pv.voice, exact: pv.exact, voiceName: pv.voice ? pv.voice.name : '' };
  }
  function setSpeechLanguage(code) { if (SPEECH_LANG[code]) speechLang = code; }

  function speak(text, npcKey) {
    if (!settings.voiceOn || !window.speechSynthesis || !text) return;
    try {
      const synth = window.speechSynthesis;
      const id = ++speakId;
      synth.cancel();
      const utter = new SpeechSynthesisUtterance(String(text).replace(/\s+/g, ' '));
      const prof = npcVoiceProfiles[npcKey] || { pitch: 1, rate: 1 };
      utter.pitch = prof.pitch;
      utter.rate = prof.rate;
      utter.volume = Math.max(0.2, settings.volume);
      const pv = pickVoice();
      if (pv.voice) { utter.voice = pv.voice; utter.lang = pv.voice.lang; }
      else utter.lang = SPEECH_LANG[speechLang] || 'en-ZA';

      musicDuck(true);
      clearTimeout(watchdog);
      const finish = () => { if (id === speakId) { clearTimeout(watchdog); musicDuck(false); } };
      utter.onend = finish;
      utter.onerror = finish;
      watchdog = setTimeout(finish, Math.min(45000, 2500 + (String(text).length * 90) / prof.rate));
      synth.speak(utter);
    } catch (e) { musicDuck(false); }
  }

  function setVoiceEnabled(on) {
    settings.voiceOn = on;
    if (!on) {
      speakId++;
      clearTimeout(watchdog);
      if (window.speechSynthesis) { try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } }
      musicDuck(false);
    }
  }

  return {
    unlock: ensureCtx, setVolume, footstep, splash, pipePlace, pickup,
    corrective, success, fail, badge, tick, fanfare,
    startAmbient, setMusic, speak, setVoiceEnabled, setSpeechLanguage, voiceInfo,
    setCustomMusic, setPlaylist, nextTrack, currentTrackName,
    onPlaylistChange(cb) { playlist.onChange = cb; },
    startRain, stopRain,
    get settings() { return settings; }
  };
})();
