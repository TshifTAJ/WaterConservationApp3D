/* =========================================================================
   Touch controls for phones / tablets (v1.4).
   Adds an on-screen joystick (WASD), E / F / 1-2-3 buttons, camera-rotate
   buttons and drag-to-rotate on the world. It reuses the game's own input
   state (keys, interactJustPressed, ...) so no game logic is duplicated.
   Only active when IS_TOUCH is true (see js/game.js).
   ========================================================================= */
(function () {
  if (typeof IS_TOUCH === 'undefined' || !IS_TOUCH) return;
  document.body.classList.add('touch');

  const root = document.createElement('div');
  root.id = 'touch-ui';
  root.innerHTML =
    '<div class="joy" id="joy"><div class="knob" id="joy-knob"></div></div>' +
    '<button class="tbtn" id="tb-e" aria-label="Interact (E)">E</button>' +
    '<button class="tbtn" id="tb-f" aria-label="Fit filter trap (F)">F</button>' +
    '<button class="tbtn tsel" id="tb-1" aria-label="Choose 1">1</button>' +
    '<button class="tbtn tsel" id="tb-2" aria-label="Choose 2">2</button>' +
    '<button class="tbtn tsel" id="tb-3" aria-label="Choose 3">3</button>' +
    '<button class="tbtn trot" id="tb-rl" aria-label="Rotate camera left">⟲</button>' +
    '<button class="tbtn trot" id="tb-rr" aria-label="Rotate camera right">⟳</button>';
  document.getElementById('ui-root').appendChild(root);

  const $ = (id) => document.getElementById(id);

  /* --- Virtual joystick -> WASD keys --- */
  const joy = $('joy'), knob = $('joy-knob');
  let joyId = null;
  function setDir(nx, ny) {
    const t = 0.35;
    keys['a'] = nx < -t; keys['d'] = nx > t;
    keys['w'] = ny < -t; keys['s'] = ny > t;
  }
  function joyMove(e) {
    const r = joy.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2, max = r.width / 2;
    let dx = e.clientX - cx, dy = e.clientY - cy;
    const len = Math.hypot(dx, dy) || 1;
    if (len > max) { dx = dx / len * max; dy = dy / len * max; }
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    setDir(dx / max, dy / max);
  }
  function joyEnd() {
    joyId = null; knob.style.transform = ''; setDir(0, 0);
  }
  joy.addEventListener('pointerdown', (e) => { joyId = e.pointerId; joy.setPointerCapture(e.pointerId); joyMove(e); e.preventDefault(); });
  joy.addEventListener('pointermove', (e) => { if (e.pointerId === joyId) joyMove(e); });
  joy.addEventListener('pointerup', (e) => { if (e.pointerId === joyId) joyEnd(); });
  joy.addEventListener('pointercancel', joyEnd);

  /* --- Action buttons --- */
  function tap(id, fn) {
    const b = $(id);
    b.addEventListener('pointerdown', (e) => { b.classList.add('down'); fn(true); e.preventDefault(); });
    const up = () => { b.classList.remove('down'); fn(false); };
    b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('pointerleave', up);
  }
  tap('tb-e', (down) => { if (down) interactJustPressed = true; });
  tap('tb-f', (down) => { if (down) trapKeyJustPressed = true; });
  tap('tb-1', (down) => { if (down) selectKeyJustPressed = '1'; });
  tap('tb-2', (down) => { if (down) selectKeyJustPressed = '2'; });
  tap('tb-3', (down) => { if (down) selectKeyJustPressed = '3'; });
  tap('tb-rl', (down) => { keys['z'] = down; });
  tap('tb-rr', (down) => { keys['x'] = down; });

  /* --- Drag on the world to rotate the camera --- */
  let dragId = null, lastX = 0;
  canvas.addEventListener('pointerdown', (e) => { if (e.pointerType === 'mouse') return; dragId = e.pointerId; lastX = e.clientX; });
  canvas.addEventListener('pointermove', (e) => {
    if (e.pointerId !== dragId || !gameStarted || isUiBlocking()) return;
    camYaw -= (e.clientX - lastX) * 0.008; lastX = e.clientX;
  });
  const endDrag = (e) => { if (e.pointerId === dragId) dragId = null; };
  canvas.addEventListener('pointerup', endDrag); canvas.addEventListener('pointercancel', endDrag);

  /* Hide the touch controls while a full-screen panel is open, so they never cover buttons */
  function syncVisibility() { root.style.display = (gameStarted && !isUiBlocking()) ? '' : 'none'; }
  root.style.display = 'none';
  setInterval(syncVisibility, 200);

  /* Block page scroll / pinch gestures */
  document.addEventListener('touchmove', (e) => { if (e.target === canvas || root.contains(e.target)) e.preventDefault(); }, { passive: false });
})();
