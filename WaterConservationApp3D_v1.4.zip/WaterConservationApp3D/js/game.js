/* =========================================================================
   Water Conservation Challenge — 3D desktop build (Three.js, no engine)
   v1.4: Electron hardening (sandbox + CSP), Wikipedia-based connectivity probe,
   anonymous CSV export of results. v1.3: bottom-anchored HUD, point penalties, voice next-step guidance in
   the selected language, personal music playlist with speech ducking,
   randomised per-stage quizzes, nine distinct stage tasks, and online fact
   updates. Characters are stylised low-poly blocky humanoids.
   ========================================================================= */

/* ---------------------------- Renderer / Scene --------------------------- */

const canvas = document.getElementById('game');
/* Touch devices (phones/tablets): on-screen controls (js/touch.js), lighter rendering. Add ?touch=1 to force. */
const IS_TOUCH = (typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0 && window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || /[?&]touch=1/.test(location.search);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !IS_TOUCH, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, IS_TOUCH ? 1.5 : 2));

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8fd0ea);
scene.fog = new THREE.Fog(0x8fd0ea, 60, 170);

const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 500);

FX.init(scene, camera, 'fx-root');

/* Settings — persisted in profile.settings, applied live */
const settings = {
  speed: 11,
  cameraAngle: 78,
  volume: 60,
  music: true,
  voice: true,
  graphics: 'standard',
  language: 'en',
  difficulty: 'standard',
  textSize: 'medium',
  customMusic: false
};

function difficultyMultiplier() {
  if (settings.difficulty === 'relaxed') return { time: 1.5, target: 0.8, budget: 1.5 };
  if (settings.difficulty === 'challenge') return { time: 0.8, target: 1.15, budget: 0.75 };
  return { time: 1, target: 1, budget: 1 };
}

function computeCamOffset() {
  const t = settings.cameraAngle / 100;
  const height = 10 + t * 20;
  const back = 11 - t * 8;
  return new THREE.Vector3(0, height, back);
}
let camOffset = computeCamOffset();

/* Camera yaw — rotated with Z / X or right-mouse drag; movement is relative to it. */
let camYaw = 0;
function camBasis() {
  return {
    f: { x: -Math.sin(camYaw), z: -Math.cos(camYaw) },
    r: { x: Math.cos(camYaw), z: -Math.sin(camYaw) }
  };
}

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 200));
resize();

const ambient = new THREE.AmbientLight(0xffffff, 0.65);
scene.add(ambient);
const sun = new THREE.DirectionalLight(0xffffff, 0.9);
sun.position.set(40, 60, 20);
scene.add(sun);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(240, 240),
  new THREE.MeshStandardMaterial({ color: 0x5fa25a })
);
ground.rotation.x = -Math.PI / 2;
scene.add(ground);

function zoneTint(x, z, radius, color) {
  const disc = new THREE.Mesh(
    new THREE.CircleGeometry(radius, 32),
    new THREE.MeshStandardMaterial({ color })
  );
  disc.rotation.x = -Math.PI / 2;
  disc.position.set(x, 0.02, z);
  scene.add(disc);
}

const ZONE1 = { x: 0, z: -50 };
const ZONE2 = { x: -55, z: 30 };
const ZONE3 = { x: 55, z: 30 };

zoneTint(ZONE1.x, ZONE1.z, 22, 0x74c2d6);
zoneTint(ZONE2.x, ZONE2.z, 22, 0x9c8258);
zoneTint(ZONE3.x, ZONE3.z, 22, 0xa88bc9);

const keepClearAreas = [
  { x: 0, z: 0, radius: 12 },
  { x: ZONE1.x, z: ZONE1.z, radius: 24 },
  { x: ZONE2.x, z: ZONE2.z, radius: 24 },
  { x: ZONE3.x, z: ZONE3.z, radius: 24 },
  { x: 0, z: -25, radius: 6 }, { x: -27, z: 15, radius: 6 }, { x: 27, z: 15, radius: 6 }
];

const environmentData = buildEnvironment(scene, keepClearAreas);
let villagers = [];
const interactables = []; // { x, z, radius, getPrompt(), interact() }

function makeLabel(text) {
  const cnv = document.createElement('canvas');
  cnv.width = 512; cnv.height = 128;
  const ctx = cnv.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(0, 0, cnv.width, cnv.height);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 48px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, cnv.width / 2, cnv.height / 2);
  const tex = new THREE.CanvasTexture(cnv);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(6.4, 1.6, 1);
  return sprite;
}

/** A sprite label whose text can be updated later (e.g. a live gauge). */
function makeDynamicLabel(text) {
  const cnv = document.createElement('canvas');
  cnv.width = 512; cnv.height = 128;
  const ctx = cnv.getContext('2d');
  const tex = new THREE.CanvasTexture(cnv);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(6.4, 1.6, 1);
  let last = null;
  sprite.userData.setText = (str) => {
    if (str === last) return;
    last = str;
    ctx.clearRect(0, 0, cnv.width, cnv.height);
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(0, 0, cnv.width, cnv.height);
    ctx.fillStyle = '#ffffff';
    let fs = 46;
    ctx.font = `bold ${fs}px sans-serif`;
    while (fs > 22 && ctx.measureText(str).width > cnv.width - 24) { fs -= 2; ctx.font = `bold ${fs}px sans-serif`; }
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(str, cnv.width / 2, cnv.height / 2);
    tex.needsUpdate = true;
  };
  sprite.userData.setText(text);
  return sprite;
}

/* ------------------------------ Humanoid rig ------------------------------ */

const SKIN = 0xe8b98a;

function makeToonGradient() {
  const c2 = document.createElement('canvas');
  c2.width = 4; c2.height = 1;
  const ctx = c2.getContext('2d');
  [70, 140, 200, 255].forEach((v, i) => {
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    ctx.fillRect(i, 0, 1, 1);
  });
  const tex = new THREE.CanvasTexture(c2);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  return tex;
}
const toonGradient = makeToonGradient();
function toonMat(color) {
  return new THREE.MeshToonMaterial({ color, gradientMap: toonGradient });
}

function cartoonifyScene(root) {
  root.traverse((obj) => {
    if (obj.isMesh && obj.material && obj.material.isMeshStandardMaterial) {
      const old = obj.material;
      const next = new THREE.MeshToonMaterial({
        color: old.color, gradientMap: toonGradient,
        transparent: old.transparent, opacity: old.opacity, side: old.side
      });
      if (old.emissive) { next.emissive = old.emissive; next.emissiveIntensity = old.emissiveIntensity; }
      obj.material = next;
    }
  });
}

function makeLimb(mat, radius, length, pivotY, meshOffsetY) {
  const pivot = new THREE.Group();
  pivot.position.y = pivotY;
  const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 4, 8), mat);
  mesh.position.y = meshOffsetY;
  pivot.add(mesh);
  return { pivot, mesh };
}

function createHumanoid(bodyColor, options) {
  const opts = options || {};
  const group = new THREE.Group();
  const matBody = toonMat(bodyColor);
  const matSkin = toonMat(SKIN);

  const leftLeg = makeLimb(matBody, 0.16, 0.34, 0.68, -0.33);
  const rightLeg = makeLimb(matBody, 0.16, 0.34, 0.68, -0.33);
  leftLeg.pivot.position.x = -0.16;
  rightLeg.pivot.position.x = 0.16;

  const leftArm = makeLimb(matSkin, 0.13, 0.30, 1.38, -0.28);
  const rightArm = makeLimb(matSkin, 0.13, 0.30, 1.38, -0.28);
  leftArm.pivot.position.x = -0.44;
  rightArm.pivot.position.x = 0.44;

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.30, 0.22, 4, 10), matBody);
  torso.position.y = 1.09;

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.40, 16, 14), matSkin);
  head.position.y = 1.85;

  const eyeGeo = new THREE.SphereGeometry(0.045, 8, 8);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1a1a1a });
  const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
  leftEye.position.set(-0.15, 1.90, 0.35);
  const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
  rightEye.position.set(0.15, 1.90, 0.35);

  group.add(leftLeg.pivot, rightLeg.pivot, leftArm.pivot, rightArm.pivot, torso, head, leftEye, rightEye);

  if (opts.hat === 'cap') {
    const hat = new THREE.Mesh(new THREE.ConeGeometry(0.36, 0.32, 10), toonMat(opts.hatColor || 0x2255aa));
    hat.position.y = 2.24;
    group.add(hat);
  } else if (opts.hat === 'wide') {
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.52, 0.05, 16), toonMat(opts.hatColor || 0x7a5a30));
    brim.position.y = 2.14;
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 0.24, 12), toonMat(opts.hatColor || 0x7a5a30));
    crown.position.y = 2.28;
    group.add(brim, crown);
  } else if (opts.hat === 'band') {
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.045, 8, 16), toonMat(opts.hatColor || 0xe8a83a));
    band.rotation.x = Math.PI / 2;
    band.position.y = 1.09;
    group.add(band);
  }

  return { group, leftLeg, rightLeg, leftArm, rightArm, torso, head, gestureTimer: 0 };
}

function animateRig(rig, time, moving, dt) {
  if (rig.gestureTimer > 0) {
    rig.gestureTimer -= dt;
    rig.rightArm.pivot.rotation.x = -2.0;
    rig.leftArm.pivot.rotation.x = -0.2;
    rig.leftLeg.pivot.rotation.x = 0;
    rig.rightLeg.pivot.rotation.x = 0;
    return;
  }
  if (moving) {
    const s = Math.sin(time * 8);
    rig.leftLeg.pivot.rotation.x = s * 0.6;
    rig.rightLeg.pivot.rotation.x = -s * 0.6;
    rig.leftArm.pivot.rotation.x = -s * 0.5;
    rig.rightArm.pivot.rotation.x = s * 0.5;
  } else {
    rig.leftLeg.pivot.rotation.x = 0;
    rig.rightLeg.pivot.rotation.x = 0;
    rig.leftArm.pivot.rotation.x = Math.sin(time * 2) * 0.05;
    rig.rightArm.pivot.rotation.x = -Math.sin(time * 2) * 0.05;
    rig.torso.position.y = 1.09 + Math.sin(time * 2) * 0.01;
    rig.head.rotation.y = Math.sin(time * 0.6) * 0.12;
  }
}

function gesture(rig) { rig.gestureTimer = 0.4; }

villagers = createVillagerWanderers(scene, createHumanoid, [
  { x: -20, z: 10 }, { x: -22, z: 6 }, { x: -16, z: 18 },
  { x: 20, z: -6 }, { x: 22, z: -2 }, { x: 17, z: -16 }
]);

const birds = createBirds(scene, 7);

function makeSignpost(scene, x, z, factText) {
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.4, 8), new THREE.MeshStandardMaterial({ color: 0x5a3c22 }));
  post.position.set(x, 0.7, z);
  scene.add(post);
  const board = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.6, 0.08), new THREE.MeshStandardMaterial({ color: 0xe8dcc0 }));
  board.position.set(x, 1.5, z);
  scene.add(board);
  interactables.push({
    x, z, radius: 2.4,
    getPrompt() { return 'Press E to read the signpost'; },
    interact() { showDialogue(`📋 ${tx(factText)}`, 8); unlockFact(factText); }
  });
}

makeSignpost(scene, -12, -2,
  'Did you know? WRC South Africa estimates greywater reuse can save around 50L per household per day — the same amount you route to the garden in the Pipe-Fitter Pete challenge.');
makeSignpost(scene, 12, -30,
  'Did you know? Roughly 73.6% of rural South African households already practise some form of rainwater harvesting (Springer Nature, 2024) — the same technique behind the Water Warden challenge.');

/* ------------------------------- UI helpers -------------------------------- */

const el = (id) => document.getElementById(id);
const promptEl = el('hud-prompt');
const dialogueEl = el('hud-dialogue');
const pointsEl = el('hud-points');
const timerEl = el('hud-timer');
const inventoryEl = el('hud-inventory');
const badgeToastEl = el('badge-toast');
const certificateBtnEl = el('certificate-btn');
const feedbackEl = el('hud-feedback');

function escHtml(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fmtTime(sec) {
  sec = Math.max(0, Math.round(sec));
  return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0');
}

let dialogueTimer = 0;
function setPrompt(text) { promptEl.textContent = tx(text) || ''; }
function greet() { return profile.playerName ? profile.playerName + ', ' : ''; }
function showDialogue(text, seconds, npcKey) {
  text = tx(text);
  dialogueEl.textContent = text;
  dialogueTimer = seconds;
  if (npcKey) AudioSys.speak(text, npcKey);
}
function setInventory(html) {
  if (html) { inventoryEl.innerHTML = html; inventoryEl.classList.remove('hidden'); }
  else { inventoryEl.classList.add('hidden'); }
}

const objectiveEl = el('hud-objective');
function setObjective(html) {
  objectiveEl.innerHTML = `<b>${escHtml(tx('OBJECTIVE:'))}</b> ${tx(html)}`;
  objectiveEl.classList.remove('hidden');
}
function clearObjective() { objectiveEl.classList.add('hidden'); }

/* Immediate feedback card: what happened / what to do instead / why it matters. */
let feedbackTimer = 0;
function showFeedback(kind, headline, lines, seconds) {
  feedbackEl.className = 'hud-feedback ' + kind;
  const head = String(headline).startsWith('✔') ? headline : tx(headline);
  feedbackEl.innerHTML = `<div class="fb-head">${escHtml(head)}</div>` +
    (lines || []).map((l) => `<div class="fb-line"><span class="fb-tag">${escHtml(tx(l.tag))}</span>${escHtml(l.text)}</div>`).join('');
  feedbackTimer = seconds || 7;
  feedbackEl.classList.remove('hidden');
}
function hideFeedback() { feedbackEl.classList.add('hidden'); feedbackTimer = 0; }

/** An incorrect action: feedback, a point penalty, and a reason. */
function wrongAction(npcKey, what, correct, why, penaltyAmt) {
  registerMistake();
  AudioSys.corrective();
  FX.flash('rgba(200,50,50,0.16)', 300);
  const lost = penaltyAmt ? penalize(penaltyAmt) : 0;
  const lines = [
    { tag: '✖ ' + tx('What happened:') + ' ', text: tx(what) },
    { tag: '✔ ' + tx('Do this instead:') + ' ', text: tx(correct) },
    { tag: '💧 ' + tx('Why it matters:') + ' ', text: why }
  ];
  if (lost > 0) lines.push({ tag: '⚠ ' + tx('Penalty:') + ' ', text: tx('−{n} points', { n: lost }) });
  showFeedback('bad', tx('Not quite!'), lines, 9);
  if (npcKey) AudioSys.speak(`${tx(what)} ${tx(correct)}`, npcKey);
}
function goodAction(headline, why, seconds) {
  showFeedback('good', '✔ ' + tx(headline), why ? [{ tag: '💧 ' + tx('Why it matters:') + ' ', text: why }] : [], seconds || 5);
}

/* --------------------------------- Hints ------------------------------------ */

let hintTimer = 0;
let hintsGivenThisAttempt = 0;

function updateHintSystem(dt) {
  const anyActive = ch1.state === 'active' || ch2.state === 'active' || ch3.state === 'active';
  if (!anyActive) { hintTimer = 0; hintsGivenThisAttempt = 0; return; }
  hintTimer += dt;
  if (hintTimer > 22 && hintsGivenThisAttempt < 2) {
    hintsGivenThisAttempt++;
    hintTimer = 0;
    showContextualHint();
  }
}

function showContextualHint() {
  let hint = '';
  if (ch1.state === 'active') hint = ch1.hint ? ch1.hint() : '';
  else if (ch2.state === 'active') hint = ch2.hint ? ch2.hint() : '';
  else if (ch3.state === 'active') hint = ch3.hint ? ch3.hint() : '';
  if (hint) showDialogue(hint, 5);
}

/* ------------------------------ Online status ------------------------------ */

const statusEl = el('hud-status');
let isOnline = false;
let wasOnline = false;

function refreshOnlineIndicator() {
  statusEl.textContent = '● ' + t(isOnline ? 'onlineLabel' : 'offlineLabel');
  statusEl.style.color = isOnline ? '#6fe86f' : '#c9c9c9';
}

async function probeConnectivity() {
  if (!navigator.onLine) { isOnline = false; refreshOnlineIndicator(); wasOnline = false; return; }
  try {
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 3000);
    await fetch('https://en.wikipedia.org/api/rest_v1/', { method: 'HEAD', mode: 'no-cors', signal: ctrl.signal });
    clearTimeout(timeout);
    isOnline = true;
  } catch (e) {
    isOnline = false;
  }
  refreshOnlineIndicator();
  if (isOnline && !wasOnline) maybeAutoUpdateFacts(false);
  wasOnline = isOnline;
}
setInterval(probeConnectivity, 15000);
probeConnectivity();

/* -------------------------------- Minimap ---------------------------------- */

const minimapCanvas = el('minimap');
const mmCtx = minimapCanvas.getContext('2d');
const compassHintEl = el('compass-hint');
const MM_SCALE = 150 / 220;

function worldToMinimap(x, z) {
  const b = camBasis();
  const u = x * b.r.x + z * b.r.z;
  const v = x * b.f.x + z * b.f.z;
  return { mx: 75 + u * MM_SCALE, my: 75 - v * MM_SCALE };
}

function drawMinimap() {
  mmCtx.clearRect(0, 0, 150, 150);
  mmCtx.fillStyle = 'rgba(50,90,50,0.9)';
  mmCtx.fillRect(0, 0, 150, 150);

  const zonesInfo = [
    { z: ZONE1, color: '#74c2d6', done: () => profile.challengesCompleted[0] },
    { z: ZONE2, color: '#c9a978', done: () => profile.challengesCompleted[1] },
    { z: ZONE3, color: '#c9a2e8', done: () => profile.challengesCompleted[2] }
  ];
  zonesInfo.forEach((zi) => {
    const p = worldToMinimap(zi.z.x, zi.z.z);
    mmCtx.beginPath();
    mmCtx.arc(p.mx, p.my, 6, 0, Math.PI * 2);
    mmCtx.fillStyle = zi.done() ? '#ffd43b' : zi.color;
    mmCtx.fill();
  });

  const wp = currentWaypoint();
  if (wp) {
    const w = worldToMinimap(wp.x, wp.z);
    mmCtx.beginPath();
    mmCtx.arc(w.mx, w.my, 6, 0, Math.PI * 2);
    mmCtx.strokeStyle = '#ffe066';
    mmCtx.lineWidth = 2;
    mmCtx.stroke();
  }

  const pp = worldToMinimap(player.x, player.z);
  mmCtx.beginPath();
  mmCtx.arc(pp.mx, pp.my, 4, 0, Math.PI * 2);
  mmCtx.fillStyle = '#2559d9';
  mmCtx.fill();
  mmCtx.strokeStyle = '#fff';
  mmCtx.lineWidth = 1;
  mmCtx.stroke();
}

function currentWaypoint() {
  if (ch1.state === 'active' && ch1.waypoint) return ch1.waypoint();
  if (ch2.state === 'active' && ch2.waypoint) return ch2.waypoint();
  if (ch3.state === 'active' && ch3.waypoint) return ch3.waypoint();
  const order = [[npc1, 0], [npc2, 1], [npc3, 2]];
  for (const [n, idx] of order) {
    if (!profile.challengesCompleted[idx]) return { x: n.x, z: n.z, label: CHALLENGE_NPC[idx] };
  }
  return null;
}

function updateCompassHint() {
  const wp = currentWaypoint();
  if (!wp) { compassHintEl.textContent = tx('All challenges complete!'); return; }
  const b = camBasis();
  const dx = wp.x - player.x, dz = wp.z - player.z;
  const u = dx * b.r.x + dz * b.r.z, v = dx * b.f.x + dz * b.f.z;
  const angle = Math.atan2(u, v);
  const dirs = ['↑', '↗', '→', '↘', '↓', '↙', '←', '↖'];
  const idx = Math.round(((angle % (Math.PI * 2)) + Math.PI * 2) / (Math.PI * 2 / 8)) % 8;
  compassHintEl.textContent = `${dirs[idx]} ${tx(wp.label)} (${Math.round(Math.hypot(dx, dz))}m)`;
}

let badgeToastTimer = 0;
function showToast(msg) {
  badgeToastEl.textContent = tx(msg);
  badgeToastEl.classList.remove('hidden');
  badgeToastTimer = 3.5;
}
function showBadgeToast(label) {
  badgeToastEl.textContent = `🏅 ${tx('Badge earned')}: ${label}`;
  badgeToastEl.classList.remove('hidden');
  badgeToastTimer = 3.5;
}

const urgencyVignetteEl = el('urgency-vignette');
let urgencyActive = false;
function setUrgencyVignette(on) {
  if (on === urgencyActive) return;
  urgencyActive = on;
  urgencyVignetteEl.classList.toggle('active', on);
}

/* ----------------------------- Player profile ------------------------------ */

function genId() { return 'p-' + Math.random().toString(36).slice(2, 10); }

let profile = {
  playerId: null,
  playerName: '',
  totalPoints: 0,
  challengesCompleted: [false, false, false],
  badges: [],
  quizScores: { ch1: null, ch2: null, ch3: null },
  retries: { ch1: 0, ch2: 0, ch3: 0 },
  journalFacts: [],
  quizStats: { totalAnswered: 0, totalCorrect: 0 },
  quizSeen: [],
  stagesCompleted: { ch1: 0, ch2: 0, ch3: 0 },
  awarded: {},
  history: [],
  onlineFacts: [],
  factCursor: 0,
  factsUpdatedAt: null,
  totalImpactLitres: 0,
  totalPlaySeconds: 0,
  finalEvaluationSeen: false,
  roundCertSeen: { 1: false, 2: false },
  pendingCerts: [],
  lastSaved: null,
  settings: null
};

const PROFILE_KEY = 'water-conservation-challenge-profile-v2';
let resettingProgress = false;

async function loadProfile() {
  let loaded = null;
  try { loaded = await window.api.loadProfile(); } catch (e) { /* fresh profile */ }
  if (!loaded) {
    try { const raw = localStorage.getItem(PROFILE_KEY); if (raw) loaded = JSON.parse(raw); } catch (e) { /* ignore */ }
  }
  if (loaded) profile = Object.assign(profile, loaded);
  profile.awarded = profile.awarded || {};
  profile.history = profile.history || [];
  profile.quizSeen = profile.quizSeen || [];
  profile.roundCertSeen = Object.assign({ 1: false, 2: false }, profile.roundCertSeen || {});
  profile.pendingCerts = profile.pendingCerts || [];
  profile.onlineFacts = profile.onlineFacts || [];
  const isNew = !profile.playerId;
  if (isNew) profile.playerId = genId();
  return isNew;
}

async function saveProfile() {
  if (resettingProgress) return;
  profile.lastSaved = new Date().toISOString();
  profile.settings = settings;
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(profile)); } catch (e) { /* storage unavailable */ }
  if (window.api && window.api.saveProfile) { try { await window.api.saveProfile(profile); } catch (e) { console.error('Save failed', e); } }
}
function saveProfileSync() {
  if (resettingProgress) return;
  profile.settings = settings;
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(profile)); } catch (e) { /* ignore */ }
}

function refreshPointsHud() {
  pointsEl.textContent = `${t('hudPoints')}: ${profile.totalPoints} | ${t('hudBadges')}: ${profile.badges.length}`;
}

function unlockFact(text) {
  if (!profile.journalFacts.includes(text)) {
    profile.journalFacts.push(text);
    saveProfile();
  }
}

const CHALLENGE_NAMES = ['first_drop', 'pipe_master', 'filter_fundi'];
const CHALLENGE_LABELS = ['First Drop', 'Pipe Master', 'Filter Fundi'];
const CHALLENGE_NPC = ['Water Warden', 'Pipe-Fitter Pete', 'Filter Fundi'];
const CHALLENGE_FULLNAME = ['Rainwater Harvesting', 'Greywater Reuse', 'Filtration System'];
const STAGE_TITLES = [
  ['Collect & Store', 'First-Flush Diverter', 'Storm Manager'],
  ['Pipe Connection', 'Source Sorting', 'Diversion Valve'],
  ['Build & Filter', 'Disinfection Bench', 'Fault Finder']
];

function chObj(idx) { return [ch1, ch2, ch3][idx]; }
function chKey(idx) { return 'ch' + (idx + 1); }
function stageKey(idx, stage) { return `ch${idx + 1}_s${stage}`; }

/**
 * Called when a stage is completed. Records the highest stage reached, advances
 * the challenge's own stage counter, and queues a certificate once a full round
 * (Stage N of all three challenges) is complete — Round 1 and Round 2 get a
 * Certificate of Participation; Round 3 (all nine stages) gets the Final
 * Combined Certificate via the existing Final Evaluation flow. Certificates are
 * queued, not shown immediately, so they appear only after the current
 * end-of-stage flow (badge / results / quiz) has fully closed.
 */
function advanceStage(key) {
  const c = key === 'ch1' ? ch1 : key === 'ch2' ? ch2 : ch3;
  profile.stagesCompleted[key] = Math.max(profile.stagesCompleted[key], c.stage);
  if (c.stage < 3) c.stage++;
  const minRound = Math.min(profile.stagesCompleted.ch1, profile.stagesCompleted.ch2, profile.stagesCompleted.ch3);
  [1, 2].forEach((round) => {
    if (minRound >= round && !profile.roundCertSeen[round]) { profile.roundCertSeen[round] = true; profile.pendingCerts.push(round); }
  });
  if (minRound >= 3 && !profile.finalEvaluationSeen) profile.pendingCerts.push('final');
  saveProfile();
}

/** Shows (but doesn't yet dismiss) whatever certificate is next in the persisted queue, if any. */
function showNextPendingCert() {
  if (!profile.pendingCerts || !profile.pendingCerts.length) return;
  const next = profile.pendingCerts[0];
  if (next === 'final') triggerFinalEvaluation(); else showRoundCertificate(next);
}
/** Removes the given certificate from the persisted queue once its popup has actually been dismissed. */
function dismissPendingCert(which) {
  if (!profile.pendingCerts) return;
  const i = profile.pendingCerts.indexOf(which);
  if (i >= 0) { profile.pendingCerts.splice(i, 1); saveProfile(); }
}

/* ------------------------- Run tracker (time / attempts) ------------------- */

const run = { active: false, idx: 0, stage: 1, elapsed: 0, mistakes: 0, points: 0, penalties: 0, practice: false, attempt: 1 };

function runStart(idx, stage) {
  const id = stageKey(idx, stage);
  profile.awarded['_attempts_' + id] = (profile.awarded['_attempts_' + id] || 0) + 1;
  Object.assign(run, {
    active: true, idx, stage, elapsed: 0, mistakes: 0, points: 0, penalties: 0,
    practice: profile.stagesCompleted[chKey(idx)] >= stage, attempt: profile.awarded['_attempts_' + id]
  });
  combo.count = 0; combo.timer = 0;
  saveProfile();
}
function runStop() { run.active = false; }
function registerMistake() { if (run.active) run.mistakes++; combo.count = 0; combo.timer = 0; }

function recordHistory(status) {
  const entry = {
    name: `${CHALLENGE_FULLNAME[run.idx]} — Stage ${run.stage}: ${STAGE_TITLES[run.idx][run.stage - 1]}`,
    status, timeSec: Math.round(run.elapsed), attempt: run.attempt, mistakes: run.mistakes,
    points: run.points, penalties: run.penalties, practice: run.practice, at: new Date().toISOString()
  };
  profile.history.unshift(entry);
  if (profile.history.length > 60) profile.history.length = 60;
  saveProfile();
}

function metricStats(extra) {
  const out = [
    { label: 'Time', value: fmtTime(run.elapsed) + ' (' + Math.round(run.elapsed) + 's)' },
    { label: 'Attempts', value: String(run.attempt) },
    { label: 'Mistakes', value: String(run.mistakes) },
    { label: 'Points earned', value: run.practice ? tx('Practice — 0') : (run.points >= 0 ? '+' : '−') + Math.abs(run.points) }
  ];
  if (run.penalties > 0) out.push({ label: 'Penalties', value: '−' + run.penalties });
  return out.concat(extra || []);
}

/* ---------------------------- Score manager --------------------------------
   Every point gain/loss goes through here. Practice replays (a stage already
   completed) never pay or penalise. */

const POINTS = {
  perLitre: 1, stageComplete: 100, quizCorrect: 20,
  overflowValve: 25, filterTrap: 15, layer: 10, riverWater: 10, rake: 15, disinfect: 20,
  cleanFlush: 15, bedWatered: 20, valveOpened: 25,
  sourceSorted: 10, loadRouted: 15, treatment: 20, fixed: 15,
  // penalties
  overflowPerLitre: 2, dirtyPickup: 10, dirtyLitre: 3, flood: 15, overwater: 3,
  wrongDestination: 25, wrongSource: 8, wrongLoad: 8, contaminatedLoad: 20,
  wrongLayer: 10, wrongStation: 8, timeUp: 10
};

function addPoints(amount) {
  if (amount <= 0 || run.practice) return 0;
  profile.totalPoints += amount;
  run.points += amount;
  refreshPointsHud();
  return amount;
}

/** Deducts points for a mistake; the total never drops below 0; practice is never penalised. */
function penalize(amount) {
  if (run.practice || !amount || amount <= 0) return 0;
  const lost = Math.min(amount, profile.totalPoints);
  if (lost <= 0) return 0;
  profile.totalPoints -= lost;
  run.points -= lost;
  run.penalties += lost;
  refreshPointsHud();
  return lost;
}

const COMBO_WINDOW = 6;
const combo = { count: 0, timer: 0, best: 0 };
function comboMultiplier() { return 1 + Math.min(2, Math.floor(combo.count / 3) * 0.5); }
function updateCombo(dt) {
  if (combo.timer > 0) { combo.timer -= dt; if (combo.timer <= 0) combo.count = 0; }
}
function registerGoodAction(worldPos, basePoints, burstKind, label) {
  combo.timer = COMBO_WINDOW;
  combo.count++;
  combo.best = Math.max(combo.best, combo.count);
  const mult = comboMultiplier();
  const bonus = Math.round(basePoints * mult);
  addPoints(bonus);
  const pos = new THREE.Vector3(worldPos.x, (worldPos.y || 0) + 1.7, worldPos.z);
  if (burstKind === 'sparkle') FX.sparkle(pos); else FX.splash(pos);
  if (combo.count >= 3 && combo.count % 3 === 0) {
    FX.popupText(pos, `+${bonus} \u00d7${mult.toFixed(1)} combo!`, { color: '#ffe066', fontSize: 21, life: 1.2 });
    AudioSys.badge();
  } else {
    FX.popupText(pos, `+${bonus}`, { color: '#7fe0ff' });
  }
  return bonus;
}
/** One-time sub-task reward: never pays twice for the same stage, never in practice. */
function awardSubtask(id, amount, worldPos, label) {
  if (run.practice) return 0;
  const key = `${stageKey(run.idx, run.stage)}_${id}`;
  if (profile.awarded[key]) return 0;
  profile.awarded[key] = 1;
  return registerGoodAction(worldPos, amount, 'sparkle', label);
}

let pendingBadges = [];
function badgeDescription(id) {
  if (id === 'water_guardian') return tx('You have started all three household water-saving challenges.');
  if (id.startsWith('flawless_')) {
    const idx = parseInt(id.split('_')[1], 10);
    return tx('Completed {c} without failing an attempt.', { c: CHALLENGE_LABELS[idx] });
  }
  const idx = CHALLENGE_NAMES.indexOf(id);
  if (idx >= 0) return tx('Completed your first {c} stage.', { c: CHALLENGE_LABELS[idx] });
  return tx('Well done!');
}
function awardBadge(id, label) {
  if (profile.badges.includes(id)) return;
  profile.badges.push(id);
  pendingBadges.push({ id, label });
  refreshPointsHud();
}

function onChallengeComplete(idx, retriesUsed, litresImpact) {
  const practice = run.practice;
  pendingBadges = [];
  let guardianNow = false;
  if (!practice) {
    const wasFirst = !profile.challengesCompleted[idx];
    profile.challengesCompleted[idx] = true;
    addPoints(POINTS.stageComplete);
    profile.totalImpactLitres = (profile.totalImpactLitres || 0) + (litresImpact || 0);
    if (wasFirst) awardBadge(CHALLENGE_NAMES[idx], CHALLENGE_LABELS[idx]);
    if (retriesUsed === 0) awardBadge('flawless_' + idx, 'Flawless: ' + CHALLENGE_LABELS[idx]);
    if (profile.challengesCompleted.every(Boolean) && !profile.badges.includes('water_guardian')) {
      awardBadge('water_guardian', 'Water Guardian');
      guardianNow = true;
    }
  }
  AudioSys.success();
  FX.confetti(new THREE.Vector3(player.x, 1.8, player.z));
  FX.flash('rgba(79,184,255,0.22)', 450);
  refreshPointsHud();
  saveProfile();
  return { badges: pendingBadges.slice(), guardianNow };
}

function showImpactSummary() {
  const total = profile.totalImpactLitres || 0;
  const flushes = Math.max(1, Math.round(total / 9));
  const showerMins = Math.max(1, Math.round(total / 9));
  setTimeout(() => {
    showDialogue(tx('🌍 Water Guardian achieved! You accounted for about {t}L of water — roughly {f} toilet flushes or {s} minutes of shower water. Practised at scale, these household techniques add up fast.',
      { t: total.toFixed(0), f: flushes, s: showerMins }), 12);
  }, 6500);
}

/* --------------------------- Briefing / Badge / Results / Quiz flow -------- */

const briefingPanelEl = el('briefing-panel');
let briefingOnStart = null;
function showBriefing(opts) {
  el('briefing-npc').textContent = opts.npc;
  el('briefing-title').textContent = tx(opts.title);
  el('briefing-text').textContent = tx(opts.text);
  el('briefing-points').innerHTML = opts.points.map((p) => `<li>${escHtml(p)}</li>`).join('');
  el('briefing-controls').textContent = tx(opts.controls);
  el('briefing-practice').classList.toggle('hidden', !opts.practice);
  el('briefing-start').textContent = tx('Start');
  briefingOnStart = opts.onStart || null;
  briefingPanelEl.classList.remove('hidden');
}
el('briefing-start').addEventListener('click', () => {
  briefingPanelEl.classList.add('hidden');
  hintTimer = 0;
  const cb = briefingOnStart;
  briefingOnStart = null;
  if (cb) cb();
});

const badgePanelEl = el('badge-panel');
let badgeDone = null;
function showBadgeUnlock(badges, done) {
  el('badge-panel-title').textContent = tx(badges.length > 1 ? 'Congratulations! Badges Unlocked' : 'Congratulations! Badge Unlocked');
  el('badge-list').innerHTML = badges.map((b) =>
    `<div class="badge-item"><div class="badge-medal">🏅</div><div class="badge-name">${escHtml(b.label)}</div><div class="badge-desc">${escHtml(badgeDescription(b.id))}</div></div>`).join('');
  badgeDone = done || null;
  badgePanelEl.classList.remove('hidden');
  AudioSys.fanfare();
  FX.confetti(new THREE.Vector3(player.x, 1.9, player.z));
}
el('badge-continue').addEventListener('click', () => {
  badgePanelEl.classList.add('hidden');
  const cb = badgeDone;
  badgeDone = null;
  if (cb) cb();
});

const endPanelEl = el('end-panel');
const endRewardView = el('end-reward-view');
const endQuizView = el('end-quiz-view');
const endTitleEl = el('end-title');
const endMessageEl = el('end-message');
const endStatsEl = el('end-stats');
const endWhyEl = el('end-why');
const endContinueBtn = el('end-continue-btn');
const quizProgressEl = el('quiz-progress');
const quizQuestionEl = el('quiz-question');
const quizOptionsEl = el('quiz-options');
const quizFeedbackEl = el('quiz-feedback');
const quizPointsEl = el('quiz-points');
const quizNextBtn = el('quiz-next-btn');
const quizResultsEl = el('quiz-results');

let endState = null;
const quiz = { set: [], index: 0, correct: 0, earned: 0, answered: false };

function resetQuizState() {
  quiz.set = []; quiz.index = 0; quiz.correct = 0; quiz.earned = 0; quiz.answered = false;
  quizOptionsEl.innerHTML = ''; quizFeedbackEl.textContent = ''; quizPointsEl.textContent = ''; quizPointsEl.className = 'quiz-points';
  quizResultsEl.classList.add('hidden'); quizResultsEl.innerHTML = '';
  quizNextBtn.classList.remove('hidden'); quizNextBtn.disabled = true; quizNextBtn.textContent = tx('Choose an answer');
}

function randomOnlineFact() {
  const list = profile.onlineFacts || [];
  return list.length ? list[Math.floor(Math.random() * Math.min(list.length, 30))] : null;
}

function showEndReward(opts) {
  endState = { quizKey: opts.quizKey || null, practice: !!opts.practice, stageId: opts.stageId || null,
    success: opts.success !== false, idx: run.idx, onDone: opts.onDone || null };
  resetQuizState();
  endTitleEl.textContent = tx(opts.title);
  endTitleEl.className = opts.success === false ? 'end-fail' : 'end-ok';
  endMessageEl.textContent = tx(opts.message || '', opts.vars);
  endStatsEl.innerHTML = (opts.stats || []).map((s) => `<div class="stat"><div class="stat-v">${escHtml(s.value)}</div><div class="stat-l">${escHtml(tx(s.label))}</div></div>`).join('');
  const whyParts = [];
  if (opts.why) whyParts.push(`<b>💧 ${escHtml(tx('Why this matters:'))}</b> ${escHtml(opts.why)}`);
  if (opts.home) whyParts.push(`<b>🏠 ${escHtml(tx('Try this at home:'))}</b> ${escHtml(opts.home)}`);
  const fact = opts.success === false ? null : randomOnlineFact();
  if (fact) whyParts.push(`<b>🌐 ${escHtml(tx('Did you know?'))}</b> ${escHtml(fact.text)} <small>(${escHtml(fact.source)})</small>`);
  endWhyEl.innerHTML = whyParts.join('<br><br>');
  endWhyEl.classList.toggle('hidden', whyParts.length === 0);
  endContinueBtn.textContent = tx(endState.quizKey ? 'Continue to quiz ▸' : (opts.continueLabel || 'Continue'));
  const showSummary = () => { endPanelEl.classList.remove('hidden'); endRewardView.classList.remove('hidden'); endQuizView.classList.add('hidden'); };
  if (opts.badges && opts.badges.length) showBadgeUnlock(opts.badges, showSummary); else showSummary();
}

/** After every stage (success or failure), tell the player what to do next — in voice and on screen. */
function announceNextStep(success, idx) {
  let msg, npcKey;
  if (success) {
    const wp = currentWaypoint();
    if (!wp) { msg = tx('Fantastic — you have finished every stage! Talk to any character to replay a stage for practice.'); npcKey = 'npc' + (idx + 1); }
    else {
      const nIdx = [npc1, npc2, npc3].indexOf([npc1, npc2, npc3].find((n) => n.x === wp.x && n.z === wp.z));
      msg = tx('Well done! Next: {npc}. Follow the compass to find them, then press E to talk.', { npc: wp.label });
      npcKey = 'npc' + (nIdx >= 0 ? nIdx + 1 : idx + 1);
    }
  } else {
    msg = tx("Don't give up! Go back to {npc} and press E to try again.", { npc: CHALLENGE_NPC[idx] });
    npcKey = 'npc' + (idx + 1);
  }
  showDialogue(msg, 9, npcKey);
}

function closeEndPanel() {
  endPanelEl.classList.add('hidden');
  const cb = endState && endState.onDone;
  const success = endState ? endState.success : true;
  const idx = endState ? endState.idx : 0;
  endState = null;
  if (cb) cb();
  updateProgressHud(true);
  announceNextStep(success, idx);
  if (profile.pendingCerts && profile.pendingCerts.length) setTimeout(showNextPendingCert, 900);
}

endContinueBtn.addEventListener('click', () => {
  if (endState && endState.quizKey) startQuiz(); else closeEndPanel();
});

function startQuiz() {
  resetQuizState();
  const key = endState.quizKey;
  const stageNum = parseInt(String(endState.stageId || key + '_s1').split('_s')[1], 10) || 1;
  quiz.set = pickQuizSet(key, stageNum, 3, profile.quizSeen);
  quiz.set.forEach((q) => { if (!profile.quizSeen.includes(q.id)) profile.quizSeen.push(q.id); });
  if (profile.quizSeen.length > 150) profile.quizSeen.splice(0, profile.quizSeen.length - 150);
  endRewardView.classList.add('hidden');
  endQuizView.classList.remove('hidden');
  renderQuizQuestion();
}

function renderQuizQuestion() {
  const item = quiz.set[quiz.index];
  quiz.answered = false;
  quizProgressEl.textContent = tx('Question {n} of {t}', { n: quiz.index + 1, t: quiz.set.length });
  quizQuestionEl.textContent = item.q;
  quizFeedbackEl.textContent = ''; quizPointsEl.textContent = ''; quizPointsEl.className = 'quiz-points';
  quizNextBtn.classList.remove('hidden'); quizNextBtn.disabled = true; quizNextBtn.textContent = tx('Choose an answer');
  quizOptionsEl.innerHTML = '';
  item.options.forEach((opt, i) => {
    const btn = document.createElement('div');
    btn.className = 'quiz-option';
    btn.textContent = opt;
    btn.addEventListener('click', () => selectQuizAnswer(i));
    quizOptionsEl.appendChild(btn);
  });
}

function awardQuizPoints() {
  if (endState.practice) return { pts: 0, reason: tx('Practice replay — no points') };
  const id = `${endState.stageId}_quiz`;
  const cap = POINTS.quizCorrect * 3;
  const banked = profile.awarded[id] || 0;
  const pts = Math.min(POINTS.quizCorrect, cap - banked);
  if (pts <= 0) return { pts: 0, reason: tx('Quiz points for this stage were already earned') };
  profile.awarded[id] = banked + pts;
  addPoints(pts);
  return { pts, reason: '' };
}

function selectQuizAnswer(i) {
  if (quiz.answered) return;
  quiz.answered = true;
  const item = quiz.set[quiz.index];
  const buttons = quizOptionsEl.querySelectorAll('.quiz-option');
  buttons.forEach((b) => (b.style.pointerEvents = 'none'));
  profile.quizStats.totalAnswered++;
  if (i === item.correct) {
    buttons[i].classList.add('correct');
    quiz.correct++;
    profile.quizStats.totalCorrect++;
    AudioSys.pickup();
    const res = awardQuizPoints();
    quiz.earned += res.pts;
    if (res.pts > 0) { quizPointsEl.textContent = tx('+{n} Points! Correct Answer', { n: res.pts }); quizPointsEl.className = 'quiz-points gain'; AudioSys.badge(); }
    else { quizPointsEl.textContent = tx('Correct Answer! {r}', { r: res.reason }); quizPointsEl.className = 'quiz-points none'; }
  } else {
    buttons[i].classList.add('incorrect');
    buttons[item.correct].classList.add('correct');
    AudioSys.corrective();
    quizPointsEl.textContent = tx('Not quite — no points. The correct answer is highlighted.');
    quizPointsEl.className = 'quiz-points none';
  }
  quizFeedbackEl.textContent = item.explain;
  unlockFact(item.explain);
  refreshPointsHud();
  saveProfile();
  quizNextBtn.disabled = false;
  quizNextBtn.textContent = tx(quiz.index < quiz.set.length - 1 ? 'Next question ▸' : 'See results ▸');
}

quizNextBtn.addEventListener('click', () => {
  if (!quiz.answered || quizNextBtn.disabled) return;
  if (quiz.index < quiz.set.length - 1) { quiz.index++; renderQuizQuestion(); } else { showQuizResults(); }
});

function showQuizResults() {
  const key = endState.quizKey;
  profile.quizScores[key] = `${quiz.correct}/${quiz.set.length}`;
  saveProfile();
  quizOptionsEl.innerHTML = ''; quizFeedbackEl.textContent = ''; quizPointsEl.textContent = ''; quizPointsEl.className = 'quiz-points';
  quizNextBtn.classList.add('hidden');
  quizProgressEl.textContent = tx('Quiz complete');
  quizQuestionEl.textContent = '';
  const ratio = quiz.correct / quiz.set.length;
  const msg = tx(ratio === 1 ? 'Perfect score — you really know your water-saving!' : ratio >= 0.5 ? 'Good work — check the Facts Journal (J) for the explanations you missed.' : 'Keep going — the Facts Journal (J) has the reasons behind every answer.');
  quizResultsEl.innerHTML = `<div class="big">${quiz.correct} / ${quiz.set.length} ${escHtml(tx('correct'))}</div>` +
    `<div>${endState.practice ? escHtml(tx('Practice replay — no points awarded.')) : escHtml(tx('Quiz points earned:')) + ' <b>+' + quiz.earned + '</b>'}</div>` +
    `<div style="margin:8px 0 16px;">${escHtml(msg)}</div><button id="quiz-done-btn">${escHtml(tx('Continue'))}</button>`;
  quizResultsEl.classList.remove('hidden');
  el('quiz-done-btn').addEventListener('click', closeEndPanel);
}

/* ------------------------------- Quiz bank --------------------------------- */
/* One pool per challenge (not per stage), 7-8 questions each, so the 3
   questions asked after a stage are randomly drawn and rarely repeat; answer
   order is reshuffled every time. */

const QUIZ_POOL = {
  ch1: [
    { q: 'About what share of rural South African households already practise rainwater harvesting?', o: ['10%', '25%', '73.6%', '50%'], c: 2, e: 'Springer Nature (2024) found roughly 73.6% of rural SA households already practise rainwater harvesting.' },
    { q: 'Which surface is generally best for collecting clean rainwater at home?', o: ['A dusty gravel driveway', 'A clean, sealed roof with gutters', 'Bare soil', 'An open compost heap'], c: 1, e: 'A clean, sealed roof with maintained gutters keeps contamination low before the water even reaches a tank.' },
    { q: 'What is the "first flush" of rainwater?', o: ['The last rain of a storm', 'The first, dirtiest runoff that washes dust and droppings off the roof', 'Water from a flushing toilet', 'Rain that falls at night'], c: 1, e: 'The first flush is the initial runoff that carries dust, leaves and bird droppings off the roof, so it is diverted away from the tank.' },
    { q: 'Why should a rainwater storage tank be covered?', o: ['To keep it warm', 'To stop mosquitoes, debris and algae growth', 'To make the water taste sweeter', 'It does not matter'], c: 1, e: 'Covers keep mosquitoes and debris out, and limit algae growth, keeping stored water cleaner for longer.' },
    { q: 'Why does a rainwater tank need an overflow outlet?', o: ['To make noise', "So a full tank's extra water goes somewhere safe instead of flooding", 'To let dirt in', 'To slow the tank filling'], c: 1, e: 'An overflow outlet guides excess water to a safe place (like a soak-away) instead of flooding the yard.' },
    { q: 'Besides drinking, what is harvested rainwater commonly used for in SA households?', o: ['Charging phones', 'Watering gardens and flushing toilets', 'Fuelling vehicles', 'Nothing else'], c: 1, e: 'Garden irrigation and toilet flushing reduce demand on treated municipal water for jobs that do not need it.' },
    { q: 'In 2018 Cape Town came close to "Day Zero" because…', o: ['Too much rain fell', 'A severe drought drained its dams', 'Pipes froze', 'A new law banned water'], c: 1, e: 'A multi-year drought left dams very low, making household water-saving a priority.' },
    { q: '1 mm of rain on 1 square metre of roof gives about how much water?', o: ['0.1 litre', '1 litre', '10 litres', '100 litres'], c: 1, e: '1 mm over 1 m² is 1 litre, so a 100 m² roof can catch roughly 100 litres from just 1 mm of rain.' }
  ],
  ch2: [
    { q: 'Which of these is typically classified as "greywater" in a home?', o: ['Toilet waste', 'Water from showers, basins and laundry', 'Sewage from septic tanks', 'Rainwater'], c: 1, e: 'Greywater is gently-used water from showers, basins and laundry — distinct from "blackwater" (toilet waste), which needs full treatment.' },
    { q: 'Roughly how much water can greywater reuse save per household per day?', o: ['5L', '50L', '500L', '0L'], c: 1, e: 'WRC South Africa estimates greywater reuse saves around 50L/household/day.' },
    { q: 'What is the job of a lint or hair trap?', o: ['To add nutrients', 'To catch solids before they clog pipes and soil', 'To warm the water', 'To make bubbles'], c: 1, e: 'A trap stops hair, lint and soap scum from clogging the pipe and building up in the garden soil.' },
    { q: 'Which laundry water should NOT be reused on the garden?', o: ['Low-sodium detergent rinse', 'Bleach-soaked whites', 'Light soapy basin water', 'Shower rinse'], c: 1, e: 'Bleach and other harsh chemicals harm plants and soil life, so that water is sent to the sewer.' },
    { q: 'Why does a broken or disconnected pipe path fail a routing challenge?', o: ['It looks untidy', "Water can't reach the destination without a continuous path", 'The game requires exactly one pipe', "It doesn't — any layout works"], c: 1, e: 'Just like real plumbing, greywater needs an unbroken route from source to destination to flow.' },
    { q: 'What does a diversion valve let a household do?', o: ['Speed up the tap', 'Send greywater to the garden OR the sewer', 'Make water sweeter', 'Reduce rainfall'], c: 1, e: 'A diversion valve lets you redirect greywater to the sewer whenever the load is unsuitable for the garden.' },
    { q: 'Kitchen sink water with grease and food scraps is usually sent…', o: ['Straight to the garden', 'To the sewer', 'Into drinking water storage', 'Nowhere — it evaporates'], c: 1, e: 'Grease and food scraps clog pipes and soil and feed bacteria, so kitchen sink water is best sent to the sewer.' },
    { q: 'What should greywater generally NOT be used for without further treatment?', o: ['Watering ornamental plants', 'Flushing toilets', 'Direct drinking', 'Irrigating a lawn'], c: 2, e: 'Untreated greywater can carry soap residue, grease and bacteria — unsafe to drink even though fine for irrigation.' }
  ],
  ch3: [
    { q: 'How many pots does the WHO-recommended low-cost household slow sand filter use?', o: ['1', '2', '3', '5'], c: 2, e: 'The WHO-recommended design (WHO, 2017) uses a 3-pot system: sand layers on top, gravel in the middle, filtered water collected at the bottom.' },
    { q: 'In the top pot, which layer goes on top of the coarse sand?', o: ['Gravel', 'Fine sand', 'Nothing', 'More coarse sand'], c: 1, e: 'Fine sand sits above coarse sand — coarse at the base supports and drains, fine on top traps small particles.' },
    { q: 'What does "turbidity" measure?', o: ['Water temperature', 'Cloudiness from suspended particles', 'Saltiness', 'Water speed'], c: 1, e: 'Turbidity is cloudiness caused by suspended particles — higher turbidity often means more contamination risk.' },
    { q: 'What turbidity does WHO recommend for drinking water?', o: ['Below 5 NTU, ideally under 1 NTU', 'Exactly 50 NTU', 'It does not matter', 'Above 100 NTU'], c: 0, e: 'WHO recommends turbidity stay below 5 NTU, ideally under 1 NTU, for effective disinfection and safety.' },
    { q: 'Why does filtered water still usually need disinfection?', o: ['It tastes better', 'Filtering does not guarantee all germs are removed', 'It is a rule about pots', 'Filtered water is poisonous'], c: 1, e: 'Slow sand filtration reduces particles and microbes, but WHO still recommends disinfection as a safety backstop.' },
    { q: 'What is the "schmutzdecke" in a slow sand filter?', o: ['A pot', 'A thin biological layer on top that helps clean the water', 'A tool', 'A kind of gravel'], c: 1, e: 'The schmutzdecke is a thin, living layer on the sand surface that traps and consumes microbes and particles.' },
    { q: 'A filter\'s flow slows to a trickle. What is the usual fix?', o: ['Throw it away', 'Gently rake or scrape the top layer', 'Add more water', 'Add soap'], c: 1, e: 'A slow sand filter clogs at the surface; gently raking the top layer restores flow without replacing the sand.' },
    { q: 'How should you boil water to disinfect it?', o: ['Warm it slightly', 'Bring it to a rolling boil (at least 1 minute) and let it cool covered', 'Boil it for a few seconds', 'Freeze it'], c: 1, e: 'A rolling boil kills the germs that cause disease; cool the water in a clean, covered container.' }
  ]
};
const QUIZ_QUESTIONS_PER_STAGE = 3;
function _shuffle(a) { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; }

function pickQuizSet(key, stage, n, seen) {
  const pool = QUIZ_POOL[key] || [];
  const withId = pool.map((q, i) => Object.assign({ id: `${key}_${i}` }, q));
  const seenSet = new Set(seen || []);
  let fresh = _shuffle(withId.filter((q) => !seenSet.has(q.id)));
  if (fresh.length < n) fresh = fresh.concat(_shuffle(withId.filter((q) => seenSet.has(q.id))));
  return fresh.slice(0, n).map((q) => {
    const correctText = q.o[q.c];
    const opts = _shuffle(q.o);
    return { id: q.id, q: q.q, options: opts, correct: opts.indexOf(correctText), explain: q.e };
  });
}

/* --------------------------------- Player ---------------------------------- */

const playerRig = createHumanoid(0x2559d9);
scene.add(playerRig.group);
playerRig.group.position.set(0, 0, 0);

const facingArrowPivot = new THREE.Group();
const facingArrowMesh = new THREE.Mesh(new THREE.ConeGeometry(0.32, 1.0, 4), new THREE.MeshBasicMaterial({ color: 0xffe767 }));
facingArrowMesh.rotation.x = Math.PI / 2;
facingArrowMesh.position.z = 1.1;
facingArrowPivot.add(facingArrowMesh);
facingArrowPivot.position.y = 0.05;
scene.add(facingArrowPivot);

const player = { x: 0, z: 0, facing: 0, hasBucket: false, bucketLitres: 0, footstepTimer: 0 };

const keys = {};
let interactJustPressed = false;
let trapKeyJustPressed = false;
let selectKeyJustPressed = null;
function isTypingTarget(e) { const tg = e.target; return !!tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.tagName === 'SELECT'); }

window.addEventListener('keydown', (e) => {
  if (isTypingTarget(e) && e.key !== 'Escape') return;
  const k = e.key.toLowerCase();
  if (!keys[k]) {
    if (k === 'e') interactJustPressed = true;
    if (k === 'f') trapKeyJustPressed = true;
    if (k === '1' || k === '2' || k === '3') selectKeyJustPressed = k;
  }
  keys[k] = true;
  if (k.startsWith('arrow')) e.preventDefault();
});
window.addEventListener('keyup', (e) => { keys[e.key.toLowerCase()] = false; });
window.addEventListener('blur', () => { Object.keys(keys).forEach((k) => { keys[k] = false; }); rmbDown = false; });

let rmbDown = false;
window.addEventListener('mousedown', (e) => { if (e.button === 2 && gameStarted && !isUiBlocking()) rmbDown = true; });
window.addEventListener('mouseup', (e) => { if (e.button === 2) rmbDown = false; });
window.addEventListener('mousemove', (e) => { if (rmbDown && gameStarted && !isUiBlocking()) camYaw -= (e.movementX || 0) * 0.008; });
window.addEventListener('contextmenu', (e) => e.preventDefault());

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function dist2D(ax, az, bx, bz) { return Math.hypot(ax - bx, az - bz); }
function isUiBlocking() { return document.querySelector('#ui-root .modal:not(.hidden)') !== null; }

/* ----------------------------------- NPCs ----------------------------------- */

function makeNpc(color, x, z, labelText, hatOptions) {
  const rig = createHumanoid(color, hatOptions);
  rig.group.position.set(x, 0, z);
  scene.add(rig.group);
  const label = makeLabel(labelText);
  label.position.set(x, 2.9, z);
  scene.add(label);
  return { rig, x, z, challengeGiven: false };
}

const npc1 = makeNpc(0xe6741a, ZONE1.x, ZONE1.z + 9, 'Water Warden', { hat: 'cap', hatColor: 0x1a5fc4 });
const npc2 = makeNpc(0x1a8f8f, ZONE2.x, ZONE2.z + 9, 'Pipe-Fitter Pete', { hat: 'band', hatColor: 0xe8a83a });
const npc3 = makeNpc(0x7a3fb0, ZONE3.x, ZONE3.z + 9, 'Filter Fundi', { hat: 'wide', hatColor: 0x8a6a3a });
const NPCS = [npc1, npc2, npc3];

function makeQuestMarker() {
  const cnv = document.createElement('canvas');
  cnv.width = 96; cnv.height = 96;
  const ctx = cnv.getContext('2d');
  ctx.fillStyle = '#ffe066';
  ctx.beginPath(); ctx.arc(48, 48, 40, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#7a5a10'; ctx.lineWidth = 5; ctx.stroke();
  ctx.fillStyle = '#3a2a05';
  ctx.font = 'bold 58px sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('!', 48, 54);
  const tex = new THREE.CanvasTexture(cnv);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(0.7, 0.7, 1);
  return sprite;
}
const questMarkers = [];
function attachQuestMarker(npcObj, availableFn) {
  const marker = makeQuestMarker();
  marker.position.set(npcObj.x, 3.55, npcObj.z);
  scene.add(marker);
  questMarkers.push({ marker, npcObj, availableFn, greeted: false });
}
function updateQuestMarkers(dt, elapsed) {
  questMarkers.forEach((q) => {
    const available = q.availableFn();
    q.marker.visible = available;
    if (!available) { q.greeted = false; return; }
    q.marker.position.y = 3.55 + Math.sin(elapsed * 3 + q.npcObj.x) * 0.12;
    const near = dist2D(player.x, player.z, q.npcObj.x, q.npcObj.z) < 4.5;
    if (near && !q.greeted) { q.greeted = true; gesture(q.npcObj.rig); AudioSys.pickup(); }
    else if (!near) { q.greeted = false; }
  });
}

/** True when the stage this NPC currently offers is unlocked (strict ladder order across the 3 NPCs). */
function nextLadderStep() {
  for (let s = 1; s <= 3; s++) {
    for (let idx = 0; idx < 3; idx++) {
      if (profile.stagesCompleted[chKey(idx)] < s) return { idx, stage: s };
    }
  }
  return null;
}

function registerNpcInteractable(npcObj, idx, challengeStateGetter, startChallengeFn) {
  interactables.push({
    x: npcObj.x, z: npcObj.z, radius: 3.2,
    getPrompt() {
      if (challengeStateGetter() !== 'idle' || npcObj.challengeGiven) return null;
      const c = chObj(idx);
      const nxt = nextLadderStep();
      const isNew = profile.stagesCompleted[chKey(idx)] < c.stage;
      if (!isNew) return tx("Press E to replay {npc}'s Stage {n} (practice — no points)", { npc: CHALLENGE_NPC[idx], n: c.stage });
      if (!(nxt && nxt.idx === idx && nxt.stage === c.stage)) return tx('🔒 {npc} — locked (press E to see what to do first)', { npc: CHALLENGE_NPC[idx] });
      return tx('Press E to talk to {npc}', { npc: CHALLENGE_NPC[idx] });
    },
    interact() {
      if (challengeStateGetter() !== 'idle' || npcObj.challengeGiven) return;
      const c = chObj(idx);
      const isNew = profile.stagesCompleted[chKey(idx)] < c.stage;
      const nxt = nextLadderStep();
      if (isNew && !(nxt && nxt.idx === idx && nxt.stage === c.stage)) {
        const m = nxt ? { npc: CHALLENGE_NPC[nxt.idx], n: nxt.stage, t: STAGE_TITLES[nxt.idx][nxt.stage - 1] } : null;
        showFeedback('info', tx('{npc}: "Not yet!"', { npc: CHALLENGE_NPC[idx] }),
          m ? [{ tag: '🔒 ' + tx('Locked:') + ' ', text: tx('Tasks are done in order. Finish Stage {n} ({t}) with {npc} first.', m) }] : [], 7);
        AudioSys.corrective();
        return;
      }
      npcObj.challengeGiven = true;
      gesture(npcObj.rig);
      startChallengeFn();
    }
  });
}
function findNearestInteractable() {
  let nearest = null, nearestDist = Infinity;
  for (const it of interactables) {
    const d = dist2D(player.x, player.z, it.x, it.z);
    if (d < it.radius && d < nearestDist && it.getPrompt()) { nearest = it; nearestDist = d; }
  }
  return nearest;
}

/* ---------------------------------- Camera ---------------------------------- */

function cameraTarget() {
  const ox = camOffset.z * Math.sin(camYaw);
  const oz = camOffset.z * Math.cos(camYaw);
  return new THREE.Vector3(player.x + ox, camOffset.y, player.z + oz);
}
{ const p0 = cameraTarget(); camera.position.set(p0.x, p0.y, p0.z); }
function updateCamera(dt) {
  camera.position.lerp(cameraTarget(), Math.min(1, 12 * dt));
  camera.lookAt(player.x, 1.2, player.z);
}

/* ============================================================================
   CHALLENGE 1 — Rainwater Harvesting
   Stage 1: Collect & Store — carry a bucket from puddle to tank (capped, with
            an overflow penalty for overfilling).
   Stage 2: First-Flush Diverter — switch flow between DRAIN and TANK as rain
            falls, discarding the dirty first flush.
   Stage 3: Storm Manager — open the overflow valve before a storm surge and
            water three garden beds from the stored water.
   ============================================================================ */

const ch1 = { state: 'idle', stage: 1, retries: 0 };

const bucketMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.3, 12), new THREE.MeshStandardMaterial({ color: 0xf2c81c }));
scene.add(bucketMesh);
const CP_EMPTY = new THREE.Color(0x9e9ea8), CP_FULL = new THREE.Color(0x1a6bf2);

function makeCheckpoint(x, z) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.12, 20), new THREE.MeshStandardMaterial({ color: CP_EMPTY.getHex() }));
  mesh.position.set(x, 0.06, z);
  scene.add(mesh);
  const rainGroup = new THREE.Group();
  const rainDrops = [];
  for (let i = 0; i < 20; i++) {
    const drop = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.25, 0.03), new THREE.MeshBasicMaterial({ color: 0x9cd0ff, transparent: true, opacity: 0.85 }));
    drop.position.set(x + (Math.random() - 0.5) * 2.6, 3 + Math.random() * 5, z + (Math.random() - 0.5) * 2.6);
    rainDrops.push(drop); rainGroup.add(drop);
  }
  scene.add(rainGroup);
  return { x, z, mesh, rainDrops, collected: 0, bucketPlaced: false };
}
const ch1Checkpoints = [];
[[-9, ZONE1.z + 4], [9, ZONE1.z + 4], [0, ZONE1.z - 6]].forEach(([dx, dz]) => ch1Checkpoints.push(makeCheckpoint(ZONE1.x + dx, dz)));

const tankMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 2.2, 14), new THREE.MeshStandardMaterial({ color: 0x3a7a9a, transparent: true, opacity: 0.5 }));
tankMesh.position.set(ZONE1.x - 15, 1.1, ZONE1.z - 2);
scene.add(tankMesh);
const tankWater = new THREE.Mesh(new THREE.CylinderGeometry(0.98, 0.98, 2.0, 14), new THREE.MeshStandardMaterial({ color: 0x1a6bf2 }));
tankWater.position.set(tankMesh.position.x, 0.1, tankMesh.position.z);
tankWater.scale.y = 0.001;
scene.add(tankWater);
const tankLabel = makeDynamicLabel('Storage Tank');
tankLabel.position.set(tankMesh.position.x, 2.9, tankMesh.position.z);
scene.add(tankLabel);
function updateTankVisual(total, cap) {
  const frac = Math.max(0, Math.min(1, total / Math.max(1, cap)));
  tankWater.scale.y = Math.max(0.001, frac);
  tankWater.position.y = 0.1 + (2.0 * frac) / 2;
  tankLabel.userData.setText(tx('Storage Tank {a}/{b}L', { a: total.toFixed(0), b: cap }));
}

const soakAwayMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.08, 16), new THREE.MeshStandardMaterial({ color: 0x6a6a5a }));
soakAwayMesh.position.set(ZONE1.x - 15, 0.04, ZONE1.z - 8);
scene.add(soakAwayMesh);
scene.add((() => { const l = makeLabel('Soak-Away Bed'); l.position.set(soakAwayMesh.position.x, 1.4, soakAwayMesh.position.z); return l; })());
const valveLabel = makeDynamicLabel('Overflow valve');
valveLabel.position.set(soakAwayMesh.position.x, 2.2, soakAwayMesh.position.z);
valveLabel.visible = false;
scene.add(valveLabel);

const gardenBeds = [-8, -1, 6].map((dx) => {
  const g = new THREE.Group();
  g.position.set(ZONE1.x + dx, 0, ZONE1.z - 11);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.4, 0.3, 14), new THREE.MeshStandardMaterial({ color: 0x7a5a33 }));
  base.position.y = 0.15;
  g.add(base);
  g.visible = false;
  scene.add(g);
  const label = makeDynamicLabel('Bed');
  label.position.set(g.position.x, 1.6, g.position.z);
  label.visible = false;
  scene.add(label);
  return { group: g, base, label, x: g.position.x, z: g.position.z, have: 0, need: 20 };
});

/* --- Stage 1: bucket-carry interactables ------------------------------------ */
interactables.push({
  x: tankMesh.position.x, z: tankMesh.position.z, radius: 3.0,
  getPrompt() {
    if (ch1.state !== 'active' || ch1.stage !== 1) return null;
    const carrying = player.hasBucket && player.bucketLitres > 0.05;
    return carrying ? tx('Press E to pour {a}L into the tank ({b}/{c}L)', { a: player.bucketLitres.toFixed(1), b: ch1.total.toFixed(1), c: ch1.target })
      : tx('Bring a bucket of collected rainwater here (E to pour)');
  },
  interact() {
    if (ch1.state !== 'active' || ch1.stage !== 1) return;
    const carrying = player.hasBucket && player.bucketLitres > 0.05;
    if (!carrying) {
      wrongAction('npc1', 'Your bucket is empty, so there is nothing to pour into the tank.', 'Fill the bucket at a puddle, then carry it here.',
        'Only rainwater that is carried to and stored in the tank counts.', 0);
      return;
    }
    const space = Math.max(0, ch1.target - ch1.total);
    const add = Math.min(player.bucketLitres, space);
    const excess = player.bucketLitres - add;
    ch1.total += add;
    player.bucketLitres = 0;
    gesture(playerRig); AudioSys.splash();
    FX.splash(new THREE.Vector3(tankMesh.position.x, 2.0, tankMesh.position.z));
    registerGoodAction({ x: tankMesh.position.x, y: 0.5, z: tankMesh.position.z }, Math.round(add) * POINTS.perLitre, 'splash', 'stored');
    if (excess > 0.05) {
      const pen = Math.min(20, Math.max(POINTS.overflowPerLitre, Math.round(excess * POINTS.overflowPerLitre)));
      wrongAction('npc1', tx('The tank only holds {cap}L — {x}L overflowed and was discarded.', { cap: ch1.target, x: excess.toFixed(1) }),
        'Watch the gauge on the tank and stop delivering once it is full.', 'Real tanks have a fixed capacity; uncontrolled overflow wastes water.', pen);
    } else {
      goodAction(tx('{a}L stored in the tank ({b}/{c}L)', { a: add.toFixed(1), b: ch1.total.toFixed(1), c: ch1.target }),
        'Carrying harvested water to a covered tank stores it safely for dry spells.', 4);
    }
    updateCh1Hud();
  }
});
ch1Checkpoints.forEach((cp) => {
  interactables.push({
    x: cp.x, z: cp.z, radius: 2.6,
    getPrompt() {
      if (ch1.state !== 'active' || ch1.stage !== 1) return null;
      if (!cp.bucketPlaced) return player.hasBucket ? tx('Press E to place bucket here') : null;
      return tx('Press E to pick up bucket ({n}L) — then carry it to the tank', { n: cp.collected.toFixed(1) });
    },
    interact() {
      if (ch1.state !== 'active' || ch1.stage !== 1) return;
      if (!cp.bucketPlaced) {
        if (!player.hasBucket) return;
        cp.bucketPlaced = true; cp.collected = 0; player.hasBucket = false;
        gesture(playerRig); AudioSys.splash(); FX.splash(new THREE.Vector3(cp.x, 0.8, cp.z));
        updateCh1Hud();
        return;
      }
      player.bucketLitres = cp.collected; cp.bucketPlaced = false; cp.collected = 0; player.hasBucket = true;
      gesture(playerRig); AudioSys.pickup(); updateCh1Hud();
    }
  });
});
function resetCh1World() {
  ch1Checkpoints.forEach((cp) => { cp.bucketPlaced = false; cp.collected = 0; cp.mesh.material.color.copy(CP_EMPTY); });
  player.hasBucket = false; player.bucketLitres = 0;
  updateTankVisual(0, ch1.target || 50);
  gardenBeds.forEach((b) => { b.group.visible = false; b.label.visible = false; b.have = 0; });
  valveLabel.visible = false;
}

registerNpcInteractable(npc1, 0, () => ch1.state, ch1Start);
attachQuestMarker(npc1, () => ch1.state === 'idle' && !npc1.challengeGiven);

function ch1Params() {
  const dm = difficultyMultiplier();
  return { time: Math.round(75 * dm.time), target: Math.round(50 * dm.target) };
}

function ch1Start() {
  if (ch1.stage === 1) { ch1StartStage1(); }
  else if (ch1.stage === 2) { ch1StartStage2(); }
  else { ch1StartStage3(); }
}

function ch1StartStage1() {
  const p = ch1Params();
  resetCh1World();
  ch1.state = 'active'; ch1.timeLeft = p.time; ch1.timeLimit = p.time; ch1.target = p.target; ch1.total = 0;
  player.hasBucket = true; player.bucketLitres = 0;
  runStart(0, 1);
  updateTankVisual(0, ch1.target);
  const cap = ch1.target;
  const text = tx('Place your bucket on a glowing puddle, let it fill, pick it up and CARRY it to the Storage Tank. Only water poured into the tank counts, and it holds exactly {cap}L — extra is lost. Beat the timer!', { cap });
  showDialogue(tx('{npc}: "{greet}Stage 1 — Fill your bucket at a puddle, then carry it to the Storage Tank. The tank holds {cap}L, no more!"', { npc: 'Water Warden', greet: greet() }), 6, 'npc1');
  setObjective(tx('<b>Stage 1/3.</b> Fill the bucket at a puddle (E), carry it to the tank, pour it in (E). Fill the {cap}L tank before the timer hits 0.', { cap }));
  AudioSys.startRain();
  updateCh1Hud();
  ch1.hint = () => (player.hasBucket && player.bucketLitres > 0.05 ? 'Hint: carry your full bucket to the Storage Tank and pour it in.' : 'Hint: place your bucket on a glowing puddle, wait for it to fill, then pick it up.');
  ch1.waypoint = () => {
    const carrying = player.hasBucket && player.bucketLitres > 0.05;
    if (carrying) return { x: tankMesh.position.x, z: tankMesh.position.z, label: 'Storage Tank' };
    const placed = ch1Checkpoints.find((cp) => cp.bucketPlaced);
    if (placed) return { x: placed.x, z: placed.z, label: 'Your bucket' };
    return { x: ch1Checkpoints[0].x, z: ch1Checkpoints[0].z, label: 'Puddle' };
  };
  showBriefing({
    npc: 'Water Warden — Rainwater Harvesting', title: tx('Stage 1 of 3: {t}', { t: 'Collect & Store' }), text,
    points: [tx('+{n} point per litre stored in the tank', { n: POINTS.perLitre }), tx('+{n} points for completing the stage', { n: POINTS.stageComplete }),
      tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points per litre lost by overfilling the tank', { n: POINTS.overflowPerLitre }), tx('Penalty: −{n} points if time runs out', { n: POINTS.timeUp }),
      tx('Paid once per stage — replays are practice (no points, no penalties).')],
    controls: 'E on a puddle: place / pick up your bucket • E at the Storage Tank: pour in the water • WASD / arrows: move • Z / X: rotate camera',
    practice: run.practice
  });
}

function updateCh1Hud() {
  const carrying = player.hasBucket && player.bucketLitres > 0.05;
  setInventory(tx('Bucket: {b} | Tank: {t}L / {c}L', { b: !player.hasBucket ? tx('down at a puddle') : carrying ? tx('carrying {n}L', { n: player.bucketLitres.toFixed(1) }) : tx('empty'), t: ch1.total.toFixed(1), c: ch1.target }));
  bucketMesh.material.color.setHex(carrying ? 0x3fa6ff : 0xf2c81c);
  updateTankVisual(ch1.total, ch1.target);
}

function ch1Complete(extra) {
  const stageDone = ch1.stage;
  ch1.state = 'complete'; runStop(); timerEl.classList.add('hidden'); setInventory(null); clearObjective();
  AudioSys.stopRain(); setUrgencyVignette(false);
  const res = onChallengeComplete(0, ch1.retries, ch1.total);
  recordHistory('Completed');
  advanceStage('ch1');
  unlockFact('Try this at home: place a clean bucket or drum under your downpipe next time it rains.');
  if (res.guardianNow) showImpactSummary();
  showEndReward(Object.assign({
    title: tx('Stage {n} Complete!', { n: stageDone }),
    message: tx("You stored {n}L of rainwater in the tank — roughly enough for one family's daily cooking water.", { n: ch1.total.toFixed(1) }) + (run.practice ? '\n\n' + tx('Practice replay — no new points or badges.') : ''),
    stats: metricStats([{ label: 'Water stored', value: ch1.total.toFixed(1) + ' L' }]),
    why: 'Harvesting rain from your roof and storing it in a covered tank cuts demand on municipal supply.',
    home: 'place a clean bucket or drum under your downpipe next time it rains.',
    quizKey: 'ch1', practice: run.practice, stageId: stageKey(0, stageDone), badges: res.badges,
    onDone: () => { resetCh1World(); npc1.challengeGiven = false; ch1.state = 'idle'; ch1.hint = null; ch1.waypoint = null; }
  }, extra || {}));
}
function ch1Fail(opts) {
  ch1.state = 'failed'; ch1.retries++; profile.retries.ch1 = ch1.retries;
  runStop(); timerEl.classList.add('hidden'); setInventory(null); clearObjective();
  AudioSys.stopRain(); setUrgencyVignette(false); AudioSys.fail();
  penalize(POINTS.timeUp);
  recordHistory(opts.status || 'Failed (time up)');
  showEndReward(Object.assign({
    title: opts.title || "Time's Up!", success: false,
    message: opts.message || tx('You stored {a}L out of {b}L before the timer ran out. Try again!', { a: ch1.total.toFixed(1), b: ch1.target }),
    stats: metricStats(opts.stats || [{ label: 'Water stored', value: ch1.total.toFixed(1) + ' L / ' + ch1.target + ' L' }]),
    why: opts.why || 'Rain is only there while it falls — being quick and organised means more ends up stored.',
    quizKey: null, continueLabel: 'Try again',
    onDone: () => { resetCh1World(); npc1.challengeGiven = false; ch1.state = 'idle'; ch1.hint = null; ch1.waypoint = null; }
  }, opts.endOverrides || {}));
}

function updateCh1Stage1(dt) {
  ch1Checkpoints.forEach((cp) => {
    if (cp.bucketPlaced && cp.collected < 20) cp.collected = Math.min(20, cp.collected + 4 * dt);
    const t = cp.collected / 20;
    cp.mesh.material.color.copy(CP_EMPTY).lerp(CP_FULL, t);
    cp.rainDrops.forEach((drop) => {
      drop.position.y -= 8 * dt;
      if (drop.position.y < 0.3) { drop.position.y = 5 + Math.random() * 3; drop.position.x = cp.x + (Math.random() - 0.5) * 2.6; drop.position.z = cp.z + (Math.random() - 0.5) * 2.6; }
    });
    if (cp.bucketPlaced) { bucketMesh.visible = true; bucketMesh.position.set(cp.x, 0.2, cp.z); }
  });
  if (player.hasBucket) {
    bucketMesh.visible = true;
    bucketMesh.position.set(player.x + Math.cos(player.facing + 1) * 0.5, 0.55, player.z + Math.sin(player.facing + 1) * 0.5);
  } else if (!ch1Checkpoints.some((cp) => cp.bucketPlaced)) bucketMesh.visible = false;

  ch1.timeLeft -= dt;
  setUrgencyVignette(ch1.timeLeft <= 10);
  setTimerHud(ch1.timeLeft, ch1.timeLimit);
  if (ch1.total >= ch1.target - 0.001) { ch1Complete(); return; }
  if (ch1.timeLeft <= 0) { ch1.timeLeft = 0; ch1Fail({}); return; }
  updateCh1Hud();
}

/* --- Stage 2: First-Flush Diverter ------------------------------------------ */

const diverterGroup = new THREE.Group();
diverterGroup.position.set(tankMesh.position.x - 5.8, 0, tankMesh.position.z + 0.6);
diverterGroup.visible = false;
scene.add(diverterGroup);
const diverterPost = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.6, 0.8), new THREE.MeshStandardMaterial({ color: 0x2f7fbf }));
diverterPost.position.y = 0.8;
diverterGroup.add(diverterPost);
const diverterLabel = makeDynamicLabel('Diverter');
diverterLabel.position.y = 2.6;
diverterGroup.add(diverterLabel);
const drainMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.1, 14), new THREE.MeshStandardMaterial({ color: 0x3a3a3a }));
drainMesh.position.set(tankMesh.position.x - 5.5, 0.05, tankMesh.position.z + 4.2);
drainMesh.visible = false;
scene.add(drainMesh);
const drainLabel = makeDynamicLabel('Drain');
drainLabel.position.set(drainMesh.position.x, 1.5, drainMesh.position.z);
drainLabel.visible = false;
scene.add(drainLabel);

interactables.push({
  x: diverterGroup.position.x, z: diverterGroup.position.z, radius: 3,
  getPrompt() {
    if (ch1.state !== 'active' || ch1.stage !== 2) return null;
    return tx('Press E to switch to {r}  (now: {c})', { r: tx(ch1.route === 'tank' ? 'DRAIN' : 'TANK'), c: tx(ch1.route === 'tank' ? 'TANK' : 'DRAIN') });
  },
  interact() {
    if (ch1.state !== 'active' || ch1.stage !== 2) return;
    ch1.route = ch1.route === 'tank' ? 'drain' : 'tank';
    gesture(playerRig); AudioSys.pipePlace();
    if (ch1.route === 'tank' && ch1.raining && ch1.dirty) {
      wrongAction('npc1', 'The water is still dirty, but you switched the flow to the tank.', 'Keep the diverter on DRAIN until the water turns clear.',
        'The first flush washes dust and droppings off the roof — real systems discard it so the tank stays clean.', POINTS.dirtyLitre);
    }
  }
});

function ch1StartStage2() {
  const dm = difficultyMultiplier();
  resetCh1World();
  ch1.state = 'active'; ch1.target = Math.round(50 * dm.target); ch1.total = 0;
  ch1.route = 'tank'; ch1.phases = [{ n: 'wait', len: 8 }, { n: 'burst', len: 14, flush: 5, no: 1 }, { n: 'dry', len: 5 }, { n: 'burst', len: 14, flush: 4, no: 2 }];
  ch1.pi = 0; ch1.pt = 0; ch1.dirty = false; ch1.raining = false; ch1.dirtyIn = 0; ch1.dirtyPaid = 0; ch1.flushOk = {}; ch1.burstDirtyStart = 0; ch1.warned = {};
  ch1.timeLimit = 8 + 14 + 5 + 14; ch1.timeLeft = ch1.timeLimit;
  diverterGroup.visible = true; drainMesh.visible = true; drainLabel.visible = true;
  runStart(0, 2);
  updateTankVisual(0, ch1.target);
  showDialogue(tx('{npc}: "{greet}Stage 2 — A storm is coming! The first water off the roof is dirty. Switch the diverter to DRAIN while it is brown, TANK once it runs clear."', { npc: 'Water Warden', greet: greet() }), 8, 'npc1');
  setObjective(tx('<b>Stage 2/3.</b> Switch the diverter (E) between DRAIN and TANK. Store {cap}L of clean water.', { cap: ch1.target }));
  ch1.hint = () => (ch1.dirty ? 'Hint: the water is dirty — keep the diverter on DRAIN.' : 'Hint: the water is clear — switch the diverter to TANK.');
  ch1.waypoint = () => ({ x: diverterGroup.position.x, z: diverterGroup.position.z, label: 'Diverter' });
  showBriefing({
    npc: 'Water Warden — Rainwater Harvesting', title: tx('Stage 2 of 3: {t}', { t: 'First-Flush Diverter' }), text: tx('A storm is coming! The first water off the roof is dirty. Stand at the diverter and press E to switch between DRAIN and TANK. Store {cap}L of clean water.', { cap: ch1.target }),
    points: [tx('+{n} point per litre of CLEAN water stored', { n: POINTS.perLitre }), tx('+{n} points each time a dirty first flush is fully diverted', { n: POINTS.cleanFlush }),
      tx('+{n} points for completing the stage', { n: POINTS.stageComplete }), tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points for each litre of dirty water let into the tank', { n: POINTS.dirtyLitre }), tx('Penalty: −{n} points if time runs out', { n: POINTS.timeUp }),
      tx('Paid once per stage — replays are practice.')],
    controls: 'E at the diverter: switch the flow between DRAIN and TANK • WASD / arrows: move • Z / X: rotate camera',
    practice: run.practice
  });
}

function ch1EndBurst(ph) {
  if (ch1.dirtyIn - ch1.burstDirtyStart < 0.5) {
    ch1.flushOk[ph.no] = true;
    awardSubtask('flush' + ph.no, POINTS.cleanFlush, { x: diverterGroup.position.x, y: 1, z: diverterGroup.position.z }, 'clean flush');
    goodAction('Dirty first flush fully diverted', 'The roof is washed by the first rain — sending that water to the drain keeps the tank clean.', 5);
  }
}

function updateCh1Stage2(dt) {
  ch1.pt += dt;
  let ph = ch1.phases[ch1.pi];
  while (ph && ch1.pt >= ph.len) {
    ch1.pt -= ph.len;
    if (ph.n === 'burst') ch1EndBurst(ph);
    ch1.pi++;
    ph = ch1.phases[ch1.pi];
    if (ph && ph.n === 'burst') { ch1.burstDirtyStart = ch1.dirtyIn; showDialogue('The rain has started — watch the colour of the water!', 4, 'npc1'); }
  }
  ch1.raining = !!ph && ph.n === 'burst';
  ch1.dirty = ch1.raining && ch1.pt < ph.flush;
  if (ch1.raining) AudioSys.startRain(); else AudioSys.stopRain();
  diverterPost.material.color.setHex(!ch1.raining ? 0x2f7fbf : ch1.dirty ? 0x6b5230 : 0x3fa6ff);
  if (ch1.raining && ch1.route === 'tank') {
    const amt = 4.5 * dt;
    if (ch1.dirty) {
      ch1.dirtyIn += amt;
      const whole = Math.floor(ch1.dirtyIn);
      while (ch1.dirtyPaid < whole) { ch1.dirtyPaid++; penalize(POINTS.dirtyLitre); }
      if (!ch1.warned[ph.no]) {
        ch1.warned[ph.no] = true; registerMistake(); AudioSys.corrective();
        showFeedback('bad', 'Not quite!', [{ tag: '✖ ' + tx('What happened:') + ' ', text: tx('Dirty first-flush water is flowing into your tank.') },
          { tag: '✔ ' + tx('Do this instead:') + ' ', text: tx('Switch the diverter back to DRAIN right now.') },
          { tag: '💧 ' + tx('Why it matters:') + ' ', text: 'Once dirt is in the tank it contaminates all the stored water.' }], 8);
      }
      if (ch1.dirtyIn > 6) { ch1Fail({ status: 'Failed (tank contaminated)', title: 'Tank contaminated!', message: 'Too much dirty first-flush water got into the tank.', why: 'A first-flush diverter discards the dirtiest runoff before it reaches the tank.' }); return; }
    } else {
      const add = Math.min(amt, ch1.target - ch1.total);
      ch1.total += add;
      registerGoodAction({ x: diverterGroup.position.x, y: 0.5, z: diverterGroup.position.z }, Math.round(add) * POINTS.perLitre || 0, 'splash');
    }
  }
  updateTankVisual(ch1.total, ch1.target);
  diverterLabel.userData.setText(tx('→ {r} • {q}', { r: tx(ch1.route === 'tank' ? 'TANK' : 'DRAIN'), q: tx(!ch1.raining ? 'no rain' : ch1.dirty ? 'DIRTY' : 'CLEAR') }));
  setInventory(tx('Diverter → {r} | Tank: {t}/{c}L | Dirty water in tank: {d}L', { r: tx(ch1.route === 'tank' ? 'TANK' : 'DRAIN'), t: ch1.total.toFixed(1), c: ch1.target, d: ch1.dirtyIn.toFixed(1) }));
  if (ch1.total >= ch1.target - 0.001) {
    const ph2 = ch1.phases[ch1.pi];
    if (ph2 && ph2.n === 'burst' && !ch1.flushOk[ph2.no]) ch1EndBurst(ph2);
    ch1Complete({ message: tx('Your tank holds {n}L of clean rainwater — and only {d}L of dirty water got in.', { n: ch1.total.toFixed(1), d: ch1.dirtyIn.toFixed(1) }),
      stats: metricStats([{ label: 'Dirty water in tank', value: ch1.dirtyIn.toFixed(1) + ' L' }]),
      why: 'A first-flush diverter sends the dirtiest runoff away, so the stored water is clean.' });
    return;
  }
  ch1.timeLeft -= dt;
  setTimerHud(ch1.timeLeft, ch1.timeLimit, true);
  if (ch1.timeLeft <= 0 && ch1.state === 'active') { ch1Fail({ status: 'Failed (rain ended)', title: 'The rain has stopped!', message: 'The storm ended before the tank was full.', why: 'Rain is only there while it falls.' }); }
}

/* --- Stage 3: Storm Manager --------------------------------------------------- */

interactables.push({
  x: soakAwayMesh.position.x, z: soakAwayMesh.position.z, radius: 3.2,
  getPrompt() { return ch1.state === 'active' && ch1.stage === 3 ? tx('Press E to {a} the overflow valve  (now: {b})', { a: tx(ch1.valve ? 'CLOSE' : 'OPEN'), b: tx(ch1.valve ? 'OPEN' : 'CLOSED') }) : null; },
  interact() {
    if (ch1.state !== 'active' || ch1.stage !== 3) return;
    ch1.valve = !ch1.valve; gesture(playerRig); AudioSys.pipePlace();
    if (ch1.valve && !ch1.valveEver) {
      ch1.valveEver = true;
      if (!ch1.surge && !ch1.surgeDone) awardSubtask('valve', POINTS.valveOpened, { x: soakAwayMesh.position.x, y: 1, z: soakAwayMesh.position.z }, 'overflow valve');
      goodAction('Overflow valve open', 'With the valve open a full tank sends its extra water to the soak-away instead of flooding the yard.', 6);
    }
  }
});
interactables.push({
  x: tankMesh.position.x, z: tankMesh.position.z, radius: 3.0,
  getPrompt() {
    if (ch1.state !== 'active' || ch1.stage !== 3) return null;
    return player.bucketLitres > 0.05 ? null : tx('Press E to fill your bucket from the tank ({t}L in the tank)', { t: ch1.total.toFixed(1) });
  },
  interact() {
    if (ch1.state !== 'active' || ch1.stage !== 3 || player.bucketLitres > 0.05) return;
    const d = Math.min(10, ch1.total);
    if (d < 1) { showFeedback('info', 'The tank is almost empty', [{ tag: '💧 ', text: 'Wait for the rain to refill the tank.' }], 5); return; }
    ch1.total -= d; player.bucketLitres = d; player.hasBucket = true; gesture(playerRig); AudioSys.splash();
  }
});
gardenBeds.forEach((b, i) => {
  interactables.push({
    x: b.x, z: b.z, radius: 2.6,
    getPrompt() { return (ch1.state === 'active' && ch1.stage === 3 && b.have < b.need - 0.01) ? tx('Press E to water this bed ({h}/{n}L)', { h: b.have.toFixed(0), n: b.need }) : null; },
    interact() {
      if (ch1.state !== 'active' || ch1.stage !== 3 || b.have >= b.need - 0.01) return;
      if (player.bucketLitres < 0.05) { wrongAction('npc1', 'Your bucket is empty.', 'Fill the bucket at the tank (E), then water a bed.', 'Stored rainwater is only useful once it reaches the plants.', 0); return; }
      const add = Math.min(player.bucketLitres, b.need - b.have);
      b.have += add; player.bucketLitres -= add; gesture(playerRig); AudioSys.splash();
      if (b.have >= b.need - 0.01) {
        b.base.material.color.setHex(0x3f9f4a);
        awardSubtask('bed' + i, POINTS.bedWatered, { x: b.x, y: 1, z: b.z }, 'bed watered');
        goodAction('Garden bed fully watered', 'Watering the garden from the tank uses stored rain instead of treated tap water.', 5);
      }
    }
  });
});

function ch1StartStage3() {
  const dm = difficultyMultiplier();
  resetCh1World();
  ch1.state = 'active'; ch1.target = Math.round(50 * dm.target); ch1.total = 24; ch1.valve = false; ch1.valveEver = false;
  gardenBeds.forEach((b) => { b.group.visible = true; b.label.visible = true; b.have = 0; b.base.material.color.setHex(0x7a5a33); });
  ch1.t = 0; ch1.surgeAt = 28; ch1.surge = false; ch1.surgeDone = false; ch1.warned3 = false; ch1.floods = 0; ch1.floodCool = 0;
  player.hasBucket = true; player.bucketLitres = 0;
  valveLabel.visible = true;
  runStart(0, 3);
  updateTankVisual(ch1.total, ch1.target);
  AudioSys.startRain();
  showDialogue(tx('{npc}: "{greet}Stage 3 — A big storm is coming! Open the overflow valve before the surge, then water all three garden beds."', { npc: 'Water Warden', greet: greet() }), 8, 'npc1');
  setObjective('<b>Stage 3/3.</b> Open the overflow valve at the soak-away bed, and water all 3 garden beds from the tank.');
  ch1.hint = () => 'Hint: open the overflow valve at the soak-away bed, and carry bucketfuls from the tank to the garden beds.';
  ch1.waypoint = () => {
    if (!ch1.valveEver && ch1.warned3) return { x: soakAwayMesh.position.x, z: soakAwayMesh.position.z, label: 'Overflow valve' };
    if (player.bucketLitres > 0.05) { const b = gardenBeds.find((bb) => bb.have < bb.need - 0.01); if (b) return { x: b.x, z: b.z, label: 'Garden bed' }; }
    if (!ch1.valveEver) return { x: soakAwayMesh.position.x, z: soakAwayMesh.position.z, label: 'Overflow valve' };
    return { x: tankMesh.position.x, z: tankMesh.position.z, label: 'Storage tank' };
  };
  showBriefing({
    npc: 'Water Warden — Rainwater Harvesting', title: tx('Stage 3 of 3: {t}', { t: 'Storm Manager' }),
    text: 'A big storm is coming! Open the overflow valve at the soak-away BEFORE the surge, and use the stored water: fill your bucket at the tank, then water each garden bed (20L each).',
    points: [tx('+{n} points for each garden bed fully watered', { n: POINTS.bedWatered }), tx('+{n} points for opening the overflow valve before the surge', { n: POINTS.valveOpened }),
      tx('+{n} points for completing the stage', { n: POINTS.stageComplete }), tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points each time the tank floods with the valve closed', { n: POINTS.flood }), tx('Penalty: −{n} points if time runs out', { n: POINTS.timeUp }),
      tx('Paid once per stage — replays are practice.')],
    controls: 'E at the tank: fill your bucket • E at a garden bed: water it • E at the soak-away: open / close the overflow valve • WASD / arrows: move • Z / X: rotate camera',
    practice: run.practice
  });
}

function updateCh1Stage3(dt) {
  ch1.t += dt;
  if (!ch1.warned3 && ch1.t >= ch1.surgeAt - 6) { ch1.warned3 = true; showDialogue('Storm surge in 6 seconds! Open the overflow valve!', 6, 'npc1'); AudioSys.corrective(); }
  if (!ch1.surge && !ch1.surgeDone && ch1.t >= ch1.surgeAt) { ch1.surge = true; ch1.surgeEnd = ch1.t + 12; FX.flash('rgba(60,90,160,0.25)', 500); }
  if (ch1.surge && ch1.t >= ch1.surgeEnd) { ch1.surge = false; ch1.surgeDone = true; }
  const inflow = 1.3 + (ch1.surge ? 6 : 0);
  ch1.total += inflow * dt;
  ch1.floodCool -= dt;
  if (ch1.total > ch1.target) {
    const over = ch1.total - ch1.target;
    ch1.total = ch1.target;
    if (!ch1.valve && ch1.floodCool <= 0) {
      ch1.floods++; ch1.floodCool = 4; FX.flash('rgba(200,40,40,0.25)', 400);
      wrongAction('npc1', 'The tank is full and the overflow valve is closed — the yard is flooding!', 'Open the overflow valve at the soak-away bed, and use water from the tank.',
        'An open overflow lets a full tank drain safely to a soak-away instead of flooding the yard.', POINTS.flood);
      if (ch1.floods >= 3) { ch1Fail({ status: 'Failed (flooded)', title: 'The yard flooded!', message: 'The tank overflowed with the valve closed three times.', why: 'Every tank needs a safe overflow route — plan before the storm.' }); return; }
    }
  }
  updateTankVisual(ch1.total, ch1.target);
  valveLabel.userData.setText(tx('Overflow valve: {v}', { v: tx(ch1.valve ? 'OPEN' : 'CLOSED') }));
  gardenBeds.forEach((b) => b.label.userData.setText(tx('Bed {h}/{n}L', { h: b.have.toFixed(0), n: b.need })));
  bucketMesh.visible = true;
  bucketMesh.position.set(player.x + Math.cos(player.facing + 1) * 0.5, 0.55, player.z + Math.sin(player.facing + 1) * 0.5);
  bucketMesh.material.color.setHex(player.bucketLitres > 0.05 ? 0x3fa6ff : 0xf2c81c);
  const done = gardenBeds.filter((b) => b.have >= b.need - 0.01).length;
  setInventory(tx('Tank: {t}/{c}L | Bucket: {b}L | Beds watered: {d}/3 | Valve: {v}', { t: ch1.total.toFixed(1), c: ch1.target, b: player.bucketLitres.toFixed(1), d: done, v: tx(ch1.valve ? 'OPEN' : 'CLOSED') }));
  if (done === 3 && ch1.valveEver) {
    ch1Complete({ message: 'You watered all three beds from the tank and kept the yard from flooding.', stats: metricStats([{ label: 'Beds watered', value: '3/3' }, { label: 'Floods', value: String(ch1.floods) }]),
      why: 'Using stored rainwater for the garden saves tap water, and an open overflow route keeps a storm from flooding your yard.', home: 'point your gutter overflow at a garden bed or gravel soak-away, away from the walls.' });
  }
}

function updateCh1(dt) {
  if (ch1.state !== 'active') return;
  if (ch1.stage === 1) updateCh1Stage1(dt);
  else if (ch1.stage === 2) updateCh1Stage2(dt);
  else updateCh1Stage3(dt);
}

function setTimerHud(left, limit, elapsedStyle) {
  timerEl.classList.remove('hidden');
  const danger = left <= 10, warn = left <= 20 && !danger;
  timerEl.className = 'hud hud-timer' + (warn ? ' warn' : '') + (danger ? ' danger' : '');
  el('timer-label').textContent = tx('TIME LEFT');
  el('timer-value').textContent = fmtTime(Math.max(0, left));
  if (danger) { const w = Math.ceil(left); if (w !== lastTick && w > 0) { lastTick = w; AudioSys.tick(); } } else lastTick = -1;
}
let lastTick = -1;

/* ============================================================================
   CHALLENGE 2 — Greywater Reuse
   Stage 1: Pipe Connection — route pipe from sink to garden (unchanged core).
   Stage 2: Source Sorting — test 4 water sources, decide reuse vs sewer, fit
            filter traps on reused water.
   Stage 3: Diversion Valve — switch a valve in time as loads flow past.
   ============================================================================ */

const CH2_COLS = 5, CH2_ROWS = 3, CH2_CELL = 3.6;
const ch2 = { state: 'idle', stage: 1, retries: 0, grid: [], budget: 0, qualityFlag: 'safe' };

function ch2Budget() {
  const dm = difficultyMultiplier();
  const base = CH2_COLS - 1 + 2;
  return Math.max(3, Math.round(base * dm.budget));
}

const gridOriginX = ZONE2.x - ((CH2_COLS - 1) * CH2_CELL) / 2;
const gridOriginZ = ZONE2.z - 6;

const sinkMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 0.6, 16), new THREE.MeshStandardMaterial({ color: 0x2559d9 }));
sinkMesh.position.set(gridOriginX, 0.3, gridOriginZ);
scene.add(sinkMesh);
scene.add((() => { const l = makeLabel('Sink (Source)'); l.position.set(gridOriginX, 1.6, gridOriginZ); return l; })());
const gardenMesh = new THREE.Mesh(new THREE.ConeGeometry(0.9, 1.1, 8), new THREE.MeshStandardMaterial({ color: 0x6b4a2a }));
gardenMesh.position.set(gridOriginX + (CH2_COLS - 1) * CH2_CELL, 0.55, gridOriginZ);
scene.add(gardenMesh);
scene.add((() => { const l = makeLabel('Garden (Destination)'); l.position.set(gridOriginX + (CH2_COLS - 1) * CH2_CELL, 1.9, gridOriginZ); return l; })());
const sewerMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.1, 16), new THREE.MeshStandardMaterial({ color: 0x4a4a4a }));
sewerMesh.position.set(gridOriginX + (CH2_COLS - 1) * CH2_CELL, 0.05, gridOriginZ + (0 - 1) * CH2_CELL);
scene.add(sewerMesh);
scene.add((() => { const l = makeLabel('Sewer (Unsafe Loads)'); l.position.set(sewerMesh.position.x, 1.4, sewerMesh.position.z); return l; })());

for (let r = 0; r < CH2_ROWS; r++) {
  for (let c = 0; c < CH2_COLS; c++) {
    const x = gridOriginX + c * CH2_CELL, z = gridOriginZ + (r - 1) * CH2_CELL;
    const isSource = c === 0 && r === 1, isDest = c === CH2_COLS - 1 && r === 1, isSewerDest = c === CH2_COLS - 1 && r === 0;
    const pad = new THREE.Mesh(new THREE.BoxGeometry(CH2_CELL * 0.85, 0.08, CH2_CELL * 0.85), new THREE.MeshStandardMaterial({ color: 0x7a6142 }));
    pad.position.set(x, 0.04, z); scene.add(pad);
    const pipe = new THREE.Mesh(new THREE.BoxGeometry(CH2_CELL * 0.5, 0.3, CH2_CELL * 0.5), new THREE.MeshStandardMaterial({ color: 0xb0b6bd }));
    pipe.position.set(x, 0.15, z); pipe.visible = isSource || isDest || isSewerDest; scene.add(pipe);
    const trapMesh = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.09, 8, 14), new THREE.MeshStandardMaterial({ color: 0x3fbf6f }));
    trapMesh.rotation.x = Math.PI / 2; trapMesh.position.set(x, 0.3, z); trapMesh.visible = false; scene.add(trapMesh);
    const cell = { r, c, x, z, hasPipe: isSource || isDest || isSewerDest, isSource, isDest, isSewerDest, isTrap: false, trapMesh, pipeMesh: pipe };
    ch2.grid.push(cell);
    if (!isSource && !isDest && !isSewerDest) {
      interactables.push({
        x, z, radius: CH2_CELL * 0.6,
        getPrompt() {
          if (ch2.state !== 'active' || ch2.stage !== 1) return null;
          if (cell.hasPipe) return tx('Press E to remove pipe (refunds 1 segment)');
          return ch2.budget > 0 ? tx('Press E to place pipe ({n} left)', { n: ch2.budget }) : tx('Out of pipe segments — remove one elsewhere first');
        },
        interact() {
          if (ch2.state !== 'active' || ch2.stage !== 1) return;
          if (!cell.hasPipe) {
            if (ch2.budget <= 0) { wrongAction('npc2', 'You are out of pipe segments.', 'Remove a segment from a wasted part of your route and reuse it.', 'Pipe is limited, so the shortest sensible route wastes the least.', 0); return; }
            ch2.budget--;
          } else { ch2.budget++; if (cell.isTrap) { cell.isTrap = false; cell.trapMesh.visible = false; } }
          cell.hasPipe = !cell.hasPipe; cell.pipeMesh.visible = cell.hasPipe;
          gesture(playerRig); AudioSys.pipePlace(); updateCh2Hud(); checkCh2Path();
        }
      });
    }
  }
}

function ch2Neighbors(cell) { return ch2.grid.filter((o) => o !== cell && ((o.r === cell.r && Math.abs(o.c - cell.c) === 1) || (o.c === cell.c && Math.abs(o.r - cell.r) === 1))); }
function ch2Bfs(source, target) {
  const visited = new Map([[source, null]]); const queue = [source];
  while (queue.length) {
    const cur = queue.shift();
    if (cur === target) { const path = []; let node = target; while (node) { path.unshift(node); node = visited.get(node); } return path; }
    if (cur.isDest || cur.isSewerDest) continue;
    for (const n of ch2Neighbors(cur)) if (n.hasPipe && !visited.has(n)) { visited.set(n, cur); queue.push(n); }
  }
  return null;
}
function checkCh2Path() {
  const source = ch2.grid.find((c) => c.isSource), gardenCell = ch2.grid.find((c) => c.isDest), sewerCell = ch2.grid.find((c) => c.isSewerDest);
  const target = gardenCell;
  const path = ch2Bfs(source, target);
  if (path) { ch2.solvedPath = path; ch2Complete(); }
}

const flowMarker = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 12), new THREE.MeshStandardMaterial({ color: 0x4fb0f0, emissive: 0x1a4a7a, emissiveIntensity: 0.4 }));
flowMarker.position.y = 0.35; flowMarker.visible = false; scene.add(flowMarker);
let flowProgress = 0;
function updateCh2Flow(dt) {
  if (ch2.state !== 'complete' || !ch2.solvedPath || ch2.solvedPath.length < 2) return;
  flowMarker.visible = true; flowProgress += dt * 0.6;
  const segments = ch2.solvedPath.length - 1, total = flowProgress % 1, segFloat = total * segments, segIdx = Math.min(segments - 1, Math.floor(segFloat)), segT = segFloat - segIdx;
  const a = ch2.solvedPath[segIdx], b = ch2.solvedPath[segIdx + 1];
  flowMarker.position.x = a.x + (b.x - a.x) * segT; flowMarker.position.z = a.z + (b.z - a.z) * segT;
}

registerNpcInteractable(npc2, 1, () => ch2.state, ch2Start);
attachQuestMarker(npc2, () => ch2.state === 'idle' && !npc2.challengeGiven);

function ch2ResetWorld() {
  ch2.grid.forEach((c) => { if (!c.isSource && !c.isDest && !c.isSewerDest) { c.hasPipe = false; c.pipeMesh.visible = false; c.isTrap = false; c.trapMesh.visible = false; } });
  gardenMesh.scale.set(1, 1, 1); gardenMesh.material.color.set(0x6b4a2a); sewerMesh.material.color.set(0x4a4a4a); flowMarker.visible = false;
}

function ch2Start() {
  if (ch2.stage === 1) ch2StartStage1();
  else if (ch2.stage === 2) ch2StartStage2();
  else ch2StartStage3();
}

function ch2StartStage1() {
  ch2.state = 'active'; ch2.budget = ch2Budget(); ch2.solvedPath = null; ch2ResetWorld();
  runStart(1, 1);
  showDialogue(tx('{npc}: "{greet}Stage 1 — Walk onto a tile and press E to lay a pipe segment. Connect the sink to the garden, no gaps!"', { npc: 'Pipe-Fitter Pete', greet: greet() }), 7, 'npc2');
  setObjective('<b>Stage 1/3.</b> Press E on grid tiles to lay pipe from the sink to the garden. Limited segments — plan a direct route.');
  ch2.hint = () => 'Hint: press E on grid tiles to lay pipe segments connecting the sink to the garden.';
  ch2.waypoint = () => ({ x: gridOriginX + ((CH2_COLS - 1) * CH2_CELL) / 2, z: gridOriginZ, label: 'Pipe grid' });
  updateCh2Hud();
  showBriefing({
    npc: 'Pipe-Fitter Pete — Greywater Reuse', title: tx('Stage 1 of 3: {t}', { t: 'Pipe Connection' }),
    text: 'Press E on the brown grid tiles to lay pipe from the Sink to the Garden. Limited pipe segments, so plan a direct route with no gaps.',
    points: [tx('+{n} points for completing the stage', { n: POINTS.stageComplete }), tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }), tx('Paid once per stage — replays are practice.')],
    controls: 'E on a grid tile: lay / remove a pipe segment • WASD / arrows: move • Z / X: rotate camera', practice: run.practice
  });
}
function updateCh2Hud() { setInventory(tx('Pipe segments remaining: {n}', { n: ch2.budget })); }

function ch2Complete(extra) {
  const stageDone = ch2.stage;
  ch2.state = 'complete'; runStop(); setInventory(null); clearObjective();
  if (ch2.solvedPath) { gardenMesh.material.color.set(0x3fae3f); gardenMesh.scale.set(1.3, 1.6, 1.3); FX.sparkle(gardenMesh.position.clone().setY(1.2)); }
  const res = onChallengeComplete(1, ch2.retries, 50);
  recordHistory('Completed');
  advanceStage('ch2');
  unlockFact('Try this at home: redirect your bath or laundry rinse water (unscented, low-sodium soap) onto the garden instead of down the drain.');
  if (res.guardianNow) showImpactSummary();
  showEndReward(Object.assign({
    title: tx('Stage {n} Complete!', { n: stageDone }),
    message: 'The garden is now irrigated with reused greywater — around 50L/day saved for a typical household.' + (run.practice ? '\n\n' + tx('Practice replay — no new points or badges.') : ''),
    stats: metricStats(), why: 'Reusing safe greywater on the garden saves drinking-quality water for people.',
    home: 'redirect your bath or laundry rinse water (unscented, low-sodium soap) onto the garden instead of down the drain.',
    quizKey: 'ch2', practice: run.practice, stageId: stageKey(1, stageDone), badges: res.badges,
    onDone: () => { ch2ResetWorld(); npc2.challengeGiven = false; ch2.state = 'idle'; ch2.hint = null; ch2.waypoint = null; }
  }, extra || {}));
}
function ch2Fail(opts) {
  ch2.state = 'failed'; ch2.retries++; profile.retries.ch2 = ch2.retries;
  runStop(); setInventory(null); clearObjective(); timerEl.classList.add('hidden'); AudioSys.fail(); FX.flash('rgba(200,40,40,0.28)', 500);
  recordHistory(opts.status);
  showEndReward({
    title: opts.title, success: false, message: opts.message, stats: metricStats(opts.stats || []), why: opts.why,
    quizKey: null, continueLabel: 'Try again',
    onDone: () => { ch2ResetWorld(); npc2.challengeGiven = false; ch2.state = 'idle'; ch2.hint = null; ch2.waypoint = null; }
  });
}

/* --- Stage 2: Source Sorting -------------------------------------------------- */

const SOURCES = [
  { name: 'Bath water', desc: 'Soapy water with a little hair. No chemicals.', reuse: true, why: 'Soap-only water with a filter trap is a good garden resource.' },
  { name: 'Shower water', desc: 'Shampoo rinse with some hair.', reuse: true, why: 'Shower water is gentle greywater — a trap catches the hair.' },
  { name: 'Basin water', desc: 'Hand-washing water with a little soap.', reuse: true, why: 'Light soapy basin water is safe for ornamental plants.' },
  { name: 'Laundry rinse', desc: 'Low-sodium detergent and some lint.', reuse: true, why: 'Low-sodium laundry water is fine for the garden once the lint is trapped.' },
  { name: 'Bleach laundry', desc: 'Whites washed with bleach.', reuse: false, why: 'Bleach harms plants and soil life, so it goes to the sewer.' },
  { name: 'Kitchen sink', desc: 'Cooking grease and food scraps.', reuse: false, why: 'Grease and food scraps clog pipes and soil and feed bacteria.' },
  { name: 'Toilet water', desc: 'Waste water from the toilet (blackwater).', reuse: false, why: 'Blackwater carries dangerous germs and always needs full treatment.' },
  { name: 'Hair-dye rinse', desc: 'Chemical dye and harsh conditioner.', reuse: false, why: 'Dyes and strong chemicals can poison plants and soil.' }
];
const ch2Sources = [];
for (let i = 0; i < 4; i++) {
  const sx = ZONE2.x - 15 + i * 10, sz = ZONE2.z - 20;
  const g = new THREE.Group(); g.position.set(sx, 0, sz);
  const post = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.6, 0.9), new THREE.MeshStandardMaterial({ color: 0x4a86a8 })); post.position.y = 0.8; g.add(post);
  const trap = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.9), new THREE.MeshStandardMaterial({ color: 0xe8a83a })); trap.position.set(0, 0.5, 1.3); trap.visible = false; g.add(trap);
  g.visible = false; scene.add(g);
  const label = makeDynamicLabel('Source'); label.position.set(sx, 2.6, sz); label.visible = false; scene.add(label);
  ch2Sources.push({ group: g, trap, label, x: sx, z: sz });
}
ch2Sources.forEach((s, i) => {
  interactables.push({
    x: s.x, z: s.z, radius: 2.6,
    getPrompt() {
      if (ch2.state !== 'active' || ch2.stage !== 2 || !ch2.srcList) return null;
      const e = ch2.srcList[i];
      if (e.resolved) return null;
      if (e.decision === 'reuse') return tx('Press F to fit a filter trap on the {n} line', { n: e.sc.name });
      return tx('Press E to test the {n} • then 1 = reuse on garden, 2 = send to sewer', { n: e.sc.name });
    },
    interact() {
      if (ch2.state !== 'active' || ch2.stage !== 2 || !ch2.srcList) return;
      const e = ch2.srcList[i];
      if (e.resolved || e.decision === 'reuse') return;
      showFeedback('info', e.sc.name, [{ tag: '🧪 ' + tx('Sample:') + ' ', text: e.sc.desc }, { tag: '❓ ' + tx('Decide:') + ' ', text: tx('Press 1 to reuse it on the garden, or 2 to send it to the sewer.') }], 9);
      AudioSys.pickup();
    }
  });
});
function ch2SourceKey(k) {
  if (!ch2.srcList) return;
  const list = ch2.srcList;
  const idx = (ch2.lastTestedSrc != null) ? ch2.lastTestedSrc : nearestCh2Source();
  if (idx == null) return;
  const i = idx, e = list[i];
  if (e.resolved) return;
  if (k === 'f') {
    if (e.decision === 'reuse' && !e.trapped) {
      e.trapped = true; e.resolved = true; ch2Sources[i].trap.visible = true;
      gesture(playerRig); AudioSys.pipePlace();
      awardSubtask('trap' + i, POINTS.filterTrap, { x: ch2Sources[i].x, y: 1, z: ch2Sources[i].z }, 'filter trap');
      ch2Sources[i].label.userData.setText('✔ ' + e.sc.name + ' → GARDEN');
      goodAction('Filter trap fitted', 'A lint/hair trap stops solids clogging the pipe and building up in the garden soil.', 5);
    } else {
      wrongAction('npc2', 'A filter trap only belongs on water that is going to the garden.', 'First press 1 to reuse this water on the garden, then fit the trap with F.', 'Water headed for the sewer needs no trap.', 4);
    }
    ch2CheckSourcesDone();
    return;
  }
  if (k !== '1' && k !== '2') return;
  const choice = k === '1' ? 'reuse' : 'sewer', right = e.sc.reuse ? 'reuse' : 'sewer';
  if (choice === right) {
    gesture(playerRig); AudioSys.pickup();
    awardSubtask('src' + i, POINTS.sourceSorted, { x: ch2Sources[i].x, y: 1, z: ch2Sources[i].z }, 'right call');
    if (choice === 'reuse') { e.decision = 'reuse'; ch2Sources[i].label.userData.setText('➜ ' + e.sc.name + ' — fit trap (F)'); goodAction('Right call — reuse it on the garden', e.sc.why, 6); }
    else { e.decision = 'sewer'; e.resolved = true; ch2Sources[i].label.userData.setText('✔ ' + e.sc.name + ' → SEWER'); goodAction('Right call — send it to the sewer', e.sc.why, 6); }
    ch2CheckSourcesDone();
  } else {
    wrongAction('npc2', tx(choice === 'reuse' ? '{n} should NOT be reused on the garden.' : '{n} is safe to reuse — it should not go to the sewer.', { n: e.sc.name }),
      choice === 'reuse' ? 'Press 2 to send it to the sewer.' : 'Press 1 to reuse it on the garden, then fit a filter trap.', e.sc.why, POINTS.wrongSource);
  }
}
function nearestCh2Source() {
  let best = null, bd = Infinity;
  ch2Sources.forEach((s, i) => { const d = dist2D(player.x, player.z, s.x, s.z); if (d < 3 && d < bd) { bd = d; best = i; } });
  return best;
}
function ch2CheckSourcesDone() {
  if (ch2.state === 'active' && ch2.stage === 2 && ch2.srcList && ch2.srcList.every((e) => e.resolved)) {
    ch2Complete({ message: 'You sorted every source correctly: soapy water goes to the garden with a filter trap, harsh water goes to the sewer.',
      stats: metricStats([{ label: 'Sources sorted', value: ch2.srcList.length + '/' + ch2.srcList.length }]),
      why: 'Knowing what is in the water decides where it can go — and a filter trap protects pipes and soil.', home: 'use low-sodium, biodegradable soap if you reuse water on plants.' });
  }
}

function ch2StartStage2() {
  const good = _shuffle(SOURCES.filter((s) => s.reuse)).slice(0, 2), bad = _shuffle(SOURCES.filter((s) => !s.reuse)).slice(0, 2);
  ch2.srcList = _shuffle(good.concat(bad)).map((sc) => ({ sc, decision: null, trapped: false, resolved: false }));
  ch2.state = 'active'; ch2ResetWorld();
  ch2Sources.forEach((s, i) => { s.group.visible = true; s.label.visible = true; s.trap.visible = false; s.label.userData.setText(ch2.srcList[i].sc.name); });
  runStart(1, 2);
  showDialogue(tx('{npc}: "{greet}Stage 2 — Test four water sources, decide reuse or sewer, and fit filter traps on reused water!"', { npc: 'Pipe-Fitter Pete', greet: greet() }), 8, 'npc2');
  setObjective('<b>Stage 2/3.</b> Test each source (E). Press 1 to reuse it on the garden, or 2 for the sewer — then fit a filter trap (F) on reused water.');
  ch2.hint = () => 'Hint: soapy bath, shower and basin water can be reused; grease, bleach, dye and toilet water must go to the sewer.';
  ch2.waypoint = () => { const i = ch2.srcList.findIndex((e) => !e.resolved); return i >= 0 ? { x: ch2Sources[i].x, z: ch2Sources[i].z, label: 'Water source' } : null; };
  unlockFact('Real technique: greywater systems include a simple lint/hair trap (or mesh filter) before water reaches the garden, preventing clogging and buildup of organic debris.');
  showBriefing({
    npc: 'Pipe-Fitter Pete — Greywater Reuse', title: tx('Stage 2 of 3: {t}', { t: 'Source Sorting' }),
    text: 'Four water sources need a decision. Press E at each to test, then 1 to REUSE it on the garden or 2 to send it to the SEWER. Reused water needs a filter trap: press F at that source.',
    points: [tx('+{n} points for each correct reuse / sewer decision', { n: POINTS.sourceSorted }), tx('+{n} points for fitting the filter trap on reused water', { n: POINTS.filterTrap }),
      tx('+{n} points for completing the stage', { n: POINTS.stageComplete }), tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points for each wrong decision', { n: POINTS.wrongSource }), tx('Paid once per stage — replays are practice.')],
    controls: 'E at a source: test the water • 1: reuse on the garden • 2: send to the sewer • F: fit a filter trap on reused water • WASD / arrows: move • Z / X: rotate camera',
    practice: run.practice
  });
}

/* --- Stage 3: Diversion Valve -------------------------------------------------- */

const LOADS = [
  { name: 'Bath water', safe: true, why: 'Safe, soapy greywater is a resource for the garden.' },
  { name: 'Basin water', safe: true, why: 'Light soapy basin water is fine for the garden.' },
  { name: 'Low-sodium laundry', safe: true, why: 'Low-sodium laundry water is safe for ornamental plants.' },
  { name: 'Bleach load', safe: false, why: 'Bleach and harsh chemicals harm plants and soil, so they go to the sewer.' },
  { name: 'Kitchen grease water', safe: false, why: 'Grease clogs pipes and soil and is best treated at the sewer.' },
  { name: 'Paint-rinse water', safe: false, why: 'Paint and solvents are toxic to plants and soil.' }
];
const ch2ValveMesh = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.4, 0.9), new THREE.MeshStandardMaterial({ color: 0xbb5533 }));
const ch2ValveX = gridOriginX + 2 * CH2_CELL, ch2ValveZ = gridOriginZ;
ch2ValveMesh.position.set(ch2ValveX, 0.7, ch2ValveZ + 4.2);
ch2ValveMesh.visible = false; scene.add(ch2ValveMesh);
const ch2ValveLabel = makeDynamicLabel('Valve'); ch2ValveLabel.position.set(ch2ValveX, 2.4, ch2ValveZ + 4.2); ch2ValveLabel.visible = false; scene.add(ch2ValveLabel);
const ch2LoadBlobs = [];
for (let i = 0; i < 6; i++) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 10), new THREE.MeshBasicMaterial({ color: 0x66b8ff })); m.visible = false; scene.add(m);
  const l = makeDynamicLabel('Load'); l.visible = false; scene.add(l);
  ch2LoadBlobs.push({ mesh: m, label: l });
}
interactables.push({
  x: ch2ValveX, z: ch2ValveZ + 4.2, radius: 3,
  getPrompt() { return (ch2.state === 'active' && ch2.stage === 3) ? tx('Press E to switch the valve to {d}  (now: {c})', { d: tx(ch2.dest === 'garden' ? 'SEWER' : 'GARDEN'), c: tx(ch2.dest === 'garden' ? 'GARDEN' : 'SEWER') }) : null; },
  interact() {
    if (ch2.state !== 'active' || ch2.stage !== 3) return;
    ch2.dest = ch2.dest === 'garden' ? 'sewer' : 'garden';
    gesture(playerRig); AudioSys.pipePlace();
    ch2ValveLabel.userData.setText(tx('Valve → {d}', { d: tx(ch2.dest === 'garden' ? 'GARDEN' : 'SEWER') }));
  }
});
function ch2StartStage3() {
  const safe = _shuffle(LOADS.filter((l) => l.safe)), bad = _shuffle(LOADS.filter((l) => !l.safe));
  const seq = _shuffle(safe.concat(bad));
  const level = settings.difficulty;
  ch2.state = 'active'; ch2ResetWorld();
  ch2.seq = seq; ch2.t = 0; ch2.dest = 'garden'; ch2.spawned = 0; ch2.processed = 0; ch2.right = 0; ch2.wrong = 0; ch2.contam = 0; ch2.loads = [];
  ch2.maxWrong = level === 'relaxed' ? 2 : level === 'challenge' ? 0 : 1;
  ch2.maxContam = level === 'relaxed' ? 3 : level === 'challenge' ? 1 : 2;
  ch2ValveMesh.visible = true; ch2ValveLabel.visible = true; ch2ValveLabel.userData.setText(tx('Valve → {d}', { d: tx('GARDEN') }));
  runStart(1, 3);
  showDialogue(tx('{npc}: "{greet}Stage 3 — Loads of used water are coming. Switch the valve to send each one to the right place!"', { npc: 'Pipe-Fitter Pete', greet: greet() }), 8, 'npc2');
  setObjective('<b>Stage 3/3.</b> Switch the valve (E) so every load reaches the right place: safe loads to the garden, harsh loads to the sewer.');
  ch2.hint = () => 'Hint: read the label above each load (✅ safe / ⚠ unsafe) and switch the valve before it reaches the junction.';
  ch2.waypoint = () => ({ x: ch2ValveX, z: ch2ValveZ + 4.2, label: 'Valve' });
  unlockFact('Real technique: a diversion valve lets a household redirect greywater to the sewer instead of the garden whenever the load contains harsh chemicals (like bleach) that could harm plants and soil.');
  showBriefing({
    npc: 'Pipe-Fitter Pete — Greywater Reuse', title: tx('Stage 3 of 3: {t}', { t: 'Diversion Valve' }),
    text: 'Used water flows toward the junction. At the valve, press E to point it at the GARDEN or the SEWER. Safe soapy loads go to the garden; harsh or dirty loads go to the sewer.',
    points: [tx('+{n} points for each load sent to the right place', { n: POINTS.loadRouted }), tx('+{n} points for completing the stage', { n: POINTS.stageComplete }),
      tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points for a safe load sent to the sewer', { n: POINTS.wrongLoad }), tx('Penalty: −{n} points for an unsafe load sent to the garden', { n: POINTS.contaminatedLoad }),
      tx('Paid once per stage — replays are practice.')],
    controls: 'E at the valve: switch between GARDEN and SEWER • WASD / arrows: move • Z / X: rotate camera', practice: run.practice
  });
}
function ch2Judge(ld) {
  const toGarden = ld.dest === 'garden';
  const pos = { x: ld.x, y: 1, z: ld.z };
  if (ld.def.safe === toGarden) {
    ch2.right++;
    awardSubtask('load' + ch2.processed + '_' + ch2.spawned, POINTS.loadRouted, pos, 'right place');
    goodAction(tx(ld.def.safe ? '{n} went to the garden' : '{n} went to the sewer', { n: ld.def.name }), ld.def.why, 4);
  } else if (ld.def.safe) {
    ch2.wrong++;
    wrongAction('npc2', tx('{n} was safe to reuse, but the valve sent it to the sewer.', { n: ld.def.name }), 'Point the valve at the garden for safe soapy loads.', ld.def.why, POINTS.wrongLoad);
  } else {
    ch2.wrong++; ch2.contam++;
    gardenMesh.material.color.set(0xb02a2a);
    setTimeout(() => gardenMesh.material.color.set(0x6b4a2a), 1500);
    wrongAction('npc2', tx('{n} is unsafe, but the valve sent it to the garden!', { n: ld.def.name }), 'Point the valve at the sewer for harsh or dirty loads.', ld.def.why, POINTS.contaminatedLoad);
    if (ch2.contam >= ch2.maxContam) ch2Fail({ status: 'Failed (garden contaminated)', title: 'Garden contaminated!', message: 'Too many unsafe loads reached the garden.', why: 'Chemicals and dirty water in the garden can damage soil life and plants.' });
  }
}
function updateCh2Stage3(dt) {
  ch2.t += dt;
  const x0 = gridOriginX, z0 = gridOriginZ, gx = gridOriginX + 4 * CH2_CELL, sz = gridOriginZ - CH2_CELL;
  if (ch2.spawned < 6 && ch2.t >= 2 + ch2.spawned * 7.5) {
    const ld = { def: ch2.seq[ch2.spawned], blob: ch2LoadBlobs[ch2.spawned], x: x0, z: z0, phase: 'flow', dest: null };
    ld.blob.mesh.material.color.setHex(ld.def.safe ? 0x66b8ff : 0xd04a3a);
    ld.blob.label.userData.setText((ld.def.safe ? '✅ ' : '⚠ ') + ld.def.name);
    ld.blob.mesh.visible = true; ld.blob.label.visible = true;
    ch2.loads.push(ld); ch2.spawned++;
    showDialogue(tx(ld.def.safe ? 'A safe load is coming: {n}.' : 'Careful — an unsafe load is coming: {n}!', { n: ld.def.name }), 3);
  }
  ch2.loads.forEach((ld) => {
    if (ld.phase === 'gone') return;
    if (ld.phase === 'flow') {
      ld.x += 1.8 * dt;
      if (ld.x >= ch2ValveX) { ld.x = ch2ValveX; ld.phase = 'exit'; ld.dest = ch2.dest; ch2Judge(ld); }
    } else if (ld.phase === 'exit') {
      const tx1 = gx, tz1 = ld.dest === 'garden' ? z0 : sz;
      const dx = tx1 - ld.x, dz = tz1 - ld.z, d = Math.hypot(dx, dz), stp = 3.6 * dt;
      if (d <= stp) { ld.phase = 'gone'; ld.blob.mesh.visible = false; ld.blob.label.visible = false; ch2.processed++; }
      else { ld.x += (dx / d) * stp; ld.z += (dz / d) * stp; }
    }
    ld.blob.mesh.position.set(ld.x, 0.9, ld.z); ld.blob.label.position.set(ld.x, 2.4, ld.z);
  });
  if (ch2.state !== 'active') return;
  setInventory(tx('Loads handled: {a}/6 | Right: {r} | Wrong: {w}/{m} | Valve → {d}', { a: ch2.processed, r: ch2.right, w: ch2.wrong, m: ch2.maxWrong + 1, d: tx(ch2.dest === 'garden' ? 'GARDEN' : 'SEWER') }));
  if (ch2.processed >= 6) {
    if (ch2.wrong <= ch2.maxWrong) {
      ch2Complete({ message: tx('You routed {n} of 6 loads correctly.', { n: ch2.right }), stats: metricStats([{ label: 'Loads routed correctly', value: ch2.right + '/6' }]),
        why: 'A diversion valve lets a household keep reusing safe greywater while sending harmful loads to the sewer for treatment.', home: 'keep bleach and chemical cleaning water separate from the water you reuse.' });
    } else {
      ch2Fail({ status: 'Failed (too many wrong loads)', title: 'Too many wrong loads', message: 'Too many loads went to the wrong place.', why: 'Sending unsafe water to the garden harms plants and soil; sending safe water to the sewer wastes a resource.' });
    }
  }
}

function updateCh2(dt) {
  updateCh2Flow(dt);
  if (ch2.state === 'active' && ch2.stage === 3) updateCh2Stage3(dt);
}

/* ============================================================================
   CHALLENGE 3 — Filtration System
   Stage 1: Build & Filter — manually select and install layers in the right
            order (coarse → fine → gravel), then filter river water.
   Stage 2: Disinfection Bench — match a scenario to the right treatment.
   Stage 3: Fault Finder — diagnose and fix a broken filter.
   ============================================================================ */

const ch3 = { state: 'idle', stage: 1, retries: 0 };

function makePile(x, z, color, label) {
  const mesh = new THREE.Mesh(new THREE.ConeGeometry(0.9, 0.9, 10), new THREE.MeshStandardMaterial({ color }));
  mesh.position.set(x, 0.45, z); scene.add(mesh);
  const l = makeLabel(label); l.position.set(x, 1.6, z); scene.add(l);
  return mesh;
}
const pileCoarse = makePile(ZONE3.x - 10, ZONE3.z - 4, 0xc2a06b, 'Coarse Sand');
const pileFine = makePile(ZONE3.x - 10, ZONE3.z + 4, 0xe8d9a0, 'Fine Sand');
const pileGravel = makePile(ZONE3.x + 10, ZONE3.z - 4, 0x8a8a8a, 'Gravel');
const ch3Piles = { coarse: pileCoarse, fine: pileFine, gravel: pileGravel };

const riverPond = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 0.1, 20), new THREE.MeshStandardMaterial({ color: 0x6b5230, transparent: true, opacity: 0.9 }));
riverPond.position.set(ZONE3.x + 10, 0.06, ZONE3.z + 6);
scene.add(riverPond);
scene.add((() => { const l = makeLabel('Muddy River'); l.position.set(riverPond.position.x, 1.4, riverPond.position.z); return l; })());

const potGroup = new THREE.Group();
potGroup.position.set(ZONE3.x, 0, ZONE3.z - 12);
scene.add(potGroup);
function makePot(y, radiusTop) {
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(radiusTop, radiusTop * 0.85, 0.9, 16, 1, true), new THREE.MeshStandardMaterial({ color: 0x8b6a4a, side: THREE.DoubleSide }));
  pot.position.y = y; potGroup.add(pot); return pot;
}
makePot(2.2, 1.1); makePot(1.1, 0.95); makePot(0.15, 0.8);
const layerCoarseMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.15, 16), new THREE.MeshStandardMaterial({ color: 0xc2a06b }));
layerCoarseMesh.position.set(0, 1.9, 0); layerCoarseMesh.visible = false; potGroup.add(layerCoarseMesh);
const layerFineMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.15, 16), new THREE.MeshStandardMaterial({ color: 0xe8d9a0 }));
layerFineMesh.position.set(0, 2.15, 0); layerFineMesh.visible = false; potGroup.add(layerFineMesh);
const layerGravelMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.2, 16), new THREE.MeshStandardMaterial({ color: 0x8a8a8a }));
layerGravelMesh.position.set(0, 0.9, 0); layerGravelMesh.visible = false; potGroup.add(layerGravelMesh);
const inputWaterMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, 0.5, 16), new THREE.MeshStandardMaterial({ color: 0x6b5230, transparent: true, opacity: 0.88 }));
inputWaterMesh.position.set(0, 2.55, 0); inputWaterMesh.visible = false; potGroup.add(inputWaterMesh);
const outputWater = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.05, 16), new THREE.MeshStandardMaterial({ color: 0x6b5230, transparent: true, opacity: 0.9 }));
outputWater.position.set(0, 0.05, 0); potGroup.add(outputWater);
const layerMeshByKey = { coarse: layerCoarseMesh, fine: layerFineMesh, gravel: layerGravelMesh };
const MURKY_COLOR = new THREE.Color(0x6b5230), CLEAR_COLOR = new THREE.Color(0x4aa8e8);
const START_TURBIDITY = 220, TARGET_TURBIDITY = 4;

const MATERIALS = { coarse: { name: 'Coarse Sand', key: '1' }, fine: { name: 'Fine Sand', key: '2' }, gravel: { name: 'Gravel', key: '3' } };
const MATERIAL_WHY = {
  coarse: 'Coarse sand goes in first as the base layer: it supports the finer sand above it and lets water drain through without washing it away.',
  fine: 'Fine sand goes on top of the coarse sand: its tiny gaps trap the small particles and microbes that make river water cloudy.',
  gravel: 'Gravel goes in last, below the sand: it supports the sand layers and lets clean water drain into the collection pot without clogging.'
};
const ORDER_TEXT = 'Coarse Sand → Fine Sand → Gravel';

interactables.push({
  x: riverPond.position.x, z: riverPond.position.z, radius: 2.8,
  getPrompt() { return (ch3.state === 'active' && ch3.stage === 1 && !ch3.inventory.riverWater) ? tx('Press E to collect unfiltered river water') : null; },
  interact() { if (ch3.state !== 'active' || ch3.stage !== 1 || ch3.inventory.riverWater) return; ch3.inventory.riverWater = true; gesture(playerRig); AudioSys.splash(); updateCh3Hud(); }
});
[['coarse', pileCoarse], ['fine', pileFine], ['gravel', pileGravel]].forEach(([key, mesh]) => {
  interactables.push({
    x: mesh.position.x, z: mesh.position.z, radius: 2.2,
    getPrompt() { return (ch3.state === 'active' && ch3.stage === 1 && !ch3.inventory[key] && !ch3.installed[key]) ? tx('Press E to collect {n}', { n: MATERIALS[key].name }) : null; },
    interact() {
      if (ch3.state !== 'active' || ch3.stage !== 1 || ch3.inventory[key] || ch3.installed[key]) return;
      ch3.inventory[key] = true; ch3.selected = key; gesture(playerRig); AudioSys.pickup(); updateCh3Hud();
    }
  });
});

function ch3AllInstalled() { return ['coarse', 'fine', 'gravel'].every((k) => ch3.installed[k]); }
interactables.push({
  x: potGroup.position.x, z: potGroup.position.z, radius: 3,
  getPrompt() {
    if (ch3.state !== 'active' || ch3.stage !== 1) return null;
    if (ch3.filtering) return null;
    if (!ch3AllInstalled()) {
      const m = MATERIALS[ch3.selected];
      return (ch3.inventory[ch3.selected] && !ch3.installed[ch3.selected]) ? tx('Press E to install {m} (1/2/3 to choose)', { m: m.name }) : tx('Selected: {m} — press 1/2/3 to choose a collected material', { m: m.name });
    }
    return tx('Press E to pour in the river water');
  },
  interact() {
    if (ch3.state !== 'active' || ch3.stage !== 1 || ch3.filtering) return;
    if (!ch3AllInstalled()) { ch3TryInstall(ch3.selected); return; }
    if (!ch3.inventory.riverWater) { wrongAction('npc3', 'The filter is built, but you have no river water yet.', 'Walk to the Muddy River and collect some.', 'A filter is tested with real unfiltered water.', 0); return; }
    ch3.inventory.riverWater = false; ch3StartFiltering();
  }
});
function ch3TryInstall(key) {
  const m = MATERIALS[key];
  if (ch3.installed[key]) { wrongAction('npc3', tx('{m} is already installed.', { m: m.name }), 'Choose a different material with 1/2/3.', 'Each layer goes in once.', 0); return; }
  if (!ch3.inventory[key]) { wrongAction('npc3', tx("You haven't collected {m} yet.", { m: m.name }), tx('Collect it from its pile (E), then select it with {k}.', { k: m.key }), 'A filter can only be built from materials you have gathered.', 0); return; }
  const expected = ['coarse', 'fine', 'gravel'].find((k) => !ch3.installed[k]);
  if (key !== expected) {
    ch3.layerMistakes++;
    const left = ch3.maxLayerMistakes - ch3.layerMistakes;
    wrongAction('npc3', tx("{m} can't go in yet — that is the wrong order.", { m: m.name }), tx('The correct order is {o}. Install {n} next.', { o: ORDER_TEXT, n: MATERIALS[expected].name }),
      MATERIAL_WHY[expected] + (left > 0 ? '  (' + left + ' wrong-order attempts left before this build fails.)' : ''), POINTS.wrongLayer);
    updateCh3Hud();
    if (ch3.layerMistakes >= ch3.maxLayerMistakes) ch3Fail();
    return;
  }
  ch3.installed[key] = true; ch3.inventory[key] = false; layerMeshByKey[key].visible = true;
  gesture(playerRig); AudioSys.pipePlace();
  awardSubtask('layer_' + key, POINTS.layer, { x: potGroup.position.x, y: 2, z: potGroup.position.z }, m.name);
  goodAction(tx('{m} installed in the right order', { m: m.name }), MATERIAL_WHY[key], 6);
  const next = ['coarse', 'fine', 'gravel'].find((k) => !ch3.installed[k]);
  if (next) ch3.selected = next;
  updateCh3Hud();
}
function handleSelectKey() {
  if (!selectKeyJustPressed) return;
  const k = selectKeyJustPressed; selectKeyJustPressed = null;
  if (ch3.state === 'active' && ch3.stage === 1) { ch3.selected = { '1': 'coarse', '2': 'fine', '3': 'gravel' }[k]; AudioSys.pickup(); updateCh3Hud(); }
  else if (ch2.state === 'active' && ch2.stage === 2) ch2SourceKey(k);
}

registerNpcInteractable(npc3, 2, () => ch3.state, ch3Start);
attachQuestMarker(npc3, () => ch3.state === 'idle' && !npc3.challengeGiven);

function ch3ResetWorld() {
  layerCoarseMesh.visible = false; layerFineMesh.visible = false; layerGravelMesh.visible = false;
  inputWaterMesh.visible = false; inputWaterMesh.scale.y = 1; outputWater.scale.y = 1; outputWater.material.color.copy(MURKY_COLOR);
}

function ch3Start() {
  if (ch3.stage === 1) ch3StartStage1();
  else if (ch3.stage === 2) ch3StartStage2();
  else ch3StartStage3();
}

function ch3StartStage1() {
  ch3.state = 'active'; ch3.inventory = { coarse: false, fine: false, gravel: false, riverWater: false };
  ch3.installed = { coarse: false, fine: false, gravel: false }; ch3.selected = 'coarse'; ch3.layerMistakes = 0;
  ch3.maxLayerMistakes = settings.difficulty === 'relaxed' ? 3 : settings.difficulty === 'challenge' ? 1 : 2;
  ch3.filtering = false; ch3.filterProgress = 0;
  ch3ResetWorld();
  runStart(2, 1);
  showDialogue(tx('{npc}: "{greet}Stage 1 — Collect the materials, choose each one with 1, 2 or 3 and install it in the right order, then fetch river water to test it!"', { npc: 'Filter Fundi', greet: greet() }), 8, 'npc3');
  updateCh3Hud();
  ch3.hint = () => ch3AllInstalled() ? (ch3.inventory.riverWater ? 'Hint: pour the river water into the filter station.' : 'Hint: fetch river water from the Muddy River.') : 'Hint: collect materials from the piles (E), choose one with 1/2/3, then install it at the filter station.';
  ch3.waypoint = () => {
    if (!ch3AllInstalled()) { const need = ['coarse', 'fine', 'gravel'].find((k) => !ch3.inventory[k] && !ch3.installed[k]); if (need) return { x: ch3Piles[need].position.x, z: ch3Piles[need].position.z, label: MATERIALS[need].name + ' pile' }; return { x: potGroup.position.x, z: potGroup.position.z, label: 'Filter station' }; }
    if (!ch3.inventory.riverWater) return { x: riverPond.position.x, z: riverPond.position.z, label: 'Muddy River' };
    return { x: potGroup.position.x, z: potGroup.position.z, label: 'Filter station' };
  };
  showBriefing({
    npc: 'Filter Fundi — Filtration System', title: tx('Stage 1 of 3: {t}', { t: 'Build & Filter' }),
    text: tx('Collect coarse sand, fine sand and gravel, then build the filter: choose a material with 1 / 2 / 3 and press E at the filter station. The order is {o}. Wrong order costs points, and {n} mistakes fail the build.', { o: ORDER_TEXT, n: ch3.maxLayerMistakes }),
    points: [tx('+{n} points for each layer installed in the correct order (+{t} in total)', { n: POINTS.layer, t: POINTS.layer * 3 }), tx('+{n} points for collecting the river water', { n: POINTS.riverWater }),
      tx('+{n} points for completing the stage', { n: POINTS.stageComplete }), tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points for each layer installed in the wrong order', { n: POINTS.wrongLayer }), tx('Paid once per stage — replays are practice.')],
    controls: 'E at a pile / the river: collect • 1/2/3: choose Coarse Sand / Fine Sand / Gravel • E at the filter station: install or pour • WASD / arrows: move • Z / X: rotate camera',
    practice: run.practice
  });
}
function updateCh3Hud() {
  if (ch3.filtering) {
    const ntu = Math.round(START_TURBIDITY - (START_TURBIDITY - TARGET_TURBIDITY) * Math.min(1, ch3.filterProgress));
    setInventory(tx('Filtering river water... Turbidity: {n} NTU (illustrative) — WHO safe guideline is under 5 NTU', { n: ntu }));
  } else {
    const mats = ['coarse', 'fine', 'gravel'].map((k) => {
      const m = MATERIALS[k], state = ch3.installed[k] ? '✔' : ch3.inventory[k] ? '✓' : '◻';
      return `<span class="mat${ch3.selected === k ? ' sel' : ''}">[${m.key}] ${m.name} ${state}</span>`;
    }).join(' &nbsp; ');
    setInventory(`${mats}<br>${ch3.inventory.riverWater ? '✓' : '◻'} River Water &nbsp;•&nbsp; Wrong-order: ${ch3.layerMistakes}/${ch3.maxLayerMistakes}`);
  }
}
function ch3StartFiltering() {
  ch3.filtering = true; ch3.filterProgress = 0; inputWaterMesh.visible = true;
  AudioSys.splash(); FX.splash(inputWaterMesh.position.clone().setY(1.2));
  showDialogue('Filter Fundi pours in the unfiltered river water — watch the turbidity drop!', 4, 'npc3');
}
function ch3Complete(extra) {
  const stageDone = 1;
  ch3.state = 'complete'; ch3.filtering = false; runStop(); setInventory(null); clearObjective(); timerEl.classList.add('hidden');
  const res = onChallengeComplete(2, ch3.retries, 20);
  recordHistory('Completed'); advanceStage('ch3');
  unlockFact('Try this at home: if your area has a boil-water advisory, remember filtering reduces particles but you should still disinfect before drinking.');
  if (res.guardianNow) showImpactSummary();
  showEndReward(Object.assign({
    title: tx('Stage {n} Complete!', { n: stageDone }),
    message: tx('Your 3-pot slow sand filter dropped turbidity from ~{a} NTU to {b} NTU — within the WHO guideline.', { a: START_TURBIDITY, b: TARGET_TURBIDITY }) + (run.practice ? '\n\n' + tx('Practice replay — no new points or badges.') : ''),
    stats: metricStats([{ label: 'Wrong-order attempts', value: ch3.layerMistakes + '/' + ch3.maxLayerMistakes }]),
    why: `Layering ${ORDER_TEXT} lets water pass through progressively finer material, removing cloudiness and microbes.`,
    home: 'if your area has a boil-water advisory, remember filtering reduces particles but you should still disinfect before drinking.',
    quizKey: 'ch3', practice: run.practice, stageId: stageKey(2, stageDone), badges: res.badges,
    onDone: () => { ch3ResetWorld(); npc3.challengeGiven = false; ch3.state = 'idle'; ch3.hint = null; ch3.waypoint = null; }
  }, extra || {}));
}
function ch3Fail() {
  ch3.state = 'failed'; ch3.filtering = false; ch3.retries++; profile.retries.ch3 = ch3.retries;
  runStop(); setInventory(null); clearObjective(); timerEl.classList.add('hidden'); AudioSys.fail(); FX.flash('rgba(200,40,40,0.28)', 500);
  recordHistory('Failed (wrong layer order)');
  showEndReward({
    title: 'Filter Build Failed', success: false,
    message: tx("The layers went in the wrong order too many times ({n}), so this filter wouldn't clean the water properly. The correct order is {o}.", { n: ch3.layerMistakes, o: ORDER_TEXT }),
    stats: metricStats([{ label: 'Wrong-order attempts', value: ch3.layerMistakes + '/' + ch3.maxLayerMistakes }]), why: `${MATERIAL_WHY.coarse} ${MATERIAL_WHY.fine} ${MATERIAL_WHY.gravel}`,
    quizKey: null, continueLabel: 'Try again',
    onDone: () => { ch3ResetWorld(); npc3.challengeGiven = false; ch3.state = 'idle'; ch3.hint = null; ch3.waypoint = null; }
  });
}
function updateCh3Stage1(dt) {
  if (!ch3.filtering) return;
  ch3.filterProgress += dt / 4;
  const p = Math.min(1, ch3.filterProgress);
  inputWaterMesh.scale.y = Math.max(0.02, 1 - p); inputWaterMesh.position.y = 2.55 - (1 - inputWaterMesh.scale.y) * 0.25;
  if (p >= 1) inputWaterMesh.visible = false;
  outputWater.scale.y = Math.min(6, 1 + p * 5); outputWater.position.y = 0.05 + (outputWater.scale.y - 1) * 0.025;
  outputWater.material.color.copy(MURKY_COLOR).lerp(CLEAR_COLOR, p);
  updateCh3Hud();
  if (p >= 1) ch3Complete();
}

/* --- Stage 2: Disinfection Bench --------------------------------------------- */

const STATION_IDS = ['tube', 'stove', 'chlor', 'solar'];
const STATION_NAMES = { tube: 'Turbidity tube', stove: 'Boiling stove', chlor: 'Chlorine tablets', solar: 'Solar bottle rack', lid: 'Lid & covers', spare: 'Spare pot' };
const benchStations = {};
STATION_IDS.concat(['lid', 'spare']).forEach((id, i) => {
  const x = ZONE3.x - 20 + i * 8, z = ZONE3.z - 26;
  const g = new THREE.Group(); g.position.set(x, 0, z);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.4, 0.4, 14), new THREE.MeshStandardMaterial({ color: 0x8fb8c9 })); base.position.y = 0.2; g.add(base);
  g.visible = false; scene.add(g);
  const label = makeDynamicLabel(STATION_NAMES[id]); label.position.set(x, 1.8, z); label.visible = false; scene.add(label);
  benchStations[id] = { x, z, group: g, label };
  interactables.push({
    x, z, radius: 2.4,
    getPrompt() {
      if (ch3.state !== 'active' || ch3.stage < 2 || !ch3.workItems) return null;
      const it = ch3.workItems[ch3.wi];
      if (!it) return null;
      const valid = ch3.stage === 2 ? STATION_IDS : ['stove', 'lid', 'spare', 'river', 'filter'];
      if (!valid.includes(id)) return null;
      return tx('Press E to work at the {s}', { s: STATION_NAMES[id] });
    },
    interact() {
      if (ch3.state !== 'active' || ch3.stage < 2 || !ch3.workItems) return;
      const it = ch3.workItems[ch3.wi];
      if (!it) return;
      if (id === it.st) { ch3.working = { id, t: 0 }; AudioSys.pickup(); return; }
      wrongAction('npc3', tx('The {s} is not the right place for this.', { s: STATION_NAMES[id] }), tx('Go to the {s} instead.', { s: STATION_NAMES[it.st] }), it.why, POINTS.wrongStation);
    }
  });
});
// Stage 3 also uses the filter station and river from Stage 1 as valid "fix" locations
interactables.push({
  x: potGroup.position.x, z: potGroup.position.z, radius: 3,
  getPrompt() {
    if (ch3.state !== 'active' || ch3.stage !== 3 || !ch3.workItems) return null;
    const it = ch3.workItems[ch3.wi];
    return (it && it.st === 'filter') ? tx('Press E to work at the filter pots') : null;
  },
  interact() {
    if (ch3.state !== 'active' || ch3.stage !== 3 || !ch3.workItems) return;
    const it = ch3.workItems[ch3.wi];
    if (it && it.st === 'filter') { ch3.working = { id: 'filter', t: 0 }; AudioSys.pickup(); }
  }
});

const SCENARIOS = [
  { text: 'Power cut, but you have a gas stove and a big pot, and you need a small amount of safe water now.', st: 'stove', why: 'A rolling boil (at least 1 minute) kills the germs that cause disease — ideal for small amounts.' },
  { text: 'No fuel and no power, but it is a bright sunny day and you have clear plastic bottles of fairly clear water.', st: 'solar', why: 'Solar disinfection (SODIS) uses sunlight and clear PET bottles for about 6 hours — no fuel needed.' },
  { text: 'You must treat a big 200L storage drum and you have chlorine tablets.', st: 'chlor', why: 'Chlorine suits large volumes: follow the label dose and allow contact time before use.' },
  { text: 'The water looks very cloudy. What should you check first, before disinfecting it?', st: 'tube', why: 'Cloudy water shields germs from sunlight and chlorine, so check turbidity and filter it first.' },
  { text: 'It has been cloudy and rainy for three days, you have no gas, but you do have chlorine tablets.', st: 'chlor', why: 'Solar disinfection needs strong sun — without it, chlorine is the reliable choice.' },
  { text: "You are preparing water for a baby's formula and a gas stove is available.", st: 'stove', why: 'Boiling is the safest way to make water safe for babies — cool it in a clean, covered container.' }
];
const FAULTS = [
  { text: 'The filter has slowed to a trickle.', st: 'filter', why: 'A slow sand filter clogs at the surface — gently raking the top layer restores the flow.' },
  { text: 'The collection pot has a crack and is leaking.', st: 'spare', why: 'A damaged container leaks and lets contaminants in — replace it.' },
  { text: 'Flies and leaves are getting into the pots.', st: 'lid', why: 'Covers keep insects and debris out and prevent re-contamination.' },
  { text: 'The water tastes and smells odd after a week.', st: 'stove', why: 'Odd taste or smell can signal contamination: disinfect the water, then inspect the filter.' }
];

function ch3StartWork(kind) {
  const isBench = kind === 'bench';
  const pool = _shuffle(isBench ? SCENARIOS : FAULTS);
  ch3.workItems = pool.slice(0, isBench ? 3 : 4);
  ch3.wi = 0; ch3.working = null;
  ch3.state = 'active';
  STATION_IDS.concat(['lid', 'spare']).forEach((id) => { benchStations[id].group.visible = isBench ? STATION_IDS.includes(id) : ['stove', 'lid', 'spare'].includes(id); benchStations[id].label.visible = benchStations[id].group.visible; });
  runStart(2, isBench ? 2 : 3);
  const titleT = isBench ? 'Disinfection Bench' : 'Fault Finder';
  showDialogue(tx('{npc}: "{greet}Stage {n} — {t}"', { npc: 'Filter Fundi', greet: greet(), n: isBench ? 2 : 3, t: isBench ? 'Read each situation, then go to the right station.' : 'Your filter has problems! Diagnose and fix each one.' }), 8, 'npc3');
  ch3AnnounceWork();
  ch3.hint = () => 'Hint: think about fuel, sunshine, volume and how cloudy the water is to choose the right station.';
  ch3.waypoint = () => { const it = ch3.workItems[ch3.wi]; if (!it) return null; const s = it.st === 'filter' ? { x: potGroup.position.x, z: potGroup.position.z } : benchStations[it.st]; return s ? { x: s.x, z: s.z, label: STATION_NAMES[it.st] || 'Filter pots' } : null; };
  showBriefing({
    npc: `Filter Fundi — Filtration System`, title: tx('Stage {n} of 3: {t}', { n: isBench ? 2 : 3, t: titleT }),
    text: isBench ? 'Read each situation, then walk to the right station and press E: Turbidity tube, Boiling stove, Chlorine tablets or Solar bottle rack.' : 'Your filter has problems! Read each fault, go to the right place, and press E to fix it.',
    points: [isBench ? tx('+{n} points for each scenario solved at the right station', { n: POINTS.treatment }) : tx('+{n} points for each fault fixed in the right place', { n: POINTS.fixed }),
      tx('+{n} points for completing the stage', { n: POINTS.stageComplete }), tx('+{n} points for each correct quiz answer (up to {t})', { n: POINTS.quizCorrect, t: POINTS.quizCorrect * 3 }),
      tx('Penalty: −{n} points for each wrong station', { n: POINTS.wrongStation }), tx('Paid once per stage — replays are practice.')],
    controls: 'E at a station: start the work (stay close until it finishes) • WASD / arrows: move • Z / X: rotate camera',
    practice: run.practice
  });
}
function ch3AnnounceWork() {
  const it = ch3.workItems[ch3.wi];
  const line = ch3.stage === 2 ? it.text : tx('Fault: {t}', { t: it.text });
  showDialogue(line, 9, 'npc3');
  setObjective(line);
}
function ch3FinishWork() {
  const isBench = ch3.stage === 2;
  ch3.state = 'complete'; runStop(); setInventory(null); clearObjective();
  const res = onChallengeComplete(2, ch3.retries, 30);
  recordHistory('Completed'); advanceStage('ch3');
  if (res.guardianNow) showImpactSummary();
  showEndReward({
    title: tx('Stage {n} Complete!', { n: ch3.stage }),
    message: isBench ? 'You matched every situation to the right disinfection method.' : 'You diagnosed and fixed every fault in your filter.',
    stats: metricStats([{ label: isBench ? 'Scenarios solved' : 'Faults fixed', value: ch3.workItems.length + '/' + ch3.workItems.length }]),
    why: isBench ? 'Filtering is not enough on its own: boiling, chlorine or sunlight (SODIS), chosen to suit the situation, is what makes filtered water safe to drink.' : 'Regular checks and quick fixes keep a household filter working and the water safe.',
    home: isBench ? 'keep a way to disinfect water (a pot, chlorine tablets or clear bottles) for emergencies.' : 'check your water filter and storage containers regularly for clogging, cracks and dirt.',
    quizKey: 'ch3', practice: run.practice, stageId: stageKey(2, ch3.stage), badges: res.badges,
    onDone: () => { STATION_IDS.concat(['lid', 'spare']).forEach((id) => { benchStations[id].group.visible = false; benchStations[id].label.visible = false; }); npc3.challengeGiven = false; ch3.state = 'idle'; ch3.hint = null; ch3.waypoint = null; }
  });
}
function updateCh3Work(dt) {
  if (!ch3.workItems) return;
  const it = ch3.workItems[ch3.wi];
  if (!it) return;
  if (ch3.working) {
    const sx = ch3.working.id === 'filter' ? potGroup.position.x : benchStations[ch3.working.id].x;
    const sz = ch3.working.id === 'filter' ? potGroup.position.z : benchStations[ch3.working.id].z;
    if (dist2D(player.x, player.z, sx, sz) < 3) {
      ch3.working.t += dt;
      if (ch3.working.t >= 2.2) {
        const id = ch3.working.id; ch3.working = null;
        awardSubtask((ch3.stage === 2 ? 'sc' : 'fx') + ch3.wi, ch3.stage === 2 ? POINTS.treatment : POINTS.fixed, { x: sx, y: 1, z: sz }, ch3.stage === 2 ? 'right method' : 'fixed');
        goodAction(ch3.stage === 2 ? 'Right method' : 'Fixed!', it.why, 6);
        gesture(playerRig); AudioSys.success();
        ch3.wi++;
        if (ch3.wi >= ch3.workItems.length) { ch3FinishWork(); return; }
        ch3AnnounceWork();
      }
    } else { ch3.working.t = Math.max(0, ch3.working.t - dt); }
  }
  setInventory(ch3.stage === 2 ? tx('Scenario {a}/{b}', { a: Math.min(ch3.wi + 1, ch3.workItems.length), b: ch3.workItems.length }) : tx('Fault {a}/{b}', { a: Math.min(ch3.wi + 1, ch3.workItems.length), b: ch3.workItems.length }));
}
function ch3StartStage2() { ch3StartWork('bench'); }
function ch3StartStage3() { ch3StartWork('faults'); }

function updateCh3(dt) {
  if (ch3.state !== 'active') return;
  if (ch3.stage === 1) updateCh3Stage1(dt);
  else updateCh3Work(dt);
}

/* ------------------------- Persistent progress HUD -------------------------- */

function progressModel() {
  if (ch1.state === 'active') return { title: tx('{name} — Stage {n} of 3: {t}', { name: 'Rainwater Harvesting', n: ch1.stage, t: STAGE_TITLES[0][ch1.stage - 1] }) + (run.practice ? ' ' + tx('(practice — no points)') : ''), pct: ch1Stage1Pct() };
  if (ch2.state === 'active') return { title: tx('{name} — Stage {n} of 3: {t}', { name: 'Greywater Reuse', n: ch2.stage, t: STAGE_TITLES[1][ch2.stage - 1] }) + (run.practice ? ' ' + tx('(practice — no points)') : ''), pct: ch2StagePct() };
  if (ch3.state === 'active') return { title: tx('{name} — Stage {n} of 3: {t}', { name: 'Filtration System', n: ch3.stage, t: STAGE_TITLES[2][ch3.stage - 1] }) + (run.practice ? ' ' + tx('(practice — no points)') : ''), pct: ch3StagePct() };
  const done = profile.stagesCompleted.ch1 + profile.stagesCompleted.ch2 + profile.stagesCompleted.ch3;
  const nxt = nextLadderStep();
  return { title: nxt ? tx('Journey: {d} of 9 stages complete — next: {npc}, Stage {n}', { d: done, npc: CHALLENGE_NPC[nxt.idx], n: nxt.stage }) : tx('All 9 stages complete! Replay any stage for practice.'), pct: done / 9 };
}
function ch1Stage1Pct() {
  if (ch1.stage === 1) return Math.min(1, ch1.total / Math.max(1, ch1.target));
  if (ch1.stage === 2) return Math.min(1, ch1.total / Math.max(1, ch1.target));
  if (ch1.stage === 3) { const done = gardenBeds.filter((b) => b.have >= b.need - 0.01).length; return done / 3 * 0.7 + (ch1.valveEver ? 0.3 : 0); }
  return 0;
}
function ch2StagePct() {
  if (ch2.stage === 1) return ch2.solvedPath ? 1 : 0;
  if (ch2.stage === 2 && ch2.srcList) return ch2.srcList.filter((e) => e.resolved).length / ch2.srcList.length;
  if (ch2.stage === 3) return ch2.processed / 6;
  return 0;
}
function ch3StagePct() {
  if (ch3.stage === 1) { const collected = ['coarse', 'fine', 'gravel'].filter((k) => ch3.inventory[k] || ch3.installed[k]).length; const installed = ['coarse', 'fine', 'gravel'].filter((k) => ch3.installed[k]).length; return (collected + installed) / 6 * 0.6 + (ch3.filtering ? ch3.filterProgress * 0.4 : 0); }
  if (ch3.workItems) return ch3.wi / ch3.workItems.length;
  return 0;
}
let progressHudTimer = 0;
function updateProgressHud(force) {
  progressHudTimer -= 1 / 60;
  if (!force && progressHudTimer > 0) return;
  progressHudTimer = 0.2;
  const m = progressModel();
  el('hp-title').textContent = m.title;
  el('hp-bar-fill').style.width = Math.round(Math.max(0, Math.min(1, m.pct)) * 100) + '%';
}

/* ------------------------- Final evaluation / certificate -------------------- */

function computeKnowledgeBand() {
  const stats = profile.quizStats;
  const pct = stats.totalAnswered > 0 ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100) : 0;
  let band, critique;
  if (pct >= 90) { band = '🏆 Water Champion'; critique = 'Outstanding grasp of practical water-saving techniques across all nine stages.'; }
  else if (pct >= 70) { band = '🌊 Water Wise'; critique = 'Solid understanding of the core techniques, with a few gaps. Revisit the Facts Journal for the explanations behind any missed questions.'; }
  else if (pct >= 50) { band = '💧 Getting There'; critique = "You've grasped the basics, but several real-world details could use reinforcement. Try replaying a stage and reading its Journal facts."; }
  else { band = '🚰 Needs Review'; critique = "The challenges were completed, but quiz performance suggests the underlying reasons haven't fully landed yet — try reading every signpost and replaying a stage before its quiz."; }
  return { pct, band, critique };
}
function badgeLabel(id) {
  if (id === 'water_guardian') return 'Water Guardian';
  if (id.startsWith('flawless_')) return 'Flawless: ' + CHALLENGE_LABELS[parseInt(id.split('_')[1], 10)];
  const idx = CHALLENGE_NAMES.indexOf(id);
  return idx >= 0 ? CHALLENGE_LABELS[idx] : id;
}
function buildCertificateData() {
  const { pct, band, critique } = computeKnowledgeBand();
  return {
    kind: 'final',
    name: profile.playerName || 'Player', date: new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }),
    band, pct, critique, points: profile.totalPoints, badgeCount: profile.badges.length, badgeLabels: profile.badges.map(badgeLabel),
    impact: Math.round(profile.totalImpactLitres || 0), minutes: Math.round(profile.totalPlaySeconds / 60), facts: profile.journalFacts.length,
    techniques: ['Rainwater Collection: first-flush diversion + storm/overflow management', 'Greywater Reuse: source sorting, filter traps + diversion valve decision-making', 'Filtration System Build: disinfection method selection + fault diagnosis']
  };
}

/* -------------------------- Round certificates (1, 2) ----------------------- */
/* Awarded once Stage N of ALL THREE challenges is complete: Round 1 after every
   Stage-1 is done, Round 2 after every Stage-2 is done. Round 3 (every Stage-3
   done) is the Final Combined Certificate above, since that point already
   means every stage of every challenge is finished. */

const ROUND_META = {
  1: { title: 'Round 1 Certificate — Foundations', sub: 'Completed Stage 1 of every challenge' },
  2: { title: 'Round 2 Certificate — Applied Skills', sub: 'Completed Stage 2 of every challenge' }
};
function buildRoundCertificateData(round) {
  const meta = ROUND_META[round];
  return {
    kind: 'round', round,
    name: profile.playerName || 'Player', date: new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }),
    roundTitle: tx(meta.title), roundSub: tx(meta.sub),
    stageLines: [0, 1, 2].map((idx) => `${CHALLENGE_NPC[idx]} — ${CHALLENGE_FULLNAME[idx]}: Stage ${round} (${STAGE_TITLES[idx][round - 1]})`),
    points: profile.totalPoints, badgeCount: profile.badges.length, minutes: Math.round(profile.totalPlaySeconds / 60)
  };
}
async function saveRoundCertificateFile(round) {
  const data = buildRoundCertificateData(round);
  if (window.api && window.api.saveCertificate) {
    try { showToast('Generating PDF...'); const ok = await window.api.saveCertificate(data); if (ok) showToast('Certificate PDF saved!'); } catch (e) { console.error('Certificate save failed', e); }
  } else {
    openPrintableCertificate(buildRoundCertificatePrintHtml(data));
  }
}
function showRoundCertificate(round) {
  currentCertRound = round;
  const meta = ROUND_META[round];
  const data = buildRoundCertificateData(round);
  el('round-cert-title').textContent = '🎓 ' + tx(meta.title);
  el('round-cert-sub').textContent = tx(meta.sub);
  el('round-cert-stages').innerHTML = '<ul style="text-align:left;margin:10px auto;max-width:420px;line-height:1.7;">' +
    data.stageLines.map((l) => `<li>${escHtml(l)}</li>`).join('') + '</ul>';
  el('round-cert-summary').innerHTML = `<div class="stats-row"><div class="stat"><div class="stat-v">${profile.totalPoints}</div><div class="stat-l">${escHtml(tx('Points so far'))}</div></div>` +
    `<div class="stat"><div class="stat-v">${profile.badges.length}</div><div class="stat-l">${escHtml(tx('Badges so far'))}</div></div></div>`;
  el('round-cert-save-btn').onclick = () => saveRoundCertificateFile(round);
  el('round-cert-panel').classList.remove('hidden');
  AudioSys.fanfare();
  FX.confetti(new THREE.Vector3(player.x, 1.9, player.z));
}
el('round-cert-close-btn').addEventListener('click', () => {
  el('round-cert-panel').classList.add('hidden');
  dismissPendingCert(currentCertRound);
  if (profile.pendingCerts && profile.pendingCerts.length) setTimeout(showNextPendingCert, 500);
});
let currentCertRound = null;
async function saveCertificateFile() {
  const data = buildCertificateData();
  if (window.api && window.api.saveCertificate) {
    try { showToast('Generating PDF...'); const ok = await window.api.saveCertificate(data); if (ok) showToast('Certificate PDF saved!'); } catch (e) { console.error('Certificate save failed', e); }
  } else {
    openPrintableCertificate(buildCertificatePrintHtml(data));
  }
}

/* --------------------- Browser fallback: print-to-PDF certificates ---------------------
   Outside Electron (e.g. the game opened by double-clicking index.html) there is no main
   process to render a PDF, so these build the same certificate as printable HTML and open
   it in a new tab with window.print() already queued -- "Save as PDF" in the browser's own
   print dialog produces an equivalent file. The visual design mirrors main.js's PDF
   templates (buildCertificateHtml / buildRoundCertificateHtml) as closely as two separate
   JS runtimes (the Electron main process and this renderer) reasonably allow without a
   shared module system between them. */

function openPrintableCertificate(html) {
  let w;
  try { w = window.open('', '_blank'); } catch (e) { w = null; }
  if (!w) { showToast('Please allow pop-ups to save this certificate.'); return; }
  w.document.open(); w.document.write(html); w.document.close();
  setTimeout(() => { try { w.focus(); w.print(); } catch (e) { /* user can still print manually */ } }, 350);
}

function buildCertificatePrintHtml(d) {
  const badgeList = (d.badgeLabels && d.badgeLabels.length)
    ? d.badgeLabels.map((b) => `<span class="badge-chip">${escHtml(b)}</span>`).join('')
    : '<span class="badge-chip muted">None yet</span>';
  const techniques = (d.techniques || []).map((t) => `<li>${escHtml(t)}</li>`).join('');
  return `<!DOCTYPE html><html><head><meta charset="UTF-8" /><title>Certificate -- ${escHtml(d.name || 'Player')}</title><style>
  @page { size: A4; margin: 0; } * { box-sizing: border-box; }
  body { margin: 0; font-family: Georgia, 'Times New Roman', serif; background: #f7f3e8; color: #23321f; }
  .sheet { width: 210mm; min-height: 297mm; padding: 14mm; position: relative; }
  .border-outer { border: 2px solid #8a6a2a; padding: 6mm; height: 100%; }
  .border-inner { border: 1px solid #8a6a2a; height: 100%; padding: 12mm 16mm; text-align: center; display: flex; flex-direction: column; align-items: center; }
  .kicker { letter-spacing: 3px; font-size: 11px; color: #6a8a5a; text-transform: uppercase; margin-bottom: 6px; }
  h1 { font-size: 30px; margin: 0 0 4px; color: #2c4a26; letter-spacing: 1px; }
  .subtitle { font-size: 14px; color: #5a6a52; margin-bottom: 18px; }
  .presented-to { font-size: 13px; color: #6a6a5a; margin-top: 10px; }
  .player-name { font-family: 'Brush Script MT', 'Segoe Script', cursive, Georgia, serif; font-style: italic; font-size: 40px; color: #1a3a6a; margin: 6px 0 14px; border-bottom: 1px solid #8a6a2a; padding-bottom: 8px; min-width: 320px; }
  .band-line { font-size: 20px; font-weight: bold; color: #a86a1a; margin-bottom: 4px; }
  .band-sub { font-size: 12px; color: #6a6a5a; margin-bottom: 18px; }
  .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px 22px; width: 100%; max-width: 460px; margin: 8px 0 18px; font-size: 12px; }
  .stat-box { text-align: center; } .stat-value { font-size: 18px; font-weight: bold; color: #2c4a26; } .stat-label { color: #6a6a5a; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
  .badges-row { margin-bottom: 16px; }
  .badge-chip { display: inline-block; background: #eadfba; border: 1px solid #a8863a; color: #5a4420; font-size: 10px; padding: 3px 10px; border-radius: 12px; margin: 2px 3px; }
  .badge-chip.muted { background: transparent; border-style: dashed; color: #9a9a8a; }
  .techniques { text-align: left; max-width: 420px; font-size: 11px; color: #3a4a35; margin-bottom: 18px; }
  .techniques h3 { font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #6a8a5a; margin-bottom: 6px; text-align: center; }
  .techniques ul { margin: 0; padding-left: 18px; line-height: 1.6; }
  .critique { font-size: 11px; font-style: italic; color: #5a5a4a; max-width: 440px; line-height: 1.5; margin-bottom: 20px; }
  .footer { margin-top: auto; width: 100%; display: flex; justify-content: space-between; align-items: flex-end; padding-top: 14px; border-top: 1px solid #cabf9a; font-size: 10px; color: #6a6a5a; }
  .footer .col { text-align: left; } .footer .col.right { text-align: right; } .footer .line { font-weight: bold; color: #2c4a26; margin-bottom: 2px; }
  @media print { body { background: #fff; } }
</style></head><body>
  <div class="sheet"><div class="border-outer"><div class="border-inner">
    <div class="kicker">Water Conservation Challenge -- Final Combined Certificate</div>
    <h1>Certificate of Achievement</h1>
    <div class="subtitle">NWU Educational Water Conservation Simulation</div>
    <div class="presented-to">This certifies that</div>
    <div class="player-name">${escHtml(d.name || 'Player')}</div>
    <div class="presented-to">has completed all three stages of all three challenges -- Rainwater Harvesting, Greywater Reuse and Filtration System -- at Mastery (Stage 3) level, and achieved the rank of</div>
    <div class="band-line">${escHtml(d.band)}</div>
    <div class="band-sub">${escHtml(d.pct)}% quiz accuracy</div>
    <div class="stats-grid">
      <div class="stat-box"><div class="stat-value">${escHtml(d.points)}</div><div class="stat-label">Points</div></div>
      <div class="stat-box"><div class="stat-value">${escHtml(d.badgeCount)}</div><div class="stat-label">Badges</div></div>
      <div class="stat-box"><div class="stat-value">${escHtml(d.pct)}%</div><div class="stat-label">Quiz Accuracy</div></div>
      <div class="stat-box"><div class="stat-value">~${escHtml(d.impact)}L</div><div class="stat-label">Water Impact</div></div>
      <div class="stat-box"><div class="stat-value">~${escHtml(d.minutes)} min</div><div class="stat-label">Time Played</div></div>
      <div class="stat-box"><div class="stat-value">${escHtml(d.facts)}</div><div class="stat-label">Facts Discovered</div></div>
    </div>
    <div class="badges-row">${badgeList}</div>
    <div class="techniques"><h3>Real-World Techniques Mastered</h3><ul>${techniques}</ul></div>
    <div class="critique">"${escHtml(d.critique)}"</div>
    <div class="footer">
      <div class="col"><div class="line">Water Conservation Challenge</div><div>NWU Educational Simulation</div></div>
      <div class="col right"><div class="line">${escHtml(d.date)}</div><div>Certificate of Participation</div></div>
    </div>
  </div></div></div>
</body></html>`;
}

function buildRoundCertificatePrintHtml(d) {
  const stageRows = (d.stageLines || []).map((l) => `<li>${escHtml(l)}</li>`).join('');
  return `<!DOCTYPE html><html><head><meta charset="UTF-8" /><title>Certificate -- ${escHtml(d.name || 'Player')}</title><style>
  @page { size: A4; margin: 0; } * { box-sizing: border-box; }
  body { margin: 0; font-family: Georgia, 'Times New Roman', serif; background: #f7f3e8; color: #23321f; }
  .sheet { width: 210mm; min-height: 297mm; padding: 14mm; position: relative; }
  .border-outer { border: 2px solid #8a6a2a; padding: 6mm; height: 100%; }
  .border-inner { border: 1px solid #b89a52; height: 100%; display: flex; flex-direction: column; align-items: center; text-align: center; padding: 16mm 14mm; position: relative; }
  .kicker { font-size: 12px; letter-spacing: 3px; text-transform: uppercase; color: #6a8a5a; margin-bottom: 10px; }
  h1 { font-size: 34px; margin: 0 0 6px; color: #2c4a26; }
  .subtitle { font-size: 13px; color: #5a5a4a; margin-bottom: 26px; }
  .presented-to { font-size: 13px; color: #3a4a35; margin-bottom: 8px; max-width: 460px; line-height: 1.5; }
  .player-name { font-size: 28px; font-weight: bold; color: #2c4a26; margin: 6px 0 16px; border-bottom: 2px solid #b89a52; padding-bottom: 8px; }
  .round-line { font-size: 20px; font-weight: bold; color: #8a6a2a; margin-bottom: 4px; }
  .round-sub { font-size: 12px; color: #6a6a5a; margin-bottom: 24px; }
  .stage-list { text-align: left; max-width: 420px; font-size: 13px; color: #3a4a35; margin-bottom: 20px; }
  .stage-list ul { margin: 0; padding-left: 20px; line-height: 1.8; }
  .stats-grid { display: flex; gap: 14px; margin-bottom: 24px; flex-wrap: wrap; justify-content: center; }
  .stat-box { background: #eee6cf; border: 1px solid #cabf9a; border-radius: 6px; padding: 10px 16px; min-width: 90px; }
  .stat-value { font-size: 20px; font-weight: bold; color: #2c4a26; }
  .stat-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; color: #6a6a5a; margin-top: 2px; }
  .footer { margin-top: auto; width: 100%; display: flex; justify-content: space-between; align-items: flex-end; padding-top: 14px; border-top: 1px solid #cabf9a; font-size: 10px; color: #6a6a5a; }
  .footer .col { text-align: left; } .footer .col.right { text-align: right; } .footer .line { font-weight: bold; color: #2c4a26; margin-bottom: 2px; }
  @media print { body { background: #fff; } }
</style></head><body>
  <div class="sheet"><div class="border-outer"><div class="border-inner">
    <div class="kicker">Water Conservation Challenge</div>
    <h1>Certificate of Participation</h1>
    <div class="subtitle">NWU Educational Water Conservation Simulation</div>
    <div class="presented-to">This certifies that</div>
    <div class="player-name">${escHtml(d.name || 'Player')}</div>
    <div class="round-line">${escHtml(d.roundTitle)}</div>
    <div class="round-sub">${escHtml(d.roundSub)}</div>
    <div class="stage-list"><ul>${stageRows}</ul></div>
    <div class="stats-grid">
      <div class="stat-box"><div class="stat-value">${escHtml(d.points)}</div><div class="stat-label">Points so far</div></div>
      <div class="stat-box"><div class="stat-value">${escHtml(d.badgeCount)}</div><div class="stat-label">Badges so far</div></div>
      <div class="stat-box"><div class="stat-value">~${escHtml(d.minutes)} min</div><div class="stat-label">Time Played</div></div>
    </div>
    <div class="footer">
      <div class="col"><div class="line">Water Conservation Challenge</div><div>NWU Educational Simulation</div></div>
      <div class="col right"><div class="line">${escHtml(d.date)}</div><div>Certificate of Participation</div></div>
    </div>
  </div></div></div>
</body></html>`;
}
function triggerFinalEvaluation() {
  profile.finalEvaluationSeen = true; saveProfile();
  const { pct, band, critique } = computeKnowledgeBand();
  const mins = Math.round(profile.totalPlaySeconds / 60);
  const name = profile.playerName ? profile.playerName : 'Player';
  el('eval-band').textContent = `${band} — ${pct}% quiz accuracy`;
  el('eval-summary').innerHTML = `<div><b>Player:</b> ${escHtml(name)}</div><div><b>Total Points:</b> ${profile.totalPoints}</div><div><b>Badges Earned:</b> ${profile.badges.length}</div>` +
    `<div><b>Quiz Accuracy:</b> ${profile.quizStats.totalCorrect}/${profile.quizStats.totalAnswered} (${pct}%)</div><div><b>Cumulative Water Impact:</b> ~${(profile.totalImpactLitres || 0).toFixed(0)}L</div>` +
    `<div><b>Time Played:</b> ~${mins} minute${mins === 1 ? '' : 's'}</div><div><b>Facts Discovered:</b> ${profile.journalFacts.length}</div>`;
  el('eval-critique').textContent = critique;
  el('evaluation-panel').classList.remove('hidden'); certificateBtnEl.classList.remove('hidden'); AudioSys.badge();
}
el('eval-certificate-btn').addEventListener('click', saveCertificateFile);
certificateBtnEl.addEventListener('click', saveCertificateFile);
el('eval-close-btn').addEventListener('click', () => {
  el('evaluation-panel').classList.add('hidden');
  dismissPendingCert('final');
  if (profile.pendingCerts && profile.pendingCerts.length) setTimeout(showNextPendingCert, 500);
});

/* ============================================================================
   Onboarding, Pause menu, Settings (incl. music + voice + facts), Journal
   ============================================================================ */

const onboardingEl = el('onboarding');
const settingsPanelEl = el('settings-panel');
const pausePanelEl = el('pause-panel');
const journalPanelEl = el('journal-panel');
const confirmPanelEl = el('confirm-panel');
let gameStarted = false;
let settingsFromPause = false;

function refreshStaticText() {
  el('onboarding-title').textContent = t('onboardingTitle');
  el('onboarding-intro').textContent = t('onboardingIntro');
  el('onboarding-controls').innerHTML = `<strong>${t('onboardingControls')}</strong>`;
  el('onboarding-start').textContent = t('onboardingBtn');
  el('controls-hint').textContent = t('controlsHint') + '  •  ' + tx('Z / X: camera  •  J: journal');
  el('settings-title').textContent = t('settingsTitle');
  el('label-speed').textContent = t('settingsSpeed');
  el('label-camera').textContent = t('settingsCamera');
  el('label-volume').textContent = t('settingsVolume');
  el('label-music').textContent = t('settingsMusic');
  el('label-voice').textContent = t('settingsVoice');
  el('label-graphics').textContent = t('settingsGraphics');
  el('label-language').textContent = t('settingsLanguage');
  el('settings-close').textContent = t('settingsClose');
  el('pause-title').textContent = '⏸ ' + tx('Paused');
  el('pause-resume').textContent = '▶ ' + tx('Resume');
  el('pause-settings').textContent = '⚙ ' + t('settingsTitle');
  el('pause-journal').textContent = '📖 ' + tx('Journal & Progress');
  if (!quitArmed) el('pause-quit').textContent = '⏻ ' + tx('Quit to Desktop');
  el('reset-progress-btn').textContent = tx('Reset Progress');
  el('label-reset').textContent = tx('Saved progress');
  el('label-custommusic').textContent = tx('Play my own music');
  el('music-add').textContent = '➕ ' + tx('Add songs from my computer…');
  el('music-next').textContent = '⏭ ' + tx('Next song');
  el('facts-update-btn').textContent = '🌐 ' + tx('Update facts');
  el('badge-continue').textContent = tx('Continue');
  el('briefing-h-points').textContent = '🎯 ' + tx('Points for this stage');
  el('briefing-h-controls').textContent = '⌨ ' + tx('Controls for this task');
  refreshVoiceInfo(); renderMusicList(); refreshFactsStatus();
  refreshPointsHud(); refreshOnlineIndicator();
}

el('onboarding-start').addEventListener('click', startFromOnboarding);
el('onboarding-name').addEventListener('keydown', (e) => { if (e.key === 'Enter') startFromOnboarding(); });
function startFromOnboarding() {
  if (gameStarted) return;
  const nameVal = el('onboarding-name').value.trim();
  if (nameVal) profile.playerName = nameVal.slice(0, 24);
  onboardingEl.classList.add('hidden');
  gameStarted = true;
  AudioSys.unlock(); AudioSys.startAmbient();
  saveProfile();
}

const speedInput = el('setting-speed'), cameraInput = el('setting-camera'), volumeInput = el('setting-volume'), musicInput = el('setting-music'),
  voiceInput = el('setting-voice'), graphicsInput = el('setting-graphics'), languageInput = el('setting-language'), difficultyInput = el('setting-difficulty'),
  textSizeInput = el('setting-textsize'), customMusicInput = el('setting-custommusic');

function applySettingsToUI() {
  speedInput.value = settings.speed; cameraInput.value = settings.cameraAngle; volumeInput.value = settings.volume;
  musicInput.checked = settings.music; voiceInput.checked = settings.voice; graphicsInput.value = settings.graphics;
  languageInput.value = settings.language; difficultyInput.value = settings.difficulty; textSizeInput.value = settings.textSize;
  customMusicInput.checked = !!settings.customMusic;
}
function applyGraphicsDetail() {
  const tier = settings.graphics, showTrees = tier !== 'minimal', showExtra = tier === 'lush';
  environmentData.foliageForWind.forEach((m) => { m.parent.visible = showTrees; });
  environmentData.extraDecor.forEach((m) => { m.visible = showExtra; });
  villagers.forEach((v) => { v.rig.group.visible = showTrees; });
  birds.forEach((b) => { b.mesh.visible = showExtra; });
}
const uiRootEl = el('ui-root');
function applyTextSize() { const z = { small: 0.85, medium: 1, large: 1.28 }; if (uiRootEl) uiRootEl.style.zoom = z[settings.textSize] || 1; }

function openSettings(fromPause) { settingsFromPause = !!fromPause; applySettingsToUI(); settingsPanelEl.classList.remove('hidden'); }
function closeSettings() { settingsPanelEl.classList.add('hidden'); saveProfile(); if (settingsFromPause) { settingsFromPause = false; openPause(); } }
el('gear-btn').addEventListener('click', () => { if (gameStarted && !isUiBlocking()) openSettings(false); });
el('settings-close').addEventListener('click', closeSettings);
speedInput.addEventListener('input', () => { settings.speed = parseFloat(speedInput.value); });
cameraInput.addEventListener('input', () => { settings.cameraAngle = parseFloat(cameraInput.value); camOffset = computeCamOffset(); });
volumeInput.addEventListener('input', () => { settings.volume = parseFloat(volumeInput.value); AudioSys.setVolume(settings.volume / 100); });
musicInput.addEventListener('change', () => { settings.music = musicInput.checked; AudioSys.setMusic(settings.music); });
voiceInput.addEventListener('change', () => { settings.voice = voiceInput.checked; AudioSys.setVoiceEnabled(settings.voice); refreshVoiceInfo(); });
graphicsInput.addEventListener('change', () => { settings.graphics = graphicsInput.value; applyGraphicsDetail(); });
languageInput.addEventListener('change', () => { settings.language = languageInput.value; setLanguage(settings.language); AudioSys.setSpeechLanguage(settings.language); refreshStaticText(); updateProgressHud(true); });
difficultyInput.addEventListener('change', () => { settings.difficulty = difficultyInput.value; });
textSizeInput.addEventListener('change', () => { settings.textSize = textSizeInput.value; applyTextSize(); });
customMusicInput.addEventListener('change', () => { settings.customMusic = customMusicInput.checked; AudioSys.setCustomMusic(settings.customMusic); renderMusicList(); });

/* --------------------------- Personal music playlist ------------------------- */

let musicTracks = [];
function renderMusicList() {
  const list = el('music-list');
  if (!list) return;
  const now = AudioSys.currentTrackName();
  el('music-now').textContent = musicTracks.length ? (settings.customMusic ? '♪ ' + (now || '') : tx('Turn on "Play my own music" to use your playlist.')) : tx('No songs added yet.');
  list.innerHTML = musicTracks.map((tr) => `<div class="music-item${tr.name === now && settings.customMusic ? ' playing' : ''}"><span>${escHtml(tr.name)}</span><button data-url="${escHtml(tr.url)}">✕</button></div>`).join('');
  list.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
    musicTracks = musicTracks.filter((t) => t.url !== b.dataset.url);
    AudioSys.setPlaylist(musicTracks); renderMusicList();
  }));
}
AudioSys.onPlaylistChange(() => renderMusicList());
el('music-add').addEventListener('click', () => el('music-file').click());
el('music-file').addEventListener('change', (e) => {
  const files = Array.from(e.target.files || []);
  e.target.value = '';
  files.forEach((f) => { if (f.type.startsWith('audio/')) musicTracks.push({ name: f.name.replace(/\.[^.]+$/, ''), url: URL.createObjectURL(f) }); });
  if (files.length) { AudioSys.setPlaylist(musicTracks); settings.customMusic = true; customMusicInput.checked = true; AudioSys.setCustomMusic(true); renderMusicList(); }
});
el('music-next').addEventListener('click', () => { AudioSys.nextTrack(); renderMusicList(); });

function refreshVoiceInfo() {
  const info = AudioSys.voiceInfo();
  const vi = el('voice-info');
  if (!vi) return;
  if (!info.supported) vi.textContent = tx('Spoken instructions are not available on this computer, so instructions are shown as text.');
  else if (!info.hasVoice) vi.textContent = tx('No voice is installed on this computer, so instructions are shown as text only.');
  else if (!info.exact) vi.textContent = tx('No matching voice for this language — the closest available voice reads the instructions. Text is always shown too.');
  else vi.textContent = tx('Voice: {v}', { v: info.voiceName });
}
if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = () => refreshVoiceInfo();

/* ------------------------------ Online fact updates --------------------------- */
/* Fetches short, validated lead-paragraph facts about water-related topics from
   Wikipedia's REST summary API — the only external source used, and only over
   HTTPS. Only standard (non-stub, non-disambiguation) articles are accepted. */

const FACT_TOPICS = ['Rainwater harvesting', 'Greywater', 'Slow sand filter', 'Water purification', 'Water scarcity', 'Water conservation',
  'Solar water disinfection', 'Turbidity', 'Cape Town water crisis', 'Water supply and sanitation in South Africa', 'Drought', 'Water chlorination'];
const FACT_TOPIC_WORDS = /water|rain|filter|drought|sanitation|irrigat|sewage|wastewater|clean|purif|disinfect|reservoir|dam|turbid|chlor|supply|drink|conserv/i;

function factsFromSummary(json, max) {
  if (!json || json.type !== 'standard' || typeof json.extract !== 'string') return [];
  const extract = json.extract;
  if (extract.length < 80 || /may (also )?refer to/i.test(extract)) return [];
  const page = json.content_urls && json.content_urls.desktop && json.content_urls.desktop.page;
  if (!page || !/^https:\/\/[a-z-]+\.wikipedia\.org\//i.test(page)) return [];
  const out = [];
  /* No regex look-behind here: it is a SyntaxError on older iOS Safari (< 16.4) and would stop the whole game from loading. */
  for (const raw of extract.replace(/\s+/g, ' ').replace(/([.!?])\s+(?=[A-Z0-9"'(])/g, '$1\u0001').split('\u0001').slice(0, 3)) {
    const s = raw.replace(/\[\s*[\w\s]{1,12}\s*\]/g, '').trim();
    if (s.length < 45 || s.length > 340 || !/[.!?]$/.test(s) || !FACT_TOPIC_WORDS.test(s)) continue;
    out.push({ text: s, source: 'Wikipedia — ' + (json.title || 'article') });
    if (out.length >= max) break;
  }
  return out;
}
async function wikiSummary(title) {
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), 9000);
  try {
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, '_'))}`, { signal: ctrl.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('http ' + res.status);
    return await res.json();
  } finally { clearTimeout(timer); }
}
let factsBusy = false;
async function maybeAutoUpdateFacts(force) {
  if (factsBusy || !profile.playerId) return;
  const last = profile.factsUpdatedAt ? Date.parse(profile.factsUpdatedAt) : 0;
  const stale = !last || (Date.now() - last) > 6 * 3600 * 1000 || (profile.onlineFacts || []).length === 0;
  if (!force && !stale) return;
  if (!isOnline) { refreshFactsStatus(tx('You are offline — showing the facts saved on this device.')); return; }
  factsBusy = true;
  refreshFactsStatus(tx('Updating…'));
  let added = 0;
  const known = new Set((profile.onlineFacts || []).map((f) => f.text.toLowerCase()));
  for (let i = 0; i < 4; i++) {
    const title = FACT_TOPICS[(profile.factCursor + i) % FACT_TOPICS.length];
    try {
      const json = await wikiSummary(title);
      factsFromSummary(json, 2).forEach((f) => {
        if (!known.has(f.text.toLowerCase())) { known.add(f.text.toLowerCase()); profile.onlineFacts.unshift(Object.assign({ fetched: new Date().toISOString() }, f)); added++; }
      });
    } catch (e) { /* one topic failing must not stop the rest */ }
  }
  profile.factCursor = (profile.factCursor + 4) % FACT_TOPICS.length;
  if (profile.onlineFacts.length > 60) profile.onlineFacts.length = 60;
  profile.factsUpdatedAt = new Date().toISOString();
  saveProfile();
  factsBusy = false;
  if (added > 0) { badgeToastEl.textContent = '🌐 ' + tx('{n} new facts added to your Journal', { n: added }); badgeToastEl.classList.remove('hidden'); badgeToastTimer = 4; }
  refreshFactsStatus();
  if (!journalPanelEl.classList.contains('hidden') && journalTab === 'facts') renderJournal();
}
function refreshFactsStatus(msg) {
  const st = el('facts-status'); if (!st) return;
  st.textContent = msg || (profile.factsUpdatedAt ? tx('Last updated: {d}', { d: new Date(profile.factsUpdatedAt).toLocaleString() }) : tx('Not updated yet — connect to the internet and press Update.'));
}
el('facts-update-btn').addEventListener('click', () => maybeAutoUpdateFacts(true));

/* ----------------------------- Reset progress -------------------------------- */

el('reset-progress-btn').addEventListener('click', () => confirmPanelEl.classList.remove('hidden'));
el('confirm-cancel').addEventListener('click', () => confirmPanelEl.classList.add('hidden'));
el('confirm-yes').addEventListener('click', resetProgress);
async function resetProgress() {
  const fresh = { settings };
  resettingProgress = true;
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(fresh)); } catch (e) { /* ignore */ }
  try { await window.api.saveProfile(fresh); } catch (e) { /* ignore */ }
  window.location.reload();
}

/* --------------------------------- Pause menu --------------------------------- */

let quitArmed = false;
function openPause() { quitArmed = false; el('pause-quit').textContent = '⏻ ' + tx('Quit to Desktop'); pausePanelEl.classList.remove('hidden'); }
function closePause() { pausePanelEl.classList.add('hidden'); quitArmed = false; }
el('pause-resume').addEventListener('click', closePause);
el('pause-settings').addEventListener('click', () => { closePause(); openSettings(true); });
el('pause-journal').addEventListener('click', () => { closePause(); openJournal('facts'); });
el('pause-quit').addEventListener('click', async () => {
  if (!quitArmed) { quitArmed = true; el('pause-quit').textContent = tx('Click again to save & quit'); return; }
  await saveProfile();
  if (window.api && window.api.quitApp) window.api.quitApp(); else window.close();
});
window.addEventListener('keydown', (e) => {
  if (isTypingTarget(e) && e.key !== 'Escape') return;
  if (e.key === 'Escape') {
    if (!gameStarted) return;
    if (!confirmPanelEl.classList.contains('hidden')) { confirmPanelEl.classList.add('hidden'); return; }
    if (!settingsPanelEl.classList.contains('hidden')) { closeSettings(); return; }
    if (!journalPanelEl.classList.contains('hidden')) { closeJournal(); return; }
    if (!pausePanelEl.classList.contains('hidden')) { closePause(); return; }
    if (isUiBlocking()) return;
    openPause();
    return;
  }
  if (e.key.toLowerCase() === 'j' && gameStarted) { if (!journalPanelEl.classList.contains('hidden')) closeJournal(); else if (!isUiBlocking()) openJournal('facts'); }
});

/* ------------------------ Journal: Facts / Progress / Controls --------------- */

const journalListEl = el('journal-list'), journalCountEl = el('journal-count');
let journalTab = 'facts';
function renderJournal() {
  const n = profile.journalFacts.length, on = (profile.onlineFacts || []).length;
  journalCountEl.textContent = tx('{n} facts discovered • {o} online updates', { n, o: on });
  refreshFactsStatus();
  let html = '';
  if (n === 0 && on === 0) html = `<div class="journal-empty">${escHtml(tx('Explore signposts, complete challenges, and answer quiz questions to fill this journal with real water-saving facts.'))}</div>`;
  else {
    html = profile.journalFacts.map((f) => `<div class="journal-entry">${escHtml(f)}</div>`).join('');
    if (on) html += `<div class="journal-online-head">🌐 ${escHtml(tx('Online updates'))}</div>` + profile.onlineFacts.slice(0, 40).map((f) => `<div class="journal-entry">${escHtml(f.text)}<span class="src">${escHtml(f.source)}${f.fetched ? ' • ' + escHtml(new Date(f.fetched).toLocaleDateString()) : ''}</span></div>`).join('');
  }
  journalListEl.innerHTML = html;
}

/* ----------------------- CSV export of results (anonymous) ----------------------
   Writes the task history and quiz totals to a CSV file the player chooses to save.
   Only the random anonymous playerId is included -- never the player's name -- and
   nothing is sent anywhere: the player decides where the file goes (POPIA: the data
   stays on this device unless the player shares the file). */
function csvCell(v) { const s = String(v == null ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
function buildResultsCsv() {
  const head = ['playerId', 'task', 'status', 'practice', 'attempt', 'timeSec', 'mistakes', 'points', 'completedAt'];
  const lines = [head.join(',')];
  profile.history.slice().reverse().forEach((h) => {
    lines.push([profile.playerId, h.name, h.status, h.practice ? 'yes' : 'no', h.attempt, Math.round(h.timeSec || 0), h.mistakes, h.practice ? 0 : h.points, h.at || ''].map(csvCell).join(','));
  });
  const qs = profile.quizStats || { totalAnswered: 0, totalCorrect: 0 };
  lines.push('');
  lines.push(['playerId', 'totalPoints', 'badges', 'stagesCompleted', 'quizAnswered', 'quizCorrect', 'quizAccuracyPct', 'impactLitres', 'playMinutes'].join(','));
  const done = profile.stagesCompleted.ch1 + profile.stagesCompleted.ch2 + profile.stagesCompleted.ch3;
  const pct = qs.totalAnswered ? Math.round(100 * qs.totalCorrect / qs.totalAnswered) : 0;
  lines.push([profile.playerId, profile.totalPoints, profile.badges.length, done, qs.totalAnswered, qs.totalCorrect, pct, Math.round(profile.totalImpactLitres || 0), Math.round((profile.totalPlaySeconds || 0) / 60)].map(csvCell).join(','));
  return lines.join('\r\n') + '\r\n';
}
async function exportResultsCsv() {
  const text = buildResultsCsv();
  const filename = 'WaterConservation_Results_' + profile.playerId + '.csv';
  if (window.api && window.api.exportCsv) {
    try { const ok = await window.api.exportCsv(text, filename); if (ok) showToast('Results exported!'); } catch (e) { console.error('CSV export failed', e); }
    return;
  }
  const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  showToast('Results exported!');
}

function renderProgressTab() {
  const nxt = nextLadderStep();
  const grid = [0, 1, 2].map((idx) => {
    const done = profile.stagesCompleted[chKey(idx)];
    const cells = [1, 2, 3].map((s) => {
      let cls = 'locked', icon = '🔒';
      if (done >= s) { cls = 'done'; icon = '✔'; } else if (nxt && nxt.idx === idx && nxt.stage === s) { cls = 'next'; icon = '▶'; }
      return `<div class="pg-cell ${cls}"><div>${icon}</div><small>${tx('Stage {n}', { n: s })}</small><small>${STAGE_TITLES[idx][s - 1]}</small></div>`;
    }).join('');
    return `<div class="pg-row"><div class="pg-name">${CHALLENGE_NPC[idx]}<small>${CHALLENGE_FULLNAME[idx]}</small></div>${cells}</div>`;
  }).join('');
  const rows = profile.history.slice(0, 30).map((h) => {
    const ok = String(h.status).startsWith('Completed');
    const when = h.at ? new Date(h.at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
    return `<tr><td>${escHtml(h.name)}${h.practice ? ' <small>(practice)</small>' : ''}</td><td class="${ok ? 'status-ok' : 'status-fail'}">${escHtml(tx(h.status))}</td><td>${fmtTime(h.timeSec)}</td><td>${h.attempt}</td><td>${h.mistakes}</td><td>${h.practice ? 0 : h.points}</td><td>${escHtml(when)}</td></tr>`;
  }).join('');
  const certRows = [];
  if (profile.roundCertSeen && profile.roundCertSeen[1]) certRows.push(['1', tx('Round 1 Certificate — Foundations')]);
  if (profile.roundCertSeen && profile.roundCertSeen[2]) certRows.push(['2', tx('Round 2 Certificate — Applied Skills')]);
  if (profile.finalEvaluationSeen) certRows.push(['final', tx('Final Combined Certificate')]);
  const certsHtml = certRows.length
    ? `<div class="cert-list">${certRows.map(([id, label]) => `<div class="cert-row"><span>🎓 ${escHtml(label)}</span><button class="btn-secondary btn-small cert-save-btn" data-cert="${id}">${escHtml(tx('Save'))}</button></div>`).join('')}</div>`
    : `<div class="journal-empty">${tx('No certificates earned yet — complete Stage 1 of all three challenges to earn the first one.')}</div>`;

  el('tab-progress').innerHTML = `<h3>${tx('Stage progress')}</h3>${grid}` +
    `<div class="settings-note" style="margin-top:8px;">${tx('Total:')} <b>${profile.totalPoints}</b> ${tx('points')}, <b>${profile.badges.length}</b> ${tx('badges')}.</div>` +
    `<h3>${tx('My Certificates')}</h3>${certsHtml}` +
    `<h3>${tx('Task history')}</h3>` + (rows ? `<table><tr><th>Task</th><th>Status</th><th>Time</th><th>Attempt</th><th>Mistakes</th><th>Points</th><th>When</th></tr>${rows}</table>` : `<div class="journal-empty">${tx('No tasks recorded yet — complete a stage to see it here.')}</div>`);
  const exp = document.createElement('div');
  exp.style.cssText = 'margin-top:12px;';
  exp.innerHTML = `<button class="btn-secondary btn-small" id="export-csv-btn">⬇ ${escHtml(tx('Export my results (CSV)'))}</button> <span class="settings-note">${escHtml(tx('Anonymous — your name is not included. Saved only where you choose.'))}</span>`;
  el('tab-progress').appendChild(exp);
  el('export-csv-btn').addEventListener('click', exportResultsCsv);
  el('tab-progress').querySelectorAll('.cert-save-btn').forEach((btn) => btn.addEventListener('click', () => {
    const id = btn.dataset.cert;
    if (id === 'final') saveCertificateFile(); else saveRoundCertificateFile(parseInt(id, 10));
  }));
}
function renderControlsTab() {
  const K = (k) => `<span class="key-chip">${k}</span>`;
  el('tab-controls').innerHTML = `<h3>Controls</h3><table>` +
    `<tr><td>${K('W')}${K('A')}${K('S')}${K('D')} / arrows</td><td>Move (relative to the camera)</td></tr>` +
    `<tr><td>${K('Z')} ${K('X')}</td><td>Rotate the camera</td></tr><tr><td>Right mouse + drag</td><td>Rotate the camera</td></tr>` +
    `<tr><td>${K('E')}</td><td>Interact: talk, place / pick up, pour, collect, build, switch, fix</td></tr>` +
    `<tr><td>${K('F')}</td><td>Fit a filter trap (Greywater Stage 2)</td></tr><tr><td>${K('1')} ${K('2')} ${K('3')}</td><td>Choose a material or decision</td></tr>` +
    `<tr><td>${K('J')}</td><td>Journal</td></tr><tr><td>${K('Esc')}</td><td>Pause menu</td></tr></table>` +
    `<h3>How points work</h3><ul style="font-size:13px;line-height:1.6;margin:4px 0;padding-left:20px;">` +
    `<li>Every stage: +${POINTS.stageComplete} for completing it; quiz: +${POINTS.quizCorrect} per correct answer.</li>` +
    `<li>Each stage pays for its own sub-tasks — exact points are listed in the briefing before the stage starts.</li>` +
    `<li>Mistakes cost points (for example overfilling the tank, a wrong layer, a wrong destination). Your total never drops below 0.</li>` +
    `<li>Points and badges are paid once per stage. Replaying a completed stage is practice and awards nothing.</li></ul>`;
}
function setJournalTab(tabName) {
  journalTab = tabName;
  ['facts', 'progress', 'controls'].forEach((n) => { el('tab-' + n).classList.toggle('hidden', n !== tabName); el('tab-btn-' + n).classList.toggle('active', n === tabName); });
  if (tabName === 'facts') renderJournal(); else if (tabName === 'progress') renderProgressTab(); else renderControlsTab();
}
function openJournal(tabName) { setJournalTab(tabName || 'facts'); journalPanelEl.classList.remove('hidden'); }
function closeJournal() { journalPanelEl.classList.add('hidden'); }
document.querySelectorAll('#journal-panel .tab').forEach((b) => b.addEventListener('click', () => setJournalTab(b.dataset.tab)));
el('journal-btn').addEventListener('click', () => { if (!gameStarted) return; if (!journalPanelEl.classList.contains('hidden')) closeJournal(); else if (!isUiBlocking()) openJournal('facts'); });
el('journal-close').addEventListener('click', closeJournal);

/* ---------------------------------- Boot --------------------------------------- */

cartoonifyScene(scene);

(async function boot() {
  const isNew = await loadProfile();
  if (profile.settings) Object.assign(settings, profile.settings);
  [0, 1, 2].forEach((i) => { const c = chObj(i); c.stage = Math.min(3, (profile.stagesCompleted[chKey(i)] || 0) + 1); c.retries = profile.retries[chKey(i)] || 0; });
  setLanguage(settings.language);
  AudioSys.setSpeechLanguage(settings.language);
  camOffset = computeCamOffset();
  AudioSys.setVolume(settings.volume / 100);
  AudioSys.setMusic(settings.music);
  AudioSys.setVoiceEnabled(settings.voice);
  applyGraphicsDetail(); applyTextSize();
  refreshStaticText(); updateProgressHud(true);
  maybeAutoUpdateFacts(false);
  if (isNew) onboardingEl.classList.remove('hidden');
  else {
    el('onboarding-name').value = profile.playerName || '';
    gameStarted = true;
    const name = profile.playerName ? `, ${profile.playerName}` : '';
    showDialogue(tx('Welcome back{name}! Points: {p}, Badges: {b}. Follow the compass to your next stage.', { name, p: profile.totalPoints, b: profile.badges.length }), 6);
    // Deliver any certificate that was earned but never actually shown (e.g. the game closed in
    // the moment between finishing the stage and the popup appearing).
    if (profile.pendingCerts && profile.pendingCerts.length) setTimeout(showNextPendingCert, 2500);
  }
})();

setInterval(() => { if (gameStarted) saveProfile(); }, 20000);
window.addEventListener('beforeunload', saveProfileSync);
document.addEventListener('visibilitychange', () => { if (document.hidden && gameStarted) saveProfile(); });

/* ------------------------------ Generic feedback -------------------------------- */

let wrongCooldown = 0;
function genericInteractFeedback() {
  if (wrongCooldown > 0) return;
  wrongCooldown = 1.2;
  if (ch1.state === 'active') {
    if (!player.hasBucket && ch1.stage !== 3) wrongAction('npc1', 'You already put your bucket down at a puddle.', 'Walk back and press E once it has filled.', 'You only have one bucket.', 0);
    else wrongAction('npc1', 'There is nothing to use here.', 'Follow the yellow prompt — it tells you when E works.', 'Each step happens at a specific place.', 0);
  } else if (ch2.state === 'active') {
    wrongAction('npc2', 'Nothing can be placed here.', 'Follow the prompt for where to go next.', 'Each stage has specific stations for its task.', 0);
  } else if (ch3.state === 'active') {
    wrongAction('npc3', 'There is nothing to use here.', 'Stand where a yellow prompt appears, then press E.', 'Every step happens at a specific place.', 0);
  }
}

/* -------------------------------- Main loop -------------------------------------- */

let lastTime = performance.now();
let minimapTimer = 0;

function update(dt, elapsed) {
  if (wrongCooldown > 0) wrongCooldown -= dt;
  if (keys['z']) camYaw -= 1.8 * dt;
  if (keys['x']) camYaw += 1.8 * dt;

  const fwd = ((keys['w'] || keys['arrowup']) ? 1 : 0) - ((keys['s'] || keys['arrowdown']) ? 1 : 0);
  const side = ((keys['d'] || keys['arrowright']) ? 1 : 0) - ((keys['a'] || keys['arrowleft']) ? 1 : 0);
  let moving = false;
  if (fwd !== 0 || side !== 0) {
    const b = camBasis();
    let dx = b.f.x * fwd + b.r.x * side, dz = b.f.z * fwd + b.r.z * side;
    const len = Math.hypot(dx, dz); dx /= len; dz /= len;
    player.x = clamp(player.x + dx * settings.speed * dt, -95, 95);
    player.z = clamp(player.z + dz * settings.speed * dt, -80, 70);
    player.facing = Math.atan2(dx, dz);
    moving = true;
    player.footstepTimer -= dt;
    if (player.footstepTimer <= 0) { AudioSys.footstep(); player.footstepTimer = 0.32; }
  }
  playerRig.group.position.set(player.x, 0, player.z);
  playerRig.group.rotation.y = player.facing;
  facingArrowPivot.position.set(player.x, 0.05, player.z);
  facingArrowPivot.rotation.y = player.facing;
  animateRig(playerRig, elapsed, moving, dt);
  animateRig(npc1.rig, elapsed, false, dt); animateRig(npc2.rig, elapsed, false, dt); animateRig(npc3.rig, elapsed, false, dt);
  updateVillagerWanderers(villagers, dt, elapsed, animateRig);
  updateBirds(birds, elapsed);
  updateEnvironment(environmentData.foliageForWind, elapsed);
  updateCamera(dt);

  const nearest = findNearestInteractable();
  const prompt = nearest ? nearest.getPrompt() : null;
  setPrompt(prompt);
  if (interactJustPressed) { if (prompt && nearest) { nearest.interact(); hintTimer = 0; hintsGivenThisAttempt = 0; } else genericInteractFeedback(); }
  interactJustPressed = false;
  handleFKey(); trapKeyJustPressed = false;
  handleSelectKey(); selectKeyJustPressed = null;

  if (dialogueTimer > 0) { dialogueTimer -= dt; if (dialogueTimer <= 0) dialogueEl.textContent = ''; }
  if (feedbackTimer > 0) { feedbackTimer -= dt; if (feedbackTimer <= 0) hideFeedback(); }
  if (badgeToastTimer > 0) { badgeToastTimer -= dt; if (badgeToastTimer <= 0) badgeToastEl.classList.add('hidden'); }

  updateCh1(dt); updateCh2(dt); updateCh3(dt);
  updateHintSystem(dt); updateQuestMarkers(dt, elapsed); updateCombo(dt);
  profile.totalPlaySeconds += dt;
  if (run.active) run.elapsed += dt;

  updateProgressHud(false);
  minimapTimer -= dt;
  if (minimapTimer <= 0) { drawMinimap(); updateCompassHint(); minimapTimer = 0.1; }
}

/** F: fit/remove a filter trap on a laid Greywater pipe (Stage 1), or on a reused source (Stage 2). */
function handleFKey() {
  if (!trapKeyJustPressed) return;
  if (wrongCooldown > 0) return;
  if (ch2.state === 'active' && ch2.stage === 2) { ch2SourceKey('f'); return; }
  if (ch2.state === 'active' && ch2.stage === 1) {
    const cell = ch2.grid.find((c) => !c.isSource && !c.isDest && !c.isSewerDest && c.hasPipe && dist2D(player.x, player.z, c.x, c.z) < CH2_CELL * 0.6);
    if (!cell) { wrongCooldown = 1.2; wrongAction('npc2', 'There is no laid pipe under you.', 'Stand on a placed pipe tile and press F.', 'A trap has to sit inside the pipe line.', 0); return; }
    cell.isTrap = !cell.isTrap; cell.trapMesh.visible = cell.isTrap;
    gesture(playerRig); AudioSys.pipePlace();
    if (cell.isTrap) { awardSubtask('trap', POINTS.filterTrap, { x: cell.x, y: 0.5, z: cell.z }, 'filter trap'); goodAction('Filter trap fitted', 'A lint/hair trap stops solids clogging the pipe.', 5); }
  } else {
    wrongCooldown = 1.2;
    wrongAction(ch1.state === 'active' ? 'npc1' : 'npc3', 'F has no use here.', 'F fits filter traps in the Greywater challenge.', 'Each technique uses its own tools.', 0);
  }
}

function loop(now) {
  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;
  const elapsed = now / 1000;
  if (gameStarted) {
    if (!isUiBlocking()) update(dt, elapsed);
    else { interactJustPressed = false; trapKeyJustPressed = false; selectKeyJustPressed = null; updateCamera(dt); animateRig(playerRig, elapsed, false, dt); }
  }
  FX.update(dt);
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}
requestAnimationFrame((t) => { lastTime = t; requestAnimationFrame(loop); });
