/* Registers the service worker (only on http/https, never inside Electron or file://). */
(function () {
  if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
  window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () { /* offline install is optional */ }); });
})();
