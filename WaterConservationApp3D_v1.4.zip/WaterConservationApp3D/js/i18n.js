/* =========================================================================
   i18n — language switcher. English and Afrikaans are highest-confidence.
   isiZulu, Sesotho, Setswana, isiXhosa and Tshivenda are AI-assisted DRAFT
   translations of short UI strings only (not the deeper dialogue/quiz
   content) and are flagged in the settings menu as needing native-speaker
   review before formal/academic use.
   ========================================================================= */

const LANGS = {
  en: { label: 'English' },
  af: { label: 'Afrikaans' },
  zu: { label: 'isiZulu' },
  st: { label: 'Sesotho' },
  tn: { label: 'Setswana' },
  xh: { label: 'isiXhosa' },
  ve: { label: 'Tshivenda' }
};

const TRANSLATIONS = {
  appTitle: {
    en: 'Water Conservation Challenge', af: 'Waterbewaring-uitdaging',
    zu: 'Inselelo Yokonga Amanzi', st: 'Phephetso ea ho Boloka Metsi',
    tn: 'Kgwetlho ya go Boloka Metsi', xh: 'Umceli mngeni Wokulondoloza Amanzi',
    ve: 'Khwetho ya u Vhulunga Madi'
  },
  onboardingTitle: {
    en: 'Welcome to the Water Conservation Challenge', af: 'Welkom by die Waterbewaring-uitdaging',
    zu: 'Wamukelekile Enseleleni Yokonga Amanzi', st: 'Rea u amohela Phephetsong ea ho Boloka Metsi',
    tn: 'O amogetswe mo Kgwetlhong ya go Boloka Metsi', xh: 'Wamkelekile Kumceli mngeni Wokulondoloza Amanzi',
    ve: 'Ni khou u ṱanganedza kha Khwetho ya u Vhulunga Madi'
  },
  onboardingIntro: {
    en: 'Explore the village and find three NPCs, each teaching a real household water-saving technique used across South Africa.',
    af: 'Verken die dorpie en vind drie karakters, elkeen leer \'n regte huishoudelike waterbesparingstegniek wat regoor Suid-Afrika gebruik word.',
    zu: 'Hlola idolobhana bese uthola ama-NPC amathathu, ngamunye efundisa isu lokonga amanzi elisetshenziswa emakhaya eNingizimu Afrika.',
    st: 'Hlahloba motse mme o fumane li-NPC tse tharo, e \'ngoe le e \'ngoe e ruta mokhoa oa \'nete oa ho boloka metsi lapeng Afrika Boroa.',
    tn: 'Sekaseka motsana mme o bone di-NPC tse tharo, nngwe le nngwe e ruta mokgwa wa mmatota wa go boloka metsi mo lelapeng go ralala Aforika Borwa.',
    xh: 'Hlola ilali ufumane ii-NPC ezintathu, nganye ifundisa iindlela zokwenyani zokulondoloza amanzi emakhaya kulo lonke elaseMzantsi Afrika.',
    ve: 'Ṱolani muḓana nahone ni wane vha-NPC vhararu, muṅwe na muṅwe a tshi funza maitele a vhukuma a u vhulunga madi hayani ngei Afrika Tshipembe.'
  },
  onboardingControls: {
    en: 'WASD / Arrow Keys to move, E to interact. Complete all three to become a Water Guardian.',
    af: 'WASD / pyltjies om te beweeg, E om te interaksie. Voltooi al drie om \'n Waterwagter te word.',
    zu: 'WASD / Izinkinobho zemicibisholo ukunyakaza, E ukuxhumana. Qedela konke okuthathu ube nguMlondolozi Wamanzi.',
    st: 'WASD / Linotlolo tsa metsu ho tsamaea, E ho sebelisana. Phethela tsohle tse tharo ho ba Molebeli oa Metsi.',
    tn: 'WASD / Dikonopo tsa metsu go tsamaya, E go dirisana. Fetsa tsotlhe tse tharo go nna Motlhokomedi wa Metsi.',
    xh: 'WASD / Amaqhosha eentolo ukuhamba, E ukusebenzisana. Gqiba zontathu ukuze ube nguMgcini wamaNzi.',
    ve: 'WASD / Vhukovhe ha musevhe u tshimbila, E u ṱanganedzana. Fhedzisani zwoṱhe zwiraru u vha Mulindi wa Madi.'
  },
  onboardingBtn: {
    en: 'Start Exploring', af: 'Begin Verken', zu: 'Qala Ukuhlola', st: 'Qala ho Hlahloba',
    tn: 'Simolola go Sekaseka', xh: 'Qalisa Ukuhlola', ve: 'Thomani u Ṱola'
  },
  controlsHint: {
    en: 'WASD / Arrow Keys to move  •  E to interact  •  Esc for settings',
    af: 'WASD / Pyltjies om te beweeg  •  E om te interaksie  •  Esc vir instellings',
    zu: 'WASD / Imicibisholo ukunyakaza  •  E ukuxhumana  •  Esc izilungiselelo',
    st: 'WASD / Metsu ho tsamaea  •  E ho sebelisana  •  Esc litlhophiso',
    tn: 'WASD / Metsu go tsamaya  •  E go dirisana  •  Esc dipeelo',
    xh: 'WASD / Iintolo ukuhamba  •  E ukusebenzisana  •  Esc iisethingi',
    ve: 'WASD / Musevhe u tshimbila  •  E u ṱanganedzana  •  Esc zwidodombedzwa'
  },
  hudPoints: { en: 'Points', af: 'Punte', zu: 'Amaphuzu', st: 'Lintlha', tn: 'Dintlha', xh: 'Amanqaku', ve: 'Mabulasi' },
  hudBadges: { en: 'Badges', af: 'Kentekens', zu: 'Amabheji', st: 'Libeji', tn: 'Dibeji', xh: 'Iibheji', ve: 'Vhubeji' },
  hudTime: { en: 'Time', af: 'Tyd', zu: 'Isikhathi', st: 'Nako', tn: 'Nako', xh: 'Ixesha', ve: 'Tshifhinga' },
  onlineLabel: { en: 'Online', af: 'Aanlyn', zu: 'Ku-inthanethi', st: 'Inthaneteng', tn: 'Mo Inthaneteng', xh: 'Kwi-intanethi', ve: 'Kha Inthanete' },
  offlineLabel: { en: 'Offline', af: 'Vanlyn', zu: 'Ngaphandle kwe-inthanethi', st: 'Ntle ho Inthanete', tn: 'Kwa ntle ga Inthanete', xh: 'Ngaphandle kwe-intanethi', ve: 'Nnda ha Inthanete' },
  continueBtn: { en: 'Continue', af: 'Gaan voort', zu: 'Qhubeka', st: 'Tsoela pele', tn: 'Tswelela', xh: 'Qhubeka', ve: 'Bvelani phanḓa' },
  playAgainBtn: { en: 'Play Again', af: 'Speel Weer', zu: 'Dlala Futhi', st: 'Bapala Hape', tn: 'Tshameka Gape', xh: 'Dlala Kwakhona', ve: 'Tambani Hafhu' },
  nextBtn: { en: 'Next', af: 'Volgende', zu: 'Okulandelayo', st: 'E latelang', tn: 'E e latelang', xh: 'Okulandelayo', ve: 'I tevhelaho' },
  finishBtn: { en: 'Finish', af: 'Voltooi', zu: 'Qedela', st: 'Qeta', tn: 'Fetsa', xh: 'Gqibezela', ve: 'Fhedzisa' },
  settingsTitle: { en: 'Settings', af: 'Instellings', zu: 'Izilungiselelo', st: 'Litlhophiso', tn: 'Dipeelo', xh: 'Iisethingi', ve: 'Zwidodombedzwa' },
  settingsSpeed: { en: 'Movement Speed', af: 'Beweeg-spoed', zu: 'Isivinini Sokunyakaza', st: 'Lebelo la ho Tsamaea', tn: 'Lobelo lwa go Tsamaya', xh: 'Isantya Sokuhamba', ve: 'Luvhilo lwa u Tshimbila' },
  settingsCamera: { en: 'Camera / Eye Angle', af: 'Kamera-hoek', zu: 'I-engile Yekhamera', st: 'Sekhahla sa Khamera', tn: 'Sekgele sa Khamera', xh: 'I-engile Yekhamera', ve: 'Engele ya Khamera' },
  settingsVolume: { en: 'Sound Volume', af: 'Klankvolume', zu: 'Ivolomu Yomsindo', st: 'Boholo ba Molumo', tn: 'Bogolo jwa Modumo', xh: 'Ivolyum Yesandi', ve: 'Volumu ya Mubvumo' },
  settingsMusic: { en: 'Background Music', af: 'Agtergrondmusiek', zu: 'Umculo Wangemuva', st: 'Mmino oa Setlammuso', tn: 'Mmino wa Kwa Morago', xh: 'Umculo Wangemva', ve: 'Muzika wa Murangaphanḓa' },
  settingsVoice: { en: 'Spoken Instructions', af: 'Gesproke Instruksies', zu: 'Imiyalelo Ekhulunywayo', st: 'Litaelo tse Buuoang', tn: 'Ditaelo tse di Buiwang', xh: 'Imiyalelo Ethethiweyo', ve: 'Ndaela dzo Ambiwaho' },
  settingsGraphics: { en: 'Environment Detail', af: 'Omgewingsdetail', zu: 'Imininingwane Yendawo', st: 'Lintlha tsa Tikoloho', tn: 'Dintlha tsa Tikologo', xh: 'Iinkcukacha Zendawo', ve: 'Zwidodombedzwa zwa Tsika' },
  settingsLanguage: { en: 'Language', af: 'Taal', zu: 'Ulimi', st: 'Puo', tn: 'Puo', xh: 'Ulwimi', ve: 'Luambo' },
  settingsClose: { en: 'Close', af: 'Maak toe', zu: 'Vala', st: 'Koala', tn: 'Tswala', xh: 'Vala', ve: 'Valani' },
  gearTitle: { en: 'Settings', af: 'Instellings', zu: 'Izilungiselelo', st: 'Litlhophiso', tn: 'Dipeelo', xh: 'Iisethingi', ve: 'Zwidodombedzwa' },
  badgeEarnedPrefix: { en: 'Badge earned', af: 'Kenteken verdien', zu: 'Ibheji Etholiwe', st: 'Beji e Fumanoeng', tn: 'Beji e Bonwe', xh: 'Ibheji Efunyenwe', ve: 'Bulasi ho Wanwa' },
  welcomeBack: {
    en: 'Welcome back! Points: {p}, Badges: {b}. Head to any NPC to continue.',
    af: 'Welkom terug! Punte: {p}, Kentekens: {b}. Gaan na enige karakter om voort te gaan.',
    zu: 'Wamukelekile futhi! Amaphuzu: {p}, Amabheji: {b}. Yiya kunoma yiliphi ithumbu ukuqhubeka.',
    st: 'Rea u amohela hape! Lintlha: {p}, Libeji: {b}. Ea ho NPC leha e le efe ho tsoela pele.',
    tn: 'O amogetswe gape! Dintlha: {p}, Dibeji: {b}. Ya kwa go NPC epe go tswelela.',
    xh: 'Wamkelekile kwakhona! Amanqaku: {p}, Iibheji: {b}. Yiya kuye nayiphi na i-NPC ukuqhubeka.',
    ve: 'Ni khou u ṱanganedza hafhu! Mabulasi: {p}, Vhubeji: {b}. Iyani kha NPC ifhio na ifhio u bvela phanḓa.'
  }
};

let currentLang = 'en';

function t(key, vars) {
  const entry = TRANSLATIONS[key];
  let str = entry ? (entry[currentLang] || entry.en) : key;
  if (vars) {
    Object.keys(vars).forEach((k) => { str = str.split(`{${k}}`).join(vars[k]); });
  }
  return str;
}

function setLanguage(code) {
  if (LANGS[code]) currentLang = code;
}

/* ---- tx(): translate dynamic in-game text (instructions, prompts, feedback) ----
   The English sentence is the key (with {placeholders}); TX holds EN/AF
   translations. Other selected languages fall back to English for this
   layer (see settings note) rather than showing an untranslated key. */
const TX = {};
function txAdd(entries) {
  entries.forEach(([en, af]) => { TX[en] = { af }; });
}

function tx(en, vars) {
  if (typeof en !== 'string' || !en) return en;
  let s = en;
  if (currentLang !== 'en') {
    const e = TX[en];
    if (e && e[currentLang]) s = e[currentLang];
  }
  if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
  return s;
}

txAdd([
  ['OBJECTIVE:', 'DOEL:'],
  ['Not quite!', 'Nie heeltemal nie!'],
  ['What happened:', 'Wat gebeur het:'],
  ['Do this instead:', 'Doen eerder dit:'],
  ['Why it matters:', 'Hoekom dit saak maak:'],
  ['Penalty:', 'Boete:'],
  ['−{n} points', '−{n} punte'],
  ['Paused', 'Gepouseer'],
  ['Resume', 'Hervat'],
  ['Journal & Progress', 'Joernaal & Vordering'],
  ['Quit to Desktop', 'Sluit af'],
  ['Click again to save & quit', 'Klik weer om te stoor en af te sluit'],
  ['Reset Progress', 'Herstel Vordering'],
  ['Saved progress', 'Gestoorde vordering'],
  ['Play my own music', 'Speel my eie musiek'],
  ['Add songs from my computer…', 'Voeg liedjies van my rekenaar by…'],
  ['Next song', 'Volgende liedjie'],
  ['Update facts', 'Werk feite by'],
  ['Continue', 'Gaan voort'],
  ['Points for this stage', 'Punte vir hierdie fase'],
  ['Controls for this task', 'Beheer vir hierdie taak'],
  ['Start', 'Begin'],
  ['Choose an answer', 'Kies \'n antwoord'],
  ['Question {n} of {t}', 'Vraag {n} van {t}'],
  ['Practice — 0', 'Oefening — 0'],
  ['Practice replay — no points', 'Oefenspel — geen punte'],
  ['Quiz points for this stage were already earned', 'Vasvrapunte vir hierdie fase is reeds verdien'],
  ['+{n} Points! Correct Answer', '+{n} Punte! Korrekte antwoord'],
  ['Correct Answer! {r}', 'Korrekte antwoord! {r}'],
  ['Not quite — no points. The correct answer is highlighted.', 'Nie heeltemal nie — geen punte. Die korrekte antwoord is uitgelig.'],
  ['Next question ▸', 'Volgende vraag ▸'],
  ['See results ▸', 'Sien uitslae ▸'],
  ['Quiz complete', 'Vasvra voltooi'],
  ['correct', 'korrek'],
  ['Practice replay — no points awarded.', 'Oefenspel — geen punte toegeken nie.'],
  ['Quiz points earned:', 'Vasvrapunte verdien:'],
  ['Perfect score — you really know your water-saving!', 'Perfekte telling — jy ken jou waterbesparing!'],
  ['Good work — check the Facts Journal (J) for the explanations you missed.', 'Goeie werk — kyk na die Feite-joernaal (J) vir die verduidelikings wat jy gemis het.'],
  ['Keep going — the Facts Journal (J) has the reasons behind every answer.', 'Hou aan — die Feite-joernaal (J) het die redes agter elke antwoord.'],
  ['Why this matters:', 'Hoekom dit saak maak:'],
  ['Try this at home:', 'Probeer dit tuis:'],
  ['Did you know?', 'Het jy geweet?'],
  ['Continue to quiz ▸', 'Gaan voort na vasvra ▸'],
  ['Congratulations! Badge Unlocked', 'Geluk! Kenteken Ontsluit'],
  ['Congratulations! Badges Unlocked', 'Geluk! Kentekens Ontsluit'],
  ["Press E to talk to {npc}", "Druk E om met {npc} te praat"],
  ["Press E to replay {npc}'s Stage {n} (practice — no points)", "Druk E om {npc} se Fase {n} weer te speel (oefening — geen punte)"],
  ['🔒 {npc} — locked (press E to see what to do first)', '🔒 {npc} — gesluit (druk E om te sien wat om eers te doen)'],
  ['{npc}: "Not yet!"', '{npc}: "Nog nie!"'],
  ['Locked:', 'Gesluit:'],
  ['Tasks are done in order. Finish Stage {n} ({t}) with {npc} first.', 'Take word in volgorde gedoen. Voltooi eers Fase {n} ({t}) by {npc}.'],
  ["Well done! Next: {npc}. Follow the compass to find them, then press E to talk.", "Mooi so! Volgende: {npc}. Volg die kompas om hulle te kry, druk dan E om te praat."],
  ["Fantastic — you have finished every stage! Talk to any character to replay a stage for practice.", "Fantasties — jy het elke fase voltooi! Praat met enige karakter om 'n fase weer te speel vir oefening."],
  ["Don't give up! Go back to {npc} and press E to try again.", "Moenie moed opgee nie! Gaan terug na {npc} en druk E om weer te probeer."],
  ['Welcome back{name}! Points: {p}, Badges: {b}. Follow the compass to your next stage.', 'Welkom terug{name}! Punte: {p}, Kentekens: {b}. Volg die kompas na jou volgende fase.'],
  ['All challenges complete!', 'Alle uitdagings voltooi!'],
  ['{n} m away', '{n} m weg'],
  ['Badge earned', 'Kenteken verdien'],
  ['TIME LEFT', 'TYD OOR'],
  ["Stage {n} Complete!", "Fase {n} Voltooi!"],
  ["You stored {n}L of rainwater in the tank — roughly enough for one family's daily cooking water.", "Jy het {n}L reënwater in die tenk gestoor — omtrent genoeg vir een gesin se daaglikse kookwater."],
  ['Practice replay — no new points or badges.', "Oefenspel — geen nuwe punte of kentekens nie."],
  ["You stored {a}L out of {b}L before the timer ran out. Try again!", "Jy het {a}L uit {b}L gestoor voor die tyd om was. Probeer weer!"],
  ['Storage Tank {a}/{b}L', 'Opgaartenk {a}/{b}L'],
  ['Press E to pour {a}L into the tank ({b}/{c}L)', 'Druk E om {a}L in die tenk te gooi ({b}/{c}L)'],
  ['Bring a bucket of collected rainwater here (E to pour)', "Bring 'n emmer opgegaarde reënwater hierheen (E om te gooi)"],
  ['The tank only holds {cap}L — {x}L overflowed and was discarded.', 'Die tenk hou net {cap}L — {x}L het oorgeloop en is weggegooi.'],
  ['{a}L stored in the tank ({b}/{c}L)', '{a}L gestoor in die tenk ({b}/{c}L)'],
  ['Press E to place bucket here', 'Druk E om die emmer hier neer te sit'],
  ['Press E to pick up bucket ({n}L) — then carry it to the tank', 'Druk E om die emmer op te tel ({n}L) — dra dit dan na die tenk'],
  ['down at a puddle', 'by \'n plas'],
  ['carrying {n}L', 'dra {n}L'],
  ['empty', 'leeg'],
  ['Bucket: {b} | Tank: {t}L / {c}L', 'Emmer: {b} | Tenk: {t}L / {c}L'],
  ['Press E to switch to {r}  (now: {c})', 'Druk E om te skakel na {r}  (nou: {c})'],
  ['DRAIN', 'AFVOER'], ['TANK', 'TENK'],
  ['Diverter → {r} | Tank: {t}/{c}L | Dirty water in tank: {d}L', 'Aflei-klep → {r} | Tenk: {t}/{c}L | Vuil water in tenk: {d}L'],
  ['→ {r} • {q}', '→ {r} • {q}'],
  ['no rain', 'geen reën'], ['DIRTY', 'VUIL'], ['CLEAR', 'HELDER'],
  ['Your tank holds {n}L of clean rainwater — and only {d}L of dirty water got in.', 'Jou tenk hou {n}L skoon reënwater — en net {d}L vuil water het ingekom.'],
  ['Press E to {a} the overflow valve  (now: {b})', 'Druk E om die oorloopklep te {a}  (nou: {b})'],
  ['OPEN', 'OOP'], ['CLOSE', 'MAAK TOE'], ['CLOSED', 'TOE'],
  ['Press E to fill your bucket from the tank ({t}L in the tank)', 'Druk E om jou emmer uit die tenk te vul ({t}L in die tenk)'],
  ['Press E to water this bed ({h}/{n}L)', 'Druk E om hierdie bedding natte maak ({h}/{n}L)'],
  ['Tank: {t}/{c}L | Bucket: {b}L | Beds watered: {d}/3 | Valve: {v}', 'Tenk: {t}/{c}L | Emmer: {b}L | Beddings natgemaak: {d}/3 | Klep: {v}'],
  ['Overflow valve: {v}', 'Oorloopklep: {v}'],
  ['Bed {h}/{n}L', 'Bedding {h}/{n}L'],
  ['Press E to place pipe ({n} left)', 'Druk E om \'n pyp te lê ({n} oor)'],
  ['Press E to remove pipe (refunds 1 segment)', "Druk E om pyp te verwyder (gee 1 segment terug)"],
  ['Out of pipe segments — remove one elsewhere first', 'Geen pypsegmente oor nie — verwyder eers een elders'],
  ['Pipe segments remaining: {n}', 'Pypsegmente oor: {n}'],
  ['Press E to test the {n} • then 1 = reuse on garden, 2 = send to sewer', 'Druk E om {n} te toets • dan 1 = hergebruik in tuin, 2 = stuur na riool'],
  ['Press E to fit a filter trap on the {n} line', "Druk E om 'n filtervangnet op die {n}-lyn te pas"],
  ['Sample:', 'Monster:'],
  ['Decide:', 'Besluit:'],
  ['Press 1 to reuse it on the garden, or 2 to send it to the sewer.', "Druk 1 om dit in die tuin te hergebruik, of 2 om dit na die riool te stuur."],
  ['{n} should NOT be reused on the garden.', '{n} moet NIE in die tuin hergebruik word nie.'],
  ['{n} is safe to reuse — it should not go to the sewer.', '{n} is veilig om te hergebruik — dit moet nie na die riool gaan nie.'],
  ['Press 2 to send it to the sewer.', 'Druk 2 om dit na die riool te stuur.'],
  ['Press 1 to reuse it on the garden, then fit a filter trap.', "Druk 1 om dit in die tuin te hergebruik, pas dan 'n filtervangnet."],
  ['Press E to switch the valve to {d}  (now: {c})', 'Druk E om die klep na {d} te skakel  (nou: {c})'],
  ['GARDEN', 'TUIN'], ['SEWER', 'RIOOL'],
  ['Valve → {d}', 'Klep → {d}'],
  ['A safe load is coming: {n}.', "'n Veilige lading kom: {n}."],
  ['Careful — an unsafe load is coming: {n}!', "Pasop — 'n onveilige lading kom: {n}!"],
  ['Loads handled: {a}/6 | Right: {r} | Wrong: {w}/{m} | Valve → {d}', 'Ladings hanteer: {a}/6 | Reg: {r} | Verkeerd: {w}/{m} | Klep → {d}'],
  ['{n} went to the garden', '{n} het na die tuin gegaan'],
  ['{n} went to the sewer', '{n} het na die riool gegaan'],
  ['{n} was safe to reuse, but the valve sent it to the sewer.', '{n} was veilig om te hergebruik, maar die klep het dit na die riool gestuur.'],
  ['{n} is unsafe, but the valve sent it to the garden!', '{n} is onveilig, maar die klep het dit na die tuin gestuur!'],
  ['You routed {n} of 6 loads correctly.', 'Jy het {n} van 6 ladings korrek gestuur.'],
  ['Press E to collect unfiltered river water', 'Druk E om ongefiltreerde rivierwater te versamel'],
  ['Press E to collect {n}', 'Druk E om {n} te versamel'],
  ['Press E to install {m} (1/2/3 to choose)', 'Druk E om {m} te installeer (1/2/3 om te kies)'],
  ['Selected: {m} — press 1/2/3 to choose a collected material', 'Gekies: {m} — druk 1/2/3 om \'n versamelde materiaal te kies'],
  ['Press E to pour in the river water', 'Druk E om die rivierwater in te gooi'],
  ['{m} is already installed.', '{m} is reeds geïnstalleer.'],
  ["You haven't collected {m} yet.", 'Jy het nog nie {m} versamel nie.'],
  ['Collect it from its pile (E), then select it with {k}.', "Versamel dit by sy hoop (E), kies dit dan met {k}."],
  ["{m} can't go in yet — that is the wrong order.", '{m} kan nog nie ingaan nie — dit is die verkeerde volgorde.'],
  ['The correct order is {o}. Install {n} next.', 'Die korrekte volgorde is {o}. Installeer {n} volgende.'],
  ['{m} installed in the right order', '{m} geïnstalleer in die regte volgorde'],
  ['Filtering river water... Turbidity: {n} NTU (illustrative) — WHO safe guideline is under 5 NTU', 'Rivierwater word gefiltreer... Troebelheid: {n} NTU (illustratief) — WGO-riglyn is onder 5 NTU'],
  ['River Water', 'Rivierwater'],
  ['Your 3-pot slow sand filter dropped turbidity from ~{a} NTU to {b} NTU — within the WHO guideline.', 'Jou 3-pot-stadige-sandfilter het troebelheid van ~{a} NTU na {b} NTU verlaag — binne die WGO-riglyn.'],
  ["The layers went in the wrong order too many times ({n}), so this filter wouldn't clean the water properly. The correct order is {o}.", "Die lae het te veel keer in die verkeerde volgorde ingegaan ({n}), so hierdie filter sou nie die water behoorlik skoonmaak nie. Die korrekte volgorde is {o}."],
  ['Press E to work at the {s}', 'Druk E om by die {s} te werk'],
  ['The {s} is not the right place for this.', 'Die {s} is nie die regte plek hiervoor nie.'],
  ['Go to the {s} instead.', 'Gaan eerder na die {s}.'],
  ['Fault: {t}', 'Fout: {t}'],
  ['Scenario {a}/{b}', 'Scenario {a}/{b}'],
  ['Fault {a}/{b}', 'Fout {a}/{b}'],
  ['Stage {n} of 3: {t}', 'Fase {n} van 3: {t}'],
  ['{name} — Stage {n} of 3: {t}', '{name} — Fase {n} van 3: {t}'],
  ['(practice — no points)', '(oefening — geen punte)'],
  ['Journey: {d} of 9 stages complete — next: {npc}, Stage {n}', 'Reis: {d} van 9 fases voltooi — volgende: {npc}, Fase {n}'],
  ['All 9 stages complete! Replay any stage for practice.', 'Alle 9 fases voltooi! Speel enige fase weer vir oefening.'],
  ['Stage {n}', 'Fase {n}'],
  ['Total:', 'Totaal:'], ['points', 'punte'], ['badges', 'kentekens'],
  ['No tasks recorded yet — complete a stage to see it here.', 'Nog geen take aangeteken nie — voltooi \'n fase om dit hier te sien.'],
  ['Stage progress', 'Fase-vordering'],
  ['Export my results (CSV)', 'Voer my resultate uit (CSV)'],
  ['Anonymous — your name is not included. Saved only where you choose.', 'Anoniem — jou naam word nie ingesluit nie. Slegs gestoor waar jy kies.'],
  ['Results exported!', 'Resultate uitgevoer!'],
  ['Task history', 'Taak-geskiedenis'],
  ['Completed', 'Voltooi'],
  ['Failed (time up)', 'Misluk (tyd om)'],
  ['Failed (wrong destination)', 'Misluk (verkeerde bestemming)'],
  ['Failed (tank contaminated)', 'Misluk (tenk besoedel)'],
  ['Failed (rain ended)', 'Misluk (reën het opgehou)'],
  ['Failed (flooded)', 'Misluk (oorstroom)'],
  ['Failed (too many wrong loads)', 'Misluk (te veel verkeerde ladings)'],
  ['Failed (garden contaminated)', 'Misluk (tuin besoedel)'],
  ['Failed (wrong layer order)', 'Misluk (verkeerde laag-volgorde)'],
  ["You are offline — showing the facts saved on this device.", "Jy is vanlyn — die feite wat op hierdie toestel gestoor is, word gewys."],
  ['Updating…', 'Besig om by te werk…'],
  ['{n} new facts added to your Journal', '{n} nuwe feite by jou joernaal gevoeg'],
  ['Last updated: {d}', 'Laaste bygewerk: {d}'],
  ['Not updated yet — connect to the internet and press Update.', "Nog nie bygewerk nie — koppel aan die internet en druk Werk By."],
  ['{n} facts discovered • {o} online updates', '{n} feite ontdek • {o} aanlyn-bywerkings'],
  ['Explore signposts, complete challenges, and answer quiz questions to fill this journal with real water-saving facts.', "Verken wegwysers, voltooi uitdagings, en beantwoord vasvraagvrae om hierdie joernaal met regte waterbesparingsfeite te vul."],
  ['Online updates', 'Aanlyn-bywerkings'],
  ['No songs added yet.', 'Nog geen liedjies bygevoeg nie.'],
  ['Turn on "Play my own music" to use your playlist.', 'Skakel "Speel my eie musiek" aan om jou speellys te gebruik.'],
  ['Spoken instructions are not available on this computer, so instructions are shown as text.', 'Gesproke instruksies is nie op hierdie rekenaar beskikbaar nie, so instruksies word as teks gewys.'],
  ['No voice is installed on this computer, so instructions are shown as text only.', 'Geen stem is op hierdie rekenaar geïnstalleer nie, so instruksies word slegs as teks gewys.'],
  ['No matching voice for this language — the closest available voice reads the instructions. Text is always shown too.', "Geen passende stem vir hierdie taal nie — die naaste beskikbare stem lees die instruksies. Teks word ook altyd gewys."],
  ['Voice: {v}', 'Stem: {v}'],
  ['Collect & Store', 'Versamel & Stoor'], ['First-Flush Diverter', 'Eerste-vloei-aflei-klep'], ['Storm Manager', 'Stormbestuurder'],
  ['Pipe Connection', 'Pypverbinding'], ['Source Sorting', 'Bronsortering'], ['Diversion Valve', 'Aflei-klep'],
  ['Build & Filter', 'Bou & Filtreer'], ['Disinfection Bench', 'Ontsmettingsbank'], ['Fault Finder', 'Foutopsporing']
]);

