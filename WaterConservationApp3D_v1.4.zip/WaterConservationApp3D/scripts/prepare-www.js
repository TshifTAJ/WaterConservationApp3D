// Copies the web game into ./www so Capacitor can wrap it as an Android app.
const fs = require('fs'); const path = require('path');
const out = path.join(__dirname, '..', 'www'); const root = path.join(__dirname, '..');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
['index.html', 'style.css', 'manifest.webmanifest', 'sw.js'].forEach((f) => fs.copyFileSync(path.join(root, f), path.join(out, f)));
['js', 'vendor', 'icons'].forEach((d) => fs.cpSync(path.join(root, d), path.join(out, d), { recursive: true }));
console.log('www ready');
