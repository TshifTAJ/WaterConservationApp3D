/* =========================================================================
   i18n — language switcher. English and Afrikaans are highest-confidence.
   isiZulu, Sesotho, Setswana, isiXhosa and Tshivenda are AI-assisted DRAFT
   translations of short UI strings only (not the deeper dialogue/quiz
   content) and are flagged in the settings menu as needing native-speaker
   review before formal/academic use.
   ========================================================================= */

const LANGS = {
  en: { label: 'English' },
  af: { label: 'Afrikaans' },
  zu: { label: 'isiZulu' },
  st: { label: 'Sesotho' },
  tn: { label: 'Setswana' },
  xh: { label: 'isiXhosa' },
  ve: { label: 'Tshivenda' }
};

const TRANSLATIONS = {
  appTitle: {
    en: 'Water Conservation Challenge', af: 'Waterbewaring-uitdaging',
    zu: 'Inselelo Yokonga Amanzi', st: 'Phephetso ea ho Boloka Metsi',
    tn: 'Kgwetlho ya go Boloka Metsi', xh: 'Umceli mngeni Wokulondoloza Amanzi',
    ve: 'Khwetho ya u Vhulunga Madi'
  },
  onboardingTitle: {
    en: 'Welcome to the Water Conservation Challenge', af: 'Welkom by die Waterbewaring-uitdaging',
    zu: 'Wamukelekile Enseleleni Yokonga Amanzi', st: 'Rea u amohela Phephetsong ea ho Boloka Metsi',
    tn: 'O amogetswe mo Kgwetlhong ya go Boloka Metsi', xh: 'Wamkelekile Kumceli mngeni Wokulondoloza Amanzi',
    ve: 'Ni khou u ṱanganedza kha Khwetho ya u Vhulunga Madi'
  },
  onboardingIntro: {
    en: 'Explore the village and find three NPCs, each teaching a real household water-saving technique used across South Africa.',
    af: 'Verken die dorpie en vind drie karakters, elkeen leer \'n regte huishoudelike waterbesparingstegniek wat regoor Suid-Afrika gebruik word.',
    zu: 'Hlola idolobhana bese uthola ama-NPC amathathu, ngamunye efundisa isu lokonga amanzi elisetshenziswa emakhaya eNingizimu Afrika.',
    st: 'Hlahloba motse mme o fumane li-NPC tse tharo, e \'ngoe le e \'ngoe e ruta mokhoa oa \'nete oa ho boloka metsi lapeng Afrika Boroa.',
    tn: 'Sekaseka motsana mme o bone di-NPC tse tharo, nngwe le nngwe e ruta mokgwa wa mmatota wa go boloka metsi mo lelapeng go ralala Aforika Borwa.',
    xh: 'Hlola ilali ufumane ii-NPC ezintathu, nganye ifundisa iindlela zokwenyani zokulondoloza amanzi emakhaya kulo lonke elaseMzantsi Afrika.',
    ve: 'Ṱolani muḓana nahone ni wane vha-NPC vhararu, muṅwe na muṅwe a tshi funza maitele a vhukuma a u vhulunga madi hayani ngei Afrika Tshipembe.'
  },
  onboardingControls: {
    en: 'WASD / Arrow Keys to move, E to interact. Complete all three to become a Water Guardian.',
    af: 'WASD / pyltjies om te beweeg, E om te interaksie. Voltooi al drie om \'n Waterwagter te word.',
    zu: 'WASD / Izinkinobho zemicibisholo ukunyakaza, E ukuxhumana. Qedela konke okuthathu ube nguMlondolozi Wamanzi.',
    st: 'WASD / Linotlolo tsa metsu ho tsamaea, E ho sebelisana. Phethela tsohle tse tharo ho ba Molebeli oa Metsi.',
    tn: 'WASD / Dikonopo tsa metsu go tsamaya, E go dirisana. Fetsa tsotlhe tse tharo go nna Motlhokomedi wa Metsi.',
    xh: 'WASD / Amaqhosha eentolo ukuhamba, E ukusebenzisana. Gqiba zontathu ukuze ube nguMgcini wamaNzi.',
    ve: 'WASD / Vhukovhe ha musevhe u tshimbila, E u ṱanganedzana. Fhedzisani zwoṱhe zwiraru u vha Mulindi wa Madi.'
  },
  onboardingBtn: {
    en: 'Start Exploring', af: 'Begin Verken', zu: 'Qala Ukuhlola', st: 'Qala ho Hlahloba',
    tn: 'Simolola go Sekaseka', xh: 'Qalisa Ukuhlola', ve: 'Thomani u Ṱola'
  },
  controlsHint: {
    en: 'WASD / Arrow Keys to move  •  E to interact  •  Esc for settings',
    af: 'WASD / Pyltjies om te beweeg  •  E om te interaksie  •  Esc vir instellings',
    zu: 'WASD / Imicibisholo ukunyakaza  •  E ukuxhumana  •  Esc izilungiselelo',
    st: 'WASD / Metsu ho tsamaea  •  E ho sebelisana  •  Esc litlhophiso',
    tn: 'WASD / Metsu go tsamaya  •  E go dirisana  •  Esc dipeelo',
    xh: 'WASD / Iintolo ukuhamba  •  E ukusebenzisana  •  Esc iisethingi',
    ve: 'WASD / Musevhe u tshimbila  •  E u ṱanganedzana  •  Esc zwidodombedzwa'
  },
  hudPoints: { en: 'Points', af: 'Punte', zu: 'Amaphuzu', st: 'Lintlha', tn: 'Dintlha', xh: 'Amanqaku', ve: 'Mabulasi' },
  hudBadges: { en: 'Badges', af: 'Kentekens', zu: 'Amabheji', st: 'Libeji', tn: 'Dibeji', xh: 'Iibheji', ve: 'Vhubeji' },
  hudTime: { en: 'Time', af: 'Tyd', zu: 'Isikhathi', st: 'Nako', tn: 'Nako', xh: 'Ixesha', ve: 'Tshifhinga' },
  onlineLabel: { en: 'Online', af: 'Aanlyn', zu: 'Ku-inthanethi', st: 'Inthaneteng', tn: 'Mo Inthaneteng', xh: 'Kwi-intanethi', ve: 'Kha Inthanete' },
  offlineLabel: { en: 'Offline', af: 'Vanlyn', zu: 'Ngaphandle kwe-inthanethi', st: 'Ntle ho Inthanete', tn: 'Kwa ntle ga Inthanete', xh: 'Ngaphandle kwe-intanethi', ve: 'Nnda ha Inthanete' },
  continueBtn: { en: 'Continue', af: 'Gaan voort', zu: 'Qhubeka', st: 'Tsoela pele', tn: 'Tswelela', xh: 'Qhubeka', ve: 'Bvelani phanḓa' },
  playAgainBtn: { en: 'Play Again', af: 'Speel Weer', zu: 'Dlala Futhi', st: 'Bapala Hape', tn: 'Tshameka Gape', xh: 'Dlala Kwakhona', ve: 'Tambani Hafhu' },
  nextBtn: { en: 'Next', af: 'Volgende', zu: 'Okulandelayo', st: 'E latelang', tn: 'E e latelang', xh: 'Okulandelayo', ve: 'I tevhelaho' },
  finishBtn: { en: 'Finish', af: 'Voltooi', zu: 'Qedela', st: 'Qeta', tn: 'Fetsa', xh: 'Gqibezela', ve: 'Fhedzisa' },
  settingsTitle: { en: 'Settings', af: 'Instellings', zu: 'Izilungiselelo', st: 'Litlhophiso', tn: 'Dipeelo', xh: 'Iisethingi', ve: 'Zwidodombedzwa' },
  settingsSpeed: { en: 'Movement Speed', af: 'Beweeg-spoed', zu: 'Isivinini Sokunyakaza', st: 'Lebelo la ho Tsamaea', tn: 'Lobelo lwa go Tsamaya', xh: 'Isantya Sokuhamba', ve: 'Luvhilo lwa u Tshimbila' },
  settingsCamera: { en: 'Camera / Eye Angle', af: 'Kamera-hoek', zu: 'I-engile Yekhamera', st: 'Sekhahla sa Khamera', tn: 'Sekgele sa Khamera', xh: 'I-engile Yekhamera', ve: 'Engele ya Khamera' },
  settingsVolume: { en: 'Sound Volume', af: 'Klankvolume', zu: 'Ivolomu Yomsindo', st: 'Boholo ba Molumo', tn: 'Bogolo jwa Modumo', xh: 'Ivolyum Yesandi', ve: 'Volumu ya Mubvumo' },
  settingsMusic: { en: 'Background Music', af: 'Agtergrondmusiek', zu: 'Umculo Wangemuva', st: 'Mmino oa Setlammuso', tn: 'Mmino wa Kwa Morago', xh: 'Umculo Wangemva', ve: 'Muzika wa Murangaphanḓa' },
  settingsVoice: { en: 'Spoken Instructions', af: 'Gesproke Instruksies', zu: 'Imiyalelo Ekhulunywayo', st: 'Litaelo tse Buuoang', tn: 'Ditaelo tse di Buiwang', xh: 'Imiyalelo Ethethiweyo', ve: 'Ndaela dzo Ambiwaho' },
  settingsGraphics: { en: 'Environment Detail', af: 'Omgewingsdetail', zu: 'Imininingwane Yendawo', st: 'Lintlha tsa Tikoloho', tn: 'Dintlha tsa Tikologo', xh: 'Iinkcukacha Zendawo', ve: 'Zwidodombedzwa zwa Tsika' },
  settingsLanguage: { en: 'Language', af: 'Taal', zu: 'Ulimi', st: 'Puo', tn: 'Puo', xh: 'Ulwimi', ve: 'Luambo' },
  settingsClose: { en: 'Close', af: 'Maak toe', zu: 'Vala', st: 'Koala', tn: 'Tswala', xh: 'Vala', ve: 'Valani' },
  gearTitle: { en: 'Settings', af: 'Instellings', zu: 'Izilungiselelo', st: 'Litlhophiso', tn: 'Dipeelo', xh: 'Iisethingi', ve: 'Zwidodombedzwa' },
  badgeEarnedPrefix: { en: 'Badge earned', af: 'Kenteken verdien', zu: 'Ibheji Etholiwe', st: 'Beji e Fumanoeng', tn: 'Beji e Bonwe', xh: 'Ibheji Efunyenwe', ve: 'Bulasi ho Wanwa' },
  welcomeBack: {
    en: 'Welcome back! Points: {p}, Badges: {b}. Head to any NPC to continue.',
    af: 'Welkom terug! Punte: {p}, Kentekens: {b}. Gaan na enige karakter om voort te gaan.',
    zu: 'Wamukelekile futhi! Amaphuzu: {p}, Amabheji: {b}. Yiya kunoma yiliphi ithumbu ukuqhubeka.',
    st: 'Rea u amohela hape! Lintlha: {p}, Libeji: {b}. Ea ho NPC leha e le efe ho tsoela pele.',
    tn: 'O amogetswe gape! Dintlha: {p}, Dibeji: {b}. Ya kwa go NPC epe go tswelela.',
    xh: 'Wamkelekile kwakhona! Amanqaku: {p}, Iibheji: {b}. Yiya kuye nayiphi na i-NPC ukuqhubeka.',
    ve: 'Ni khou u ṱanganedza hafhu! Mabulasi: {p}, Vhubeji: {b}. Iyani kha NPC ifhio na ifhio u bvela phanḓa.'
  }
};

let currentLang = 'en';

function t(key, vars) {
  const entry = TRANSLATIONS[key];
  let str = entry ? (entry[currentLang] || entry.en) : key;
  if (vars) {
    Object.keys(vars).forEach((k) => { str = str.replace(`{${k}}`, vars[k]); });
  }
  return str;
}

function setLanguage(code) {
  if (LANGS[code]) currentLang = code;
}
