/* =========================================================================
   Effects — lightweight, dependency-free "juice" layer: particle bursts
   (droplets / sparkles / confetti), floating "+N" reward popups, and a
   screen flash, all built from primitives already in the scene's budget
   (THREE.Points + small canvas sprites). No textures, no external assets,
   fully offline. Designed to be called from game.js at reward moments.
   ========================================================================= */

const FX = (() => {
  let scene = null;
  let camera = null;
  let domRoot = null;
  const burstGroups = [];   // active THREE.Points bursts
  const popups = [];        // active floating DOM score popups

  function init(sceneRef, cameraRef, domRootId) {
    scene = sceneRef;
    camera = cameraRef;
    domRoot = document.getElementById(domRootId);
  }

  /* ------------------------------ Particle bursts ------------------------------ */
  // A burst is a THREE.Points cloud with per-particle velocity/gravity/life,
  // stored on userData and advanced each frame in update(dt).

  function spawnBurst(position, opts) {
    const o = Object.assign({
      count: 18,
      color: 0x4fb8ff,
      size: 0.09,
      speed: 3.2,
      spread: 1.0,
      gravity: -6,
      life: 0.7,
      upBias: 1.4
    }, opts || {});

    const positions = new Float32Array(o.count * 3);
    const velocities = new Float32Array(o.count * 3);
    for (let i = 0; i < o.count; i++) {
      positions[i * 3] = position.x;
      positions[i * 3 + 1] = position.y;
      positions[i * 3 + 2] = position.z;
      const theta = Math.random() * Math.PI * 2;
      const r = Math.random() * o.speed;
      velocities[i * 3] = Math.cos(theta) * r * o.spread;
      velocities[i * 3 + 1] = Math.random() * o.speed * o.upBias;
      velocities[i * 3 + 2] = Math.sin(theta) * r * o.spread;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: o.color, size: o.size, transparent: true, opacity: 1,
      depthWrite: false, sizeAttenuation: true
    });
    const points = new THREE.Points(geo, mat);
    scene.add(points);

    burstGroups.push({ points, geo, mat, velocities, age: 0, life: o.life, gravity: o.gravity });
  }

  /** Blue water droplets — collection ticks, splashes, pickups. */
  function splash(position) {
    spawnBurst(position, { count: 14, color: 0x3fa8f0, size: 0.08, speed: 2.6, life: 0.55, gravity: -9 });
  }

  /** Warm sparkles — correct quiz answers, fact unlocks, milestones. */
  function sparkle(position) {
    spawnBurst(position, { count: 16, color: 0xffe066, size: 0.07, speed: 2.0, life: 0.8, gravity: -2, upBias: 2.0 });
  }

  /** Multi-colour confetti — badge earned / challenge complete. */
  function confetti(position) {
    const colors = [0xff6b6b, 0xffd93d, 0x6bcB77, 0x4fb8ff, 0xc77dff];
    colors.forEach((c) => spawnBurst(position, {
      count: 10, color: c, size: 0.1, speed: 3.6, life: 1.1, gravity: -4.5, upBias: 1.8
    }));
  }

  function updateBursts(dt) {
    for (let i = burstGroups.length - 1; i >= 0; i--) {
      const b = burstGroups[i];
      b.age += dt;
      const t = b.age / b.life;
      if (t >= 1) {
        scene.remove(b.points);
        b.geo.dispose();
        b.mat.dispose();
        burstGroups.splice(i, 1);
        continue;
      }
      const pos = b.geo.attributes.position.array;
      for (let p = 0; p < pos.length; p += 3) {
        pos[p] += b.velocities[p] * dt;
        pos[p + 1] += b.velocities[p + 1] * dt;
        b.velocities[p + 1] += b.gravity * dt;
        pos[p + 2] += b.velocities[p + 2] * dt;
      }
      b.geo.attributes.position.needsUpdate = true;
      b.mat.opacity = 1 - t;
    }
  }

  /* --------------------------- Floating reward popups --------------------------- */
  // Simple DOM elements projected from world space to screen space each frame,
  // rising and fading — cheaper and crisper than sprite-sheets for short text.

  function worldToScreen(pos) {
    const v = pos.clone().project(camera);
    return {
      x: (v.x * 0.5 + 0.5) * window.innerWidth,
      y: (-v.y * 0.5 + 0.5) * window.innerHeight
    };
  }

  function popupText(worldPos, text, opts) {
    if (!domRoot) return;
    const o = Object.assign({ color: '#7fe0ff', life: 1.1, rise: 46, fontSize: 20 }, opts || {});
    const elDiv = document.createElement('div');
    elDiv.className = 'fx-popup';
    elDiv.textContent = text;
    elDiv.style.color = o.color;
    elDiv.style.fontSize = o.fontSize + 'px';
    domRoot.appendChild(elDiv);
    popups.push({ el: elDiv, world: worldPos.clone(), age: 0, life: o.life, rise: o.rise });
  }

  function updatePopups(dt) {
    for (let i = popups.length - 1; i >= 0; i--) {
      const p = popups[i];
      p.age += dt;
      const t = p.age / p.life;
      if (t >= 1) {
        p.el.remove();
        popups.splice(i, 1);
        continue;
      }
      const screen = worldToScreen(p.world);
      p.el.style.left = screen.x + 'px';
      p.el.style.top = (screen.y - p.rise * t) + 'px';
      p.el.style.opacity = String(1 - t * t);
    }
  }

  /* --------------------------------- Screen flash -------------------------------- */

  function flash(color, durationMs) {
    if (!domRoot) return;
    const f = document.createElement('div');
    f.className = 'fx-flash';
    f.style.background = color || 'rgba(255,255,255,0.35)';
    domRoot.appendChild(f);
    requestAnimationFrame(() => { f.style.opacity = '0'; });
    setTimeout(() => f.remove(), durationMs || 400);
  }

  /* ------------------------------------- Loop ------------------------------------- */

  function update(dt) {
    updateBursts(dt);
    updatePopups(dt);
  }

  return { init, splash, sparkle, confetti, popupText, flash, update };
})();
