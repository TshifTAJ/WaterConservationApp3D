/* =========================================================================
   Water Conservation Challenge — 3D desktop build (Three.js, no engine)
   Implements FR-01..FR-09 from the functional/technical specification.
   Characters are stylised low-poly blocky humanoids (procedurally built
   and animated) rather than photoreal rigged models.
   ========================================================================= */

/* ---------------------------- Renderer / Scene --------------------------- */

const canvas = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8fd0ea);
scene.fog = new THREE.Fog(0x8fd0ea, 60, 170);

const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 500);

/* Settings — persisted in profile.settings, applied live */
const settings = {
  speed: 11,
  cameraAngle: 78, // 0 = close chase cam, 100 = high overhead view — default leans top-down for easier navigation
  volume: 60,
  music: true,
  voice: true,
  graphics: 'standard',
  language: 'en',
  difficulty: 'standard', // relaxed | standard | challenge
  textSize: 'medium' // small | medium | large
};

function difficultyMultiplier() {
  // Applied to time limits and targets so all age groups can find a comfortable pace.
  if (settings.difficulty === 'relaxed') return { time: 1.5, target: 0.8, budget: 1.5 };
  if (settings.difficulty === 'challenge') return { time: 0.8, target: 1.15, budget: 0.75 };
  return { time: 1, target: 1, budget: 1 };
}

function computeCamOffset() {
  const t = settings.cameraAngle / 100;
  const height = 10 + t * 20;  // 10 .. 30
  const back = 11 - t * 8;     // 11 .. 3
  return new THREE.Vector3(0, height, back);
}
let camOffset = computeCamOffset();

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
resize();

const ambient = new THREE.AmbientLight(0xffffff, 0.65);
scene.add(ambient);
const sun = new THREE.DirectionalLight(0xffffff, 0.9);
sun.position.set(40, 60, 20);
scene.add(sun);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(240, 240),
  new THREE.MeshStandardMaterial({ color: 0x5fa25a })
);
ground.rotation.x = -Math.PI / 2;
scene.add(ground);

function zoneTint(x, z, radius, color) {
  const disc = new THREE.Mesh(
    new THREE.CircleGeometry(radius, 32),
    new THREE.MeshStandardMaterial({ color })
  );
  disc.rotation.x = -Math.PI / 2;
  disc.position.set(x, 0.02, z);
  scene.add(disc);
}

const ZONE1 = { x: 0, z: -50 };   // Rainwater
const ZONE2 = { x: -55, z: 30 };  // Greywater
const ZONE3 = { x: 55, z: 30 };   // Filtration

zoneTint(ZONE1.x, ZONE1.z, 22, 0x74c2d6);
zoneTint(ZONE2.x, ZONE2.z, 22, 0x9c8258);
zoneTint(ZONE3.x, ZONE3.z, 22, 0xa88bc9);

/* --------------------------- World dressing --------------------------- */

const keepClearAreas = [
  { x: 0, z: 0, radius: 12 },          // spawn
  { x: ZONE1.x, z: ZONE1.z, radius: 24 },
  { x: ZONE2.x, z: ZONE2.z, radius: 24 },
  { x: ZONE3.x, z: ZONE3.z, radius: 24 },
  { x: 0, z: -25, radius: 6 }, { x: -27, z: 15, radius: 6 }, { x: 27, z: 15, radius: 6 } // path corridors
];

const environmentData = buildEnvironment(scene, keepClearAreas);

let villagers = []; // populated after createHumanoid is defined below

/* Declared early so signposts/NPCs/challenges below can all register into it */
const interactables = []; // { x, z, radius, getPrompt(), interact() }

/* ------------------------------ Label sprites ----------------------------- */

function makeLabel(text) {
  const cnv = document.createElement('canvas');
  cnv.width = 512; cnv.height = 128;
  const ctx = cnv.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(0, 0, cnv.width, cnv.height);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 48px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, cnv.width / 2, cnv.height / 2);
  const tex = new THREE.CanvasTexture(cnv);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(6.4, 1.6, 1);
  return sprite;
}

/* ------------------------------ Humanoid rig ------------------------------ */

const SKIN = 0xe8b98a;

function makeToonGradient() {
  const canvas = document.createElement('canvas');
  canvas.width = 4; canvas.height = 1;
  const ctx = canvas.getContext('2d');
  [70, 140, 200, 255].forEach((v, i) => {
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    ctx.fillRect(i, 0, 1, 1);
  });
  const tex = new THREE.CanvasTexture(canvas);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  return tex;
}
const toonGradient = makeToonGradient();
function toonMat(color) {
  return new THREE.MeshToonMaterial({ color, gradientMap: toonGradient });
}

/**
 * Converts every MeshStandardMaterial already in the scene to a matching
 * cel-shaded MeshToonMaterial, giving the whole world (ground, trees,
 * houses, checkpoints, pots...) a cohesive cartoon look in one pass,
 * rather than hand-editing dozens of individual material definitions.
 */
function cartoonifyScene(root) {
  root.traverse((obj) => {
    if (obj.isMesh && obj.material && obj.material.isMeshStandardMaterial) {
      const old = obj.material;
      const next = new THREE.MeshToonMaterial({
        color: old.color,
        gradientMap: toonGradient,
        transparent: old.transparent,
        opacity: old.opacity,
        side: old.side
      });
      if (old.emissive) { next.emissive = old.emissive; next.emissiveIntensity = old.emissiveIntensity; }
      obj.material = next;
    }
  });
}

function makeLimb(mat, radius, length, pivotY, meshOffsetY) {
  const pivot = new THREE.Group();
  pivot.position.y = pivotY;
  const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 4, 8), mat);
  mesh.position.y = meshOffsetY;
  pivot.add(mesh);
  return { pivot, mesh };
}

/**
 * Builds a stylised, cel-shaded "chibi" cartoon character: oversized head,
 * rounded capsule limbs, simple round eyes. `options.hat` ('cap' | 'wide' |
 * null) gives NPCs a distinguishing, recognisable silhouette.
 */
function createHumanoid(bodyColor, options) {
  const opts = options || {};
  const group = new THREE.Group();
  const matBody = toonMat(bodyColor);
  const matSkin = toonMat(SKIN);

  const leftLeg = makeLimb(matBody, 0.16, 0.34, 0.68, -0.33);
  const rightLeg = makeLimb(matBody, 0.16, 0.34, 0.68, -0.33);
  leftLeg.pivot.position.x = -0.16;
  rightLeg.pivot.position.x = 0.16;

  const leftArm = makeLimb(matSkin, 0.13, 0.30, 1.38, -0.28);
  const rightArm = makeLimb(matSkin, 0.13, 0.30, 1.38, -0.28);
  leftArm.pivot.position.x = -0.44;
  rightArm.pivot.position.x = 0.44;

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.30, 0.22, 4, 10), matBody);
  torso.position.y = 1.09;

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.40, 16, 14), matSkin);
  head.position.y = 1.85;

  const eyeGeo = new THREE.SphereGeometry(0.045, 8, 8);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1a1a1a });
  const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
  leftEye.position.set(-0.15, 1.90, -0.35);
  const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
  rightEye.position.set(0.15, 1.90, -0.35);

  group.add(leftLeg.pivot, rightLeg.pivot, leftArm.pivot, rightArm.pivot, torso, head, leftEye, rightEye);

  if (opts.hat === 'cap') {
    const hat = new THREE.Mesh(new THREE.ConeGeometry(0.36, 0.32, 10), toonMat(opts.hatColor || 0x2255aa));
    hat.position.y = 2.24;
    group.add(hat);
  } else if (opts.hat === 'wide') {
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.52, 0.05, 16), toonMat(opts.hatColor || 0x7a5a30));
    brim.position.y = 2.14;
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 0.24, 12), toonMat(opts.hatColor || 0x7a5a30));
    crown.position.y = 2.28;
    group.add(brim, crown);
  } else if (opts.hat === 'band') {
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.045, 8, 16), toonMat(opts.hatColor || 0xe8a83a));
    band.rotation.x = Math.PI / 2;
    band.position.y = 1.09;
    group.add(band);
  }

  return { group, leftLeg, rightLeg, leftArm, rightArm, torso, head, gestureTimer: 0 };
}

function animateRig(rig, time, moving, dt) {
  if (rig.gestureTimer > 0) {
    rig.gestureTimer -= dt;
    rig.rightArm.pivot.rotation.x = -2.0;
    rig.leftArm.pivot.rotation.x = -0.2;
    rig.leftLeg.pivot.rotation.x = 0;
    rig.rightLeg.pivot.rotation.x = 0;
    return;
  }
  if (moving) {
    const s = Math.sin(time * 8);
    rig.leftLeg.pivot.rotation.x = s * 0.6;
    rig.rightLeg.pivot.rotation.x = -s * 0.6;
    rig.leftArm.pivot.rotation.x = -s * 0.5;
    rig.rightArm.pivot.rotation.x = s * 0.5;
  } else {
    rig.leftLeg.pivot.rotation.x = 0;
    rig.rightLeg.pivot.rotation.x = 0;
    rig.leftArm.pivot.rotation.x = Math.sin(time * 2) * 0.05;
    rig.rightArm.pivot.rotation.x = -Math.sin(time * 2) * 0.05;
    rig.torso.position.y = 1.09 + Math.sin(time * 2) * 0.01;
  }
}

function gesture(rig) {
  rig.gestureTimer = 0.4;
}

villagers = createVillagerWanderers(scene, createHumanoid, [
  { x: -20, z: 10 }, { x: -22, z: 6 }, { x: -16, z: 18 },
  { x: 20, z: -6 }, { x: 22, z: -2 }, { x: 17, z: -16 }
]);

const birds = createBirds(scene, 7);

/* ------------------------- Educational signposts --------------------------- */
/* Optional, exploration-rewarding facts — reinforces the same validated
   citations used in the post-challenge quizzes through spaced repetition,
   discovered by wandering the world rather than only after a challenge. */

function makeSignpost(scene, x, z, factText) {
  const post = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.06, 1.4, 8),
    new THREE.MeshStandardMaterial({ color: 0x5a3c22 })
  );
  post.position.set(x, 0.7, z);
  scene.add(post);

  const board = new THREE.Mesh(
    new THREE.BoxGeometry(1.1, 0.6, 0.08),
    new THREE.MeshStandardMaterial({ color: 0xe8dcc0 })
  );
  board.position.set(x, 1.5, z);
  scene.add(board);

  interactables.push({
    x, z, radius: 2.4,
    getPrompt() { return 'Press E to read the signpost'; },
    interact() { showDialogue(`📋 ${factText}`, 8); unlockFact(factText); }
  });
}

makeSignpost(scene, -12, -2,
  'Did you know? WRC South Africa estimates greywater reuse can save around 50L per household per day — the same amount you route to the garden in the Pipe-Fitter Pete challenge.');
makeSignpost(scene, 12, -30,
  'Did you know? Roughly 73.6% of rural South African households already practise some form of rainwater harvesting (Springer Nature, 2024) — the same technique behind the Water Warden challenge.');

/* ------------------------------- UI helpers -------------------------------- */

const el = (id) => document.getElementById(id);
const promptEl = el('hud-prompt');
const dialogueEl = el('hud-dialogue');
const pointsEl = el('hud-points');
const timerEl = el('hud-timer');
const inventoryEl = el('hud-inventory');
const badgeToastEl = el('badge-toast');
const certificateBtnEl = el('certificate-btn');

let dialogueTimer = 0;
function setPrompt(text) { promptEl.textContent = text || ''; }
function greet() { return profile.playerName ? profile.playerName + ', ' : ''; }
function showDialogue(text, seconds, npcKey) {
  dialogueEl.textContent = text;
  dialogueTimer = seconds;
  if (npcKey) AudioSys.speak(text, npcKey);
}
function setInventory(html) {
  if (html) { inventoryEl.innerHTML = html; inventoryEl.classList.remove('hidden'); }
  else { inventoryEl.classList.add('hidden'); }
}

const objectiveEl = el('hud-objective');
function setObjective(html) {
  objectiveEl.innerHTML = `<b>OBJECTIVE:</b> ${html}`;
  objectiveEl.classList.remove('hidden');
}
function clearObjective() { objectiveEl.classList.add('hidden'); }

/* --------------------------------- Hints ------------------------------------ */
/* Resets to 0 whenever the player successfully interacts with something
   (see the interaction dispatch in the main loop). If nothing meaningful
   happens for a while during an active challenge, offer a gentle nudge. */

let hintTimer = 0;
let hintsGivenThisAttempt = 0;

function updateHintSystem(dt) {
  const anyActive = ch1.state === 'active' || ch2.state === 'active' || ch3.state === 'active';
  if (!anyActive) { hintTimer = 0; hintsGivenThisAttempt = 0; return; }
  hintTimer += dt;
  if (hintTimer > 22 && hintsGivenThisAttempt < 2) {
    hintsGivenThisAttempt++;
    hintTimer = 0;
    showContextualHint();
  }
}

function showContextualHint() {
  let hint = '';
  if (ch1.state === 'active') {
    const waitingOnFlush = ch1.stage >= 2 && ch1.checkpoints.some((cp) => cp.bucketPlaced && cp.flushRemaining > 0);
    hint = waitingOnFlush
      ? 'Hint: that puddle is still running dirty first-flush water — wait for it to turn clean (blue) before collecting.'
      : 'Hint: walk to a glowing puddle, press E to place your bucket, wait for it to fill, then press E again to collect.';
  } else if (ch2.state === 'active') {
    hint = ch2.stage >= 2
      ? 'Hint: press E on grid tiles to lay pipe, and F on a placed pipe to add a filter trap before the destination.'
      : 'Hint: press E on grid tiles to lay pipe segments connecting the sink to the garden.';
  } else if (ch3.state === 'active') {
    hint = ch3.clogged
      ? 'Hint: press E at the filter station to rake the clogged top layer clean.'
      : ch3.awaitingDisinfection
        ? 'Hint: press E at the filter station to add disinfection before the water is safe.'
        : 'Hint: collect the materials from the piles, install them in order at the station, then fetch river water.';
  }
  if (hint) showDialogue(hint, 4.5);
}

/* ------------------------------ Online status ------------------------------ */

const statusEl = el('hud-status');
let isOnline = false;

function refreshOnlineIndicator() {
  statusEl.textContent = (isOnline ? '● ' : '● ') + t(isOnline ? 'onlineLabel' : 'offlineLabel');
  statusEl.style.color = isOnline ? '#6fe86f' : '#c9c9c9';
}

async function probeConnectivity() {
  if (!navigator.onLine) { isOnline = false; refreshOnlineIndicator(); return; }
  try {
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 3000);
    await fetch('https://registry.npmjs.org/', { method: 'HEAD', mode: 'no-cors', signal: ctrl.signal });
    clearTimeout(timeout);
    isOnline = true;
  } catch (e) {
    isOnline = false;
  }
  refreshOnlineIndicator();
}
setInterval(probeConnectivity, 15000);
probeConnectivity();

/* -------------------------------- Minimap ---------------------------------- */

const minimapCanvas = el('minimap');
const mmCtx = minimapCanvas.getContext('2d');
const compassHintEl = el('compass-hint');
const MM_SCALE = 150 / 220; // canvas px per world unit (world spans ~ -110..110)

function worldToMinimap(x, z) {
  return { mx: 75 + x * MM_SCALE, my: 75 + z * MM_SCALE };
}

function drawMinimap() {
  mmCtx.clearRect(0, 0, 150, 150);
  mmCtx.fillStyle = 'rgba(50,90,50,0.9)';
  mmCtx.fillRect(0, 0, 150, 150);

  const zonesInfo = [
    { z: ZONE1, color: '#74c2d6', done: () => profile.challengesCompleted[0] },
    { z: ZONE2, color: '#c9a978', done: () => profile.challengesCompleted[1] },
    { z: ZONE3, color: '#c9a2e8', done: () => profile.challengesCompleted[2] }
  ];
  zonesInfo.forEach((zi) => {
    const p = worldToMinimap(zi.z.x, zi.z.z);
    mmCtx.beginPath();
    mmCtx.arc(p.mx, p.my, 6, 0, Math.PI * 2);
    mmCtx.fillStyle = zi.done() ? '#ffd43b' : zi.color;
    mmCtx.fill();
  });

  const pp = worldToMinimap(player.x, player.z);
  mmCtx.beginPath();
  mmCtx.arc(pp.mx, pp.my, 4, 0, Math.PI * 2);
  mmCtx.fillStyle = '#2559d9';
  mmCtx.fill();
  mmCtx.strokeStyle = '#fff';
  mmCtx.lineWidth = 1;
  mmCtx.stroke();
}

function updateCompassHint() {
  const targets = [
    { pos: ZONE1, label: 'Water Warden', done: profile.challengesCompleted[0] },
    { pos: ZONE2, label: 'Pipe-Fitter Pete', done: profile.challengesCompleted[1] },
    { pos: ZONE3, label: 'Filter Fundi', done: profile.challengesCompleted[2] }
  ].filter((o) => !o.done);

  if (targets.length === 0) { compassHintEl.textContent = 'All challenges complete!'; return; }

  let nearest = targets[0], nearestDist = Infinity;
  targets.forEach((tgt) => {
    const d = dist2D(player.x, player.z, tgt.pos.x, tgt.pos.z);
    if (d < nearestDist) { nearestDist = d; nearest = tgt; }
  });

  const angle = Math.atan2(nearest.pos.x - player.x, nearest.pos.z - player.z) - player.facing;
  const dirs = ['↑', '↗', '→', '↘', '↓', '↙', '←', '↖'];
  const idx = Math.round(((angle % (Math.PI * 2)) + Math.PI * 2) / (Math.PI * 2 / 8)) % 8;
  compassHintEl.textContent = `${dirs[idx]} ${nearest.label} (${Math.round(nearestDist)}m)`;
}

let badgeToastTimer = 0;
function showBadgeToast(label) {
  badgeToastEl.textContent = `🏅 ${t('badgeEarnedPrefix')}: ${label}`;
  badgeToastEl.classList.remove('hidden');
  badgeToastTimer = 3.5;
}

const urgencyVignetteEl = el('urgency-vignette');
let urgencyActive = false;
function setUrgencyVignette(on) {
  if (on === urgencyActive) return;
  urgencyActive = on;
  urgencyVignetteEl.classList.toggle('active', on);
}

/* ----------------------------- Player profile ------------------------------ */

function genId() { return 'p-' + Math.random().toString(36).slice(2, 10); }

let profile = {
  playerId: null,
  playerName: '',
  totalPoints: 0,
  challengesCompleted: [false, false, false],
  badges: [],
  quizScores: { ch1: null, ch2: null, ch3: null },
  retries: { ch1: 0, ch2: 0, ch3: 0 },
  journalFacts: [],
  quizStats: { totalAnswered: 0, totalCorrect: 0 },
  stagesCompleted: { ch1: 0, ch2: 0, ch3: 0 }, // 0..3, highest stage fully completed
  totalPlaySeconds: 0,
  finalEvaluationSeen: false,
  lastSaved: null
};

function unlockFact(text) {
  if (!profile.journalFacts.includes(text)) {
    profile.journalFacts.push(text);
    saveProfile();
  }
}

/**
 * Called when a challenge stage is completed. Records the highest stage
 * reached (capped at 3), advances the challenge's own stage counter so the
 * NPC offers the next stage next time, and triggers the Final Evaluation
 * once all three challenges have reached Stage 3.
 */
function advanceStage(key) {
  const chObj = key === 'ch1' ? ch1 : key === 'ch2' ? ch2 : ch3;
  profile.stagesCompleted[key] = Math.max(profile.stagesCompleted[key], chObj.stage);
  if (chObj.stage < 3) chObj.stage++;
  saveProfile();
  if (profile.stagesCompleted.ch1 >= 3 && profile.stagesCompleted.ch2 >= 3 &&
      profile.stagesCompleted.ch3 >= 3 && !profile.finalEvaluationSeen) {
    setTimeout(() => triggerFinalEvaluation(), 7000);
  }
}

async function loadProfile() {
  try {
    const loaded = await window.api.loadProfile();
    if (loaded) profile = Object.assign(profile, loaded);
  } catch (e) { /* fresh profile, first run */ }
  const isNew = !profile.playerId;
  if (isNew) profile.playerId = genId();
  return isNew;
}

async function saveProfile() {
  profile.lastSaved = new Date().toISOString();
  try { await window.api.saveProfile(profile); } catch (e) { console.error('Save failed', e); }
}

function refreshPointsHud() {
  pointsEl.textContent = `${t('hudPoints')}: ${profile.totalPoints} | ${t('hudBadges')}: ${profile.badges.length}`;
}

function awardBadge(id, label) {
  if (!profile.badges.includes(id)) {
    profile.badges.push(id);
    showBadgeToast(label);
    AudioSys.badge();
  }
}

const CHALLENGE_NAMES = ['first_drop', 'pipe_master', 'filter_fundi'];
const CHALLENGE_LABELS = ['First Drop', 'Pipe Master', 'Filter Fundi'];

function onChallengeComplete(idx, retriesUsed, litresImpact) {
  const wasFirst = !profile.challengesCompleted[idx];
  profile.challengesCompleted[idx] = true;
  profile.totalPoints += 100;
  profile.totalImpactLitres = (profile.totalImpactLitres || 0) + (litresImpact || 0);
  AudioSys.success();

  if (wasFirst) awardBadge(CHALLENGE_NAMES[idx], CHALLENGE_LABELS[idx]);
  if (retriesUsed === 0) awardBadge('flawless_' + idx, 'Flawless: ' + CHALLENGE_LABELS[idx]);
  if (profile.challengesCompleted.every(Boolean)) {
    awardBadge('water_guardian', 'Water Guardian');
    showImpactSummary();
  }

  refreshPointsHud();
  saveProfile();
}

function showImpactSummary() {
  const total = profile.totalImpactLitres || 0;
  const flushes = Math.max(1, Math.round(total / 9));
  const showerMins = Math.max(1, Math.round(total / 9));
  setTimeout(() => {
    showDialogue(
      `🌍 Water Guardian achieved! Across all three challenges you accounted for roughly ${total.toFixed(0)}L of water — ` +
      `approximately equivalent to ${flushes} toilet flushes or about ${showerMins} minutes of shower water. ` +
      `These are the same real household techniques used across South Africa — practised at scale, they add up fast.`,
      12
    );
  }, 6500); // let the challenge's own end-panel/quiz flow finish first
}

/* ------------------------------- Quiz data --------------------------------- */

const QUIZZES = {
  ch1: [
    {
      q: 'About what share of rural South African households already practise rainwater harvesting?',
      options: ['10%', '25%', '73.6%', '50%'],
      correct: 2,
      explain: 'Springer Nature (2024) found roughly 73.6% of rural SA households already practise rainwater harvesting — you just practised the same core technique.'
    },
    {
      q: 'How many litres did the Water Warden ask you to collect?',
      options: ['10L', '25L', '50L', '100L'],
      correct: 2,
      explain: 'The target was 50L, collected across multiple checkpoints before the timer ran out.'
    },
    {
      q: 'Which surface is generally best for collecting clean rainwater at home?',
      options: ['A dusty gravel driveway', 'A clean, sealed roof with gutters', 'Bare soil', 'An open compost heap'],
      correct: 1,
      explain: 'A clean, sealed roof with properly maintained gutters minimises contamination before the water even reaches a storage tank.'
    },
    {
      q: 'What is a simple way to reduce contamination in a rainwater tank?',
      options: [
        'Leave the tank permanently open to the sky',
        'Use a first-flush diverter to discard the initial dirty runoff',
        'Only collect water once a year',
        'Add soil to the tank for filtration'
      ],
      correct: 1,
      explain: 'A first-flush diverter discards the initial, dirtiest runoff (which washes dust and debris off the roof) before clean water reaches storage.'
    },
    {
      q: 'Besides drinking, what is harvested rainwater commonly used for in SA households?',
      options: ['Charging phones', 'Watering gardens and flushing toilets', 'Fuelling vehicles', 'Nothing else'],
      correct: 1,
      explain: 'Non-potable uses like garden irrigation and toilet flushing are the most common uses, reducing demand on municipal supply for tasks that don\'t need treated water.'
    }
  ],
  ch2: [
    {
      q: 'Roughly how much water can greywater reuse save per household per day?',
      options: ['5L', '50L', '500L', '0L'],
      correct: 1,
      explain: 'WRC South Africa estimates greywater reuse saves around 50L/household/day — 45–65% of total household wastewater.'
    },
    {
      q: 'Why does a broken or disconnected pipe path fail the challenge?',
      options: [
        'It looks untidy',
        'Water can\'t reach the destination without a continuous path',
        'The game requires exactly one pipe',
        'It doesn\'t — any layout works'
      ],
      correct: 1,
      explain: 'Just like real plumbing, greywater needs an unbroken route from source to destination (e.g. the garden) to actually flow.'
    },
    {
      q: 'Which of these is typically classified as "greywater" in a home?',
      options: ['Toilet waste', 'Water from showers, basins and laundry', 'Water from kitchen sinks with heavy grease', 'Sewage from septic tanks'],
      correct: 1,
      explain: 'Greywater is gently-used water from showers, basins and laundry — distinct from "blackwater" (toilet waste), which needs full treatment.'
    },
    {
      q: 'What should greywater generally NOT be used for without further treatment?',
      options: ['Watering ornamental plants', 'Flushing toilets', 'Direct drinking', 'Irrigating a lawn'],
      correct: 2,
      explain: 'Untreated greywater can carry soap residue, grease and bacteria — it\'s unsafe to drink even though it\'s fine for irrigation or flushing.'
    },
    {
      q: 'What is one simple household change that reduces greywater contamination?',
      options: [
        'Using biodegradable, low-sodium soaps and detergents',
        'Using more bleach in laundry',
        'Mixing greywater with motor oil',
        'Storing greywater for months before reuse'
      ],
      correct: 0,
      explain: 'Biodegradable, low-sodium products break down more easily and are gentler on soil and plants when the greywater is reused for irrigation.'
    }
  ],
  ch3: [
    {
      q: 'How many pots does the WHO-recommended low-cost household slow sand filter use?',
      options: ['1', '2', '3', '5'],
      correct: 2,
      explain: 'The WHO-recommended design (WHO, 2017) uses a 3-pot system: sand layers on top, gravel in the middle, filtered water collected in the bottom pot.'
    },
    {
      q: 'In the top pot, which layer goes on top of the coarse sand?',
      options: ['Gravel', 'Fine sand', 'Nothing', 'More coarse sand'],
      correct: 1,
      explain: 'Fine sand sits above coarse sand in the top pot — the layering (coarse at base, fine on top) is what makes the filtration effective.'
    },
    {
      q: 'What water clarity measurement does WHO recommend for safe drinking water?',
      options: ['Below 5 NTU (turbidity), ideally under 1 NTU', 'Exactly 50 NTU', 'Turbidity doesn\'t matter', 'Above 100 NTU'],
      correct: 0,
      explain: 'WHO guidelines recommend drinking water turbidity stay below 5 NTU, and ideally under 1 NTU, for effective disinfection and safety.'
    },
    {
      q: 'Why does filtered water still usually need disinfection (e.g. boiling or chlorination)?',
      options: [
        'Filtering alone removes all pathogens',
        'Sand/gravel filtration reduces particles and some microbes but doesn\'t guarantee all pathogens are removed',
        'Disinfection is never needed after filtering',
        'It makes the water taste better only'
      ],
      correct: 1,
      explain: 'Slow sand filtration significantly improves water clarity and reduces microbial load, but WHO still recommends disinfection as a safety backstop.'
    },
    {
      q: 'What does "turbidity" actually measure?',
      options: [
        'The temperature of water',
        'How cloudy/murky water is due to suspended particles',
        'The pH (acidity) of water',
        'The mineral taste of water'
      ],
      correct: 1,
      explain: 'Turbidity measures cloudiness caused by suspended particles — higher turbidity often correlates with more contamination risk.'
    }
  ]
};

function pickQuizSet(key, n) {
  const pool = [...QUIZZES[key]];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, n);
}

/* --------------------------- End panel / quiz flow -------------------------- */

const endPanelEl = el('end-panel');
const endRewardView = el('end-reward-view');
const endQuizView = el('end-quiz-view');
const endTitleEl = el('end-title');
const endMessageEl = el('end-message');
const endContinueBtn = el('end-continue-btn');
const quizProgressEl = el('quiz-progress');
const quizQuestionEl = el('quiz-question');
const quizOptionsEl = el('quiz-options');
const quizFeedbackEl = el('quiz-feedback');
const quizNextBtn = el('quiz-next-btn');

let pendingQuizKey = null;
let quizSet = [];
let quizIndex = 0;
let quizCorrectCount = 0;
let onQuizFinished = null;

function showEndReward(title, message, quizKey, onDone) {
  endPanelEl.classList.remove('hidden');
  endRewardView.classList.remove('hidden');
  endQuizView.classList.add('hidden');
  endTitleEl.textContent = title;
  endMessageEl.textContent = message;
  pendingQuizKey = quizKey;
  onQuizFinished = onDone;
}

endContinueBtn.addEventListener('click', () => {
  endRewardView.classList.add('hidden');
  endQuizView.classList.remove('hidden');
  quizSet = pickQuizSet(pendingQuizKey, Math.min(3, QUIZZES[pendingQuizKey].length));
  quizIndex = 0;
  quizCorrectCount = 0;
  renderQuizQuestion();
});

function renderQuizQuestion() {
  const item = quizSet[quizIndex];
  quizProgressEl.textContent = `Question ${quizIndex + 1} of ${quizSet.length}`;
  quizQuestionEl.textContent = item.q;
  quizFeedbackEl.textContent = '';
  quizNextBtn.classList.add('hidden');
  quizOptionsEl.innerHTML = '';

  item.options.forEach((opt, i) => {
    const btn = document.createElement('div');
    btn.className = 'quiz-option';
    btn.textContent = opt;
    btn.addEventListener('click', () => selectQuizAnswer(i));
    quizOptionsEl.appendChild(btn);
  });
}

function selectQuizAnswer(i) {
  const item = quizSet[quizIndex];
  const buttons = quizOptionsEl.querySelectorAll('.quiz-option');
  buttons.forEach((b) => (b.style.pointerEvents = 'none'));

  profile.quizStats.totalAnswered++;
  if (i === item.correct) {
    buttons[i].classList.add('correct');
    quizCorrectCount++;
    profile.quizStats.totalCorrect++;
    AudioSys.pickup();
  } else {
    buttons[i].classList.add('incorrect');
    buttons[item.correct].classList.add('correct');
    AudioSys.corrective();
  }
  quizFeedbackEl.textContent = item.explain;
  unlockFact(item.explain);
  quizNextBtn.classList.remove('hidden');
  quizNextBtn.textContent = quizIndex < quizSet.length - 1 ? t('nextBtn') : t('finishBtn');
}

quizNextBtn.addEventListener('click', () => {
  if (quizIndex < quizSet.length - 1) {
    quizIndex++;
    renderQuizQuestion();
  } else {
    profile.totalPoints += quizCorrectCount * 10;
    profile.quizScores[pendingQuizKey] = `${quizCorrectCount}/${quizSet.length}`;
    refreshPointsHud();
    saveProfile();
    endPanelEl.classList.add('hidden');
    if (onQuizFinished) onQuizFinished();
  }
});

/* --------------------------------- Player ---------------------------------- */

const playerRig = createHumanoid(0x2559d9);
scene.add(playerRig.group);
playerRig.group.position.set(0, 0, 0);

// A bright, unmistakable facing arrow on the ground so the player always
// knows which way they're heading, regardless of camera angle.
const facingArrowPivot = new THREE.Group();
const facingArrowMesh = new THREE.Mesh(
  new THREE.ConeGeometry(0.32, 1.0, 4),
  new THREE.MeshBasicMaterial({ color: 0xffe767 })
);
facingArrowMesh.rotation.x = -Math.PI / 2;
facingArrowMesh.position.z = -1.1;
facingArrowPivot.add(facingArrowMesh);
facingArrowPivot.position.y = 0.05;
scene.add(facingArrowPivot);

const player = {
  x: 0, z: 0, startX: 0, startZ: 0,
  facing: 0, // radians
  hasBucket: false,
  footstepTimer: 0
};

const keys = {};
let interactJustPressed = false;
let trapKeyJustPressed = false;
window.addEventListener('keydown', (e) => {
  const k = e.key.toLowerCase();
  if (!keys[k] && k === 'e') interactJustPressed = true;
  if (!keys[k] && k === 'f') trapKeyJustPressed = true;
  keys[k] = true;
});
window.addEventListener('keyup', (e) => { keys[e.key.toLowerCase()] = false; });

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function dist2D(ax, az, bx, bz) { return Math.hypot(ax - bx, az - bz); }

/* ----------------------------------- NPCs ----------------------------------- */

function makeNpc(color, x, z, labelText, hatOptions) {
  const rig = createHumanoid(color, hatOptions);
  rig.group.position.set(x, 0, z);
  scene.add(rig.group);
  const label = makeLabel(labelText);
  label.position.set(x, 2.9, z);
  scene.add(label);
  return { rig, x, z, challengeGiven: false };
}

const npc1 = makeNpc(0xe6741a, ZONE1.x, ZONE1.z + 9, 'Water Warden', { hat: 'cap', hatColor: 0x1a5fc4 });
const npc2 = makeNpc(0x1a8f8f, ZONE2.x, ZONE2.z + 9, 'Pipe-Fitter Pete', { hat: 'band', hatColor: 0xe8a83a });
const npc3 = makeNpc(0x7a3fb0, ZONE3.x, ZONE3.z + 9, 'Filter Fundi', { hat: 'wide', hatColor: 0x8a6a3a });

/* ----------------------------- Interaction system ---------------------------- */

function registerNpcInteractable(npcObj, challengeStateGetter, startChallengeFn) {
  interactables.push({
    x: npcObj.x, z: npcObj.z, radius: 3.2,
    getPrompt() {
      if (challengeStateGetter() === 'idle' && !npcObj.challengeGiven) {
        return `Press E to talk to ${npcObj === npc1 ? 'the Water Warden' : npcObj === npc2 ? 'Pipe-Fitter Pete' : 'Filter Fundi'}`;
      }
      return null;
    },
    interact() {
      if (challengeStateGetter() === 'idle' && !npcObj.challengeGiven) {
        npcObj.challengeGiven = true;
        gesture(npcObj.rig);
        startChallengeFn();
      }
    }
  });
}

function findNearestInteractable() {
  let nearest = null, nearestDist = Infinity;
  for (const it of interactables) {
    const d = dist2D(player.x, player.z, it.x, it.z);
    if (d < it.radius && d < nearestDist) { nearest = it; nearestDist = d; }
  }
  return nearest;
}

/* ---------------------------------- Camera ---------------------------------- */

camera.position.set(player.x + camOffset.x, camOffset.y, player.z + camOffset.z);

function updateCamera(dt) {
  const targetPos = new THREE.Vector3(player.x + camOffset.x, camOffset.y, player.z + camOffset.z);
  camera.position.lerp(targetPos, Math.min(1, 12 * dt));
  camera.lookAt(player.x, 1.2, player.z);
}

/* ============================================================================
   CHALLENGE 1 — Rainwater Collection (FR-01)
   Stage 1: core collection loop.
   Stage 2: + first-flush diversion (real technique — the initial dirty roof
            runoff must be discarded before clean water is worth collecting).
   Stage 3: + overflow management (real technique — a full tank's excess is
            diverted to a soak-away bed instead of flooding).
   ============================================================================ */

const CH1_CAP = 20, CH1_RATE = 4;

const ch1 = {
  state: 'idle', // idle | active | complete | failed
  stage: 1,
  total: 0, wasted: 0, timeLeft: 60, target: 50, flushSeconds: 0, retries: 0,
  checkpoints: [], milestonesHit: {},
  needsOverflow: false, overflowDone: false
};

function ch1Params() {
  const dm = difficultyMultiplier();
  const stage = ch1.stage;
  const baseTime = stage === 1 ? 60 : stage === 2 ? 78 : 95;
  return {
    time: Math.round(baseTime * dm.time),
    target: Math.round(50 * dm.target),
    flushSeconds: stage >= 2 ? 4 : 0,
    needsOverflow: stage >= 3
  };
}

const bucketMesh = new THREE.Mesh(
  new THREE.CylinderGeometry(0.22, 0.22, 0.3, 12),
  new THREE.MeshStandardMaterial({ color: 0xf2c81c })
);
scene.add(bucketMesh);

const CP_EMPTY = new THREE.Color(0x9e9ea8);
const CP_FULL = new THREE.Color(0x1a6bf2);
const CP_DIRTY = new THREE.Color(0x6b5230);

function makeCheckpoint(x, z) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(1.6, 1.6, 0.12, 20),
    new THREE.MeshStandardMaterial({ color: CP_EMPTY.getHex() })
  );
  mesh.position.set(x, 0.06, z);
  scene.add(mesh);

  const rainGroup = new THREE.Group();
  const rainDrops = [];
  for (let i = 0; i < 20; i++) {
    const drop = new THREE.Mesh(
      new THREE.BoxGeometry(0.03, 0.25, 0.03),
      new THREE.MeshBasicMaterial({ color: 0x9cd0ff, transparent: true, opacity: 0.85 })
    );
    drop.position.set(x + (Math.random() - 0.5) * 2.6, 3 + Math.random() * 5, z + (Math.random() - 0.5) * 2.6);
    rainDrops.push(drop);
    rainGroup.add(drop);
  }
  scene.add(rainGroup);

  return { x, z, mesh, rainDrops, collected: 0, bucketPlaced: false, flushRemaining: 0 };
}

[[-9, ZONE1.z + 4], [9, ZONE1.z + 4], [0, ZONE1.z - 6]].forEach(([dx, dz]) => {
  ch1.checkpoints.push(makeCheckpoint(ZONE1.x + dx, dz));
});

// Storage tank + soak-away bed — only relevant at Stage 3
const tankMesh = new THREE.Mesh(
  new THREE.CylinderGeometry(1.1, 1.1, 2.2, 14),
  new THREE.MeshStandardMaterial({ color: 0x3a7a9a })
);
tankMesh.position.set(ZONE1.x - 15, 1.1, ZONE1.z - 2);
scene.add(tankMesh);
scene.add((() => { const l = makeLabel('Storage Tank'); l.position.set(tankMesh.position.x, 2.6, tankMesh.position.z); return l; })());

const soakAwayMesh = new THREE.Mesh(
  new THREE.CylinderGeometry(1.6, 1.6, 0.08, 16),
  new THREE.MeshStandardMaterial({ color: 0x6a6a5a })
);
soakAwayMesh.position.set(ZONE1.x - 15, 0.04, ZONE1.z - 8);
scene.add(soakAwayMesh);
scene.add((() => { const l = makeLabel('Soak-Away Bed'); l.position.set(soakAwayMesh.position.x, 1.4, soakAwayMesh.position.z); return l; })());

interactables.push({
  x: tankMesh.position.x, z: tankMesh.position.z, radius: 2.8,
  getPrompt() {
    if (ch1.state === 'active' && ch1.needsOverflow && !ch1.overflowDone && ch1.total >= ch1.target) {
      return 'Press E to open the overflow valve toward the soak-away bed';
    }
    return null;
  },
  interact() {
    if (ch1.state === 'active' && ch1.needsOverflow && !ch1.overflowDone && ch1.total >= ch1.target) {
      ch1.overflowDone = true;
      AudioSys.splash();
      unlockFact('Real technique: a full rainwater tank\'s overflow is piped to a soak-away bed (gravel-filled pit) instead of flooding the yard — it also passively irrigates nearby plants.');
      showDialogue('Overflow safely diverted to the soak-away bed — this prevents flooding and quietly waters the ground around it, just like a real household system.', 5, 'npc1');
      ch1Complete();
    }
  }
});

registerNpcInteractable(npc1, () => ch1.state, ch1Start);

ch1.checkpoints.forEach((cp) => {
  interactables.push({
    x: cp.x, z: cp.z, radius: 2.6,
    getPrompt() {
      if (ch1.state !== 'active') return null;
      if (!cp.bucketPlaced) return player.hasBucket ? 'Press E to place bucket here' : null;
      if (ch1.stage >= 2 && cp.flushRemaining > 0) {
        return `Press E to collect (first-flush still draining, ${cp.flushRemaining.toFixed(1)}s)`;
      }
      return `Press E to collect bucket (${cp.collected.toFixed(1)}L)`;
    },
    interact() {
      if (ch1.state !== 'active') return;
      if (!cp.bucketPlaced && player.hasBucket) {
        cp.bucketPlaced = true;
        cp.collected = 0;
        player.hasBucket = false;
        gesture(playerRig);
        AudioSys.splash();
      } else if (cp.bucketPlaced) {
        if (ch1.stage >= 2 && cp.flushRemaining > 0) {
          ch1.wasted += cp.collected;
          showDialogue('That was dirty first-flush runoff — real systems divert this away automatically. Wait for the puddle to run clean before collecting.', 4, 'npc1');
          AudioSys.corrective();
        } else {
          ch1.total += cp.collected;
          AudioSys.pickup();
        }
        cp.bucketPlaced = false;
        cp.collected = 0;
        player.hasBucket = true;
        gesture(playerRig);
        updateCh1Hud();
      }
    }
  });
});

function ch1Start() {
  const p = ch1Params();
  ch1.state = 'active';
  ch1.timeLeft = p.time;
  ch1.target = p.target;
  ch1.flushSeconds = p.flushSeconds;
  ch1.needsOverflow = p.needsOverflow;
  ch1.overflowDone = false;
  ch1.total = 0;
  ch1.wasted = 0;
  ch1.milestonesHit = {};
  ch1.checkpoints.forEach((cp) => { cp.flushRemaining = p.flushSeconds; });
  player.hasBucket = true;
  timerEl.classList.remove('hidden');

  if (ch1.stage === 1) {
    showDialogue(`Water Warden: "${greet()}Stage 1 — Stand on a puddle to place your bucket, let it fill, then press E to collect it. Bring me 50L before time runs out!"`, 6, 'npc1');
    setObjective(`<b>Stage 1/3.</b> Place your bucket at a puddle, let it fill, collect it. Reach ${ch1.target}L before the timer hits 0.`);
  } else if (ch1.stage === 2) {
    showDialogue(`Water Warden: "${greet()}Stage 2 — Well done! Now watch out: the first water off a roof is always dirty (first-flush). Let each puddle run clean before you collect from it!"`, 7, 'npc1');
    setObjective(`<b>Stage 2/3 — First-Flush Diversion.</b> Each puddle starts dirty. Wait for it to run clean before collecting, or your bucket won't count. Reach ${ch1.target}L.`);
    unlockFact('Real technique: the first flush of rainwater off a roof carries dust, leaves and bird droppings. A first-flush diverter lets you discard it automatically before clean water reaches your tank.');
  } else {
    showDialogue(`Water Warden: "${greet()}Stage 3 — Master level! Once your tank is full, you\'ll need to manage the overflow properly too."`, 7, 'npc1');
    setObjective(`<b>Stage 3/3 — Full System.</b> Divert first-flush, reach ${ch1.target}L, then open the overflow valve at the Storage Tank.`);
  }
  AudioSys.startRain();
  updateCh1Hud();
}

const CH1_MILESTONES = [
  { at: 15, text: '15L collected — that\'s about one bucket-flush of a toilet.' },
  { at: 30, text: '30L collected — enough for a quick 3-minute shower.' },
  { at: 45, text: '45L collected — almost there, keep going!' }
];

function updateCh1Hud() {
  setInventory(`Bucket: ${player.hasBucket ? 'carried' : 'placed'} | Collected: ${ch1.total.toFixed(1)}L / ${ch1.target}L`);
  timerEl.textContent = `Time: ${Math.ceil(Math.max(0, ch1.timeLeft))}s`;
}

function ch1Complete() {
  ch1.state = 'complete';
  timerEl.classList.add('hidden');
  setInventory(null);
  clearObjective();
  AudioSys.stopRain();
  setUrgencyVignette(false);
  onChallengeComplete(0, ch1.retries, ch1.total);
  advanceStage('ch1');
  unlockFact('Try this at home: place a clean bucket or drum under your downpipe next time it rains — even a short shower can fill several litres for garden use.');
  showEndReward(
    `Stage ${ch1.stage > 1 ? ch1.stage - 1 : 1} Complete!`,
    `You collected ${ch1.total.toFixed(1)}L of rainwater — roughly enough for one family's daily cooking water. +100 points!` +
      (ch1.wasted > 0 ? ` (${ch1.wasted.toFixed(1)}L of dirty first-flush water was correctly discarded.)` : '') +
      `\n\n🏠 Try this at home: place a clean bucket or drum under your downpipe next time it rains.`,
    'ch1',
    () => { npc1.challengeGiven = false; ch1.state = 'idle'; }
  );
}

function ch1Fail() {
  ch1.state = 'failed';
  ch1.retries++;
  timerEl.classList.add('hidden');
  setInventory(null);
  clearObjective();
  AudioSys.stopRain();
  setUrgencyVignette(false);
  AudioSys.fail();
  showEndReward(
    "Time's Up!",
    `You collected ${ch1.total.toFixed(1)}L out of ${ch1.target}L. Move quickly between checkpoints and try again!`,
    'ch1',
    () => {
      ch1.checkpoints.forEach((cp) => { cp.bucketPlaced = false; cp.collected = 0; cp.mesh.material.color.copy(CP_EMPTY); });
      player.hasBucket = false;
      npc1.challengeGiven = false;
      ch1.state = 'idle';
    }
  );
}

function updateCh1(dt, time) {
  if (ch1.state === 'active') {
    ch1.checkpoints.forEach((cp) => { if (cp.flushRemaining > 0) cp.flushRemaining = Math.max(0, cp.flushRemaining - dt); });
  }

  ch1.checkpoints.forEach((cp) => {
    if (cp.bucketPlaced && cp.collected < CH1_CAP) {
      cp.collected = Math.min(CH1_CAP, cp.collected + CH1_RATE * dt);
    }
    if (ch1.stage >= 2 && cp.flushRemaining > 0) {
      const dirtT = 1 - (cp.flushRemaining / Math.max(0.001, ch1.flushSeconds));
      cp.mesh.material.color.copy(CP_DIRTY).lerp(CP_EMPTY, dirtT);
    } else {
      const t = cp.collected / CH1_CAP;
      cp.mesh.material.color.copy(CP_EMPTY).lerp(CP_FULL, t);
    }

    if (ch1.state === 'active') {
      cp.rainDrops.forEach((drop) => {
        drop.position.y -= 8 * dt;
        if (drop.position.y < 0.3) {
          drop.position.y = 5 + Math.random() * 3;
          drop.position.x = cp.x + (Math.random() - 0.5) * 2.6;
          drop.position.z = cp.z + (Math.random() - 0.5) * 2.6;
        }
      });
    }

    if (cp.bucketPlaced) {
      bucketMesh.visible = true;
      bucketMesh.position.set(cp.x, 0.2, cp.z);
    }
  });

  if (player.hasBucket) {
    bucketMesh.visible = true;
    const bx = player.x + Math.cos(player.facing + 1) * 0.5;
    const bz = player.z + Math.sin(player.facing + 1) * 0.5;
    bucketMesh.position.set(bx, 0.55, bz);
  } else if (!ch1.checkpoints.some((cp) => cp.bucketPlaced)) {
    bucketMesh.visible = false;
  }

  if (ch1.state === 'active') {
    ch1.timeLeft -= dt;
    CH1_MILESTONES.forEach((m) => {
      if (ch1.total >= m.at && !ch1.milestonesHit[m.at]) {
        ch1.milestonesHit[m.at] = true;
        showDialogue(m.text, 3, 'npc1');
      }
    });
    setUrgencyVignette(ch1.timeLeft <= 10);
    if (ch1.total >= ch1.target && (!ch1.needsOverflow || ch1.overflowDone)) ch1Complete();
    else if (ch1.total >= ch1.target && ch1.needsOverflow && !ch1.overflowDone) {
      setObjective('Tank full! Head to the <b>Storage Tank</b> and press <b>E</b> to open the overflow valve toward the soak-away bed.');
    }
    if (ch1.timeLeft <= 0) { ch1.timeLeft = 0; ch1Fail(); }
    else updateCh1Hud();
  }
}

/* ============================================================================
   CHALLENGE 2 — Greywater Pipe-Routing (FR-02)
   Stage 1: core routing loop.
   Stage 2: + filter/lint trap requirement (real technique — greywater needs
            a simple hair/lint trap before reaching the garden).
   Stage 3: + diversion valve decision (real technique — contaminated loads,
            e.g. with bleach, must be diverted to the sewer, not the garden).
   ============================================================================ */

const CH2_COLS = 5, CH2_ROWS = 3, CH2_CELL = 3.6;
const ch2 = { state: 'idle', stage: 1, retries: 0, grid: [], budget: 0, qualityFlag: 'safe' };

function ch2Budget() {
  const dm = difficultyMultiplier();
  const base = CH2_COLS - 1 + (ch2.stage === 1 ? 2 : ch2.stage === 2 ? 3 : 4);
  return Math.max(3, Math.round(base * dm.budget));
}

const gridOriginX = ZONE2.x - ((CH2_COLS - 1) * CH2_CELL) / 2;
const gridOriginZ = ZONE2.z - 6;

const sinkMesh = new THREE.Mesh(
  new THREE.CylinderGeometry(0.9, 0.9, 0.6, 16),
  new THREE.MeshStandardMaterial({ color: 0x2559d9 })
);
sinkMesh.position.set(gridOriginX, 0.3, gridOriginZ);
scene.add(sinkMesh);
scene.add((() => { const l = makeLabel('Sink (Source)'); l.position.set(gridOriginX, 1.6, gridOriginZ); return l; })());

const gardenMesh = new THREE.Mesh(
  new THREE.ConeGeometry(0.9, 1.1, 8),
  new THREE.MeshStandardMaterial({ color: 0x6b4a2a })
);
gardenMesh.position.set(gridOriginX + (CH2_COLS - 1) * CH2_CELL, 0.55, gridOriginZ);
scene.add(gardenMesh);
scene.add((() => { const l = makeLabel('Garden (Destination)'); l.position.set(gridOriginX + (CH2_COLS - 1) * CH2_CELL, 1.9, gridOriginZ); return l; })());

// Sewer — only gameplay-relevant from Stage 3 onward (diversion valve decision)
const sewerMesh = new THREE.Mesh(
  new THREE.CylinderGeometry(0.85, 0.85, 0.1, 16),
  new THREE.MeshStandardMaterial({ color: 0x4a4a4a })
);
sewerMesh.position.set(gridOriginX + (CH2_COLS - 1) * CH2_CELL, 0.05, gridOriginZ + (0 - 1) * CH2_CELL);
scene.add(sewerMesh);
scene.add((() => { const l = makeLabel('Sewer (Unsafe Loads)'); l.position.set(sewerMesh.position.x, 1.4, sewerMesh.position.z); return l; })());

for (let r = 0; r < CH2_ROWS; r++) {
  for (let c = 0; c < CH2_COLS; c++) {
    const x = gridOriginX + c * CH2_CELL;
    const z = gridOriginZ + (r - 1) * CH2_CELL;
    const isSource = c === 0 && r === 1;
    const isDest = c === CH2_COLS - 1 && r === 1;
    const isSewerDest = c === CH2_COLS - 1 && r === 0;

    const pad = new THREE.Mesh(
      new THREE.BoxGeometry(CH2_CELL * 0.85, 0.08, CH2_CELL * 0.85),
      new THREE.MeshStandardMaterial({ color: 0x7a6142 })
    );
    pad.position.set(x, 0.04, z);
    scene.add(pad);

    const pipe = new THREE.Mesh(
      new THREE.BoxGeometry(CH2_CELL * 0.5, 0.3, CH2_CELL * 0.5),
      new THREE.MeshStandardMaterial({ color: 0xb0b6bd })
    );
    pipe.position.set(x, 0.15, z);
    pipe.visible = isSource || isDest || isSewerDest;
    scene.add(pipe);

    const trapMesh = new THREE.Mesh(
      new THREE.TorusGeometry(0.5, 0.09, 8, 14),
      new THREE.MeshStandardMaterial({ color: 0x3fbf6f })
    );
    trapMesh.rotation.x = Math.PI / 2;
    trapMesh.position.set(x, 0.3, z);
    trapMesh.visible = false;
    scene.add(trapMesh);

    const cell = {
      r, c, x, z,
      hasPipe: isSource || isDest || isSewerDest,
      isSource, isDest, isSewerDest,
      isTrap: false, trapMesh, pipeMesh: pipe
    };
    ch2.grid.push(cell);

    if (!isSource && !isDest && !isSewerDest) {
      interactables.push({
        x, z, radius: CH2_CELL * 0.6,
        getPrompt() {
          if (ch2.state !== 'active') return null;
          if (cell.hasPipe) return 'Press E to remove pipe (refunds 1 segment)' + (ch2.stage >= 2 ? ' • F to toggle filter trap' : '');
          return ch2.budget > 0 ? `Press E to place pipe (${ch2.budget} left)` : 'Out of pipe segments — remove one elsewhere first';
        },
        interact() {
          if (ch2.state !== 'active') return;
          if (!cell.hasPipe) {
            if (ch2.budget <= 0) {
              showDialogue('Pipe-Fitter Pete: "You\'re out of pipe segments! Remove one from a wasted route to reuse it — plan a more direct path."', 3.5, 'npc2');
              AudioSys.corrective();
              return;
            }
            ch2.budget--;
          } else {
            ch2.budget++;
            if (cell.isTrap) { cell.isTrap = false; cell.trapMesh.visible = false; }
          }
          cell.hasPipe = !cell.hasPipe;
          cell.pipeMesh.visible = cell.hasPipe;
          gesture(playerRig);
          AudioSys.pipePlace();
          updateCh2Hud();
          checkCh2Path();
        }
      });
    }
  }
}

function updateCh2TrapKey() {
  if (!(ch2.state === 'active' && ch2.stage >= 2 && trapKeyJustPressed)) return;
  const cell = ch2.grid.find((c) => !c.isSource && !c.isDest && !c.isSewerDest && c.hasPipe && dist2D(player.x, player.z, c.x, c.z) < CH2_CELL * 0.6);
  if (cell) {
    cell.isTrap = !cell.isTrap;
    cell.trapMesh.visible = cell.isTrap;
    gesture(playerRig);
    AudioSys.pipePlace();
    checkCh2Path();
  }
}

function ch2Neighbors(cell) {
  return ch2.grid.filter((o) => o !== cell && ((o.r === cell.r && Math.abs(o.c - cell.c) === 1) || (o.c === cell.c && Math.abs(o.r - cell.r) === 1)));
}

function ch2Bfs(source, target) {
  const visited = new Map([[source, null]]);
  const queue = [source];
  while (queue.length) {
    const cur = queue.shift();
    if (cur === target) {
      const path = [];
      let node = target;
      while (node) { path.unshift(node); node = visited.get(node); }
      return path;
    }
    for (const n of ch2Neighbors(cur)) {
      if (n.hasPipe && !visited.has(n)) { visited.set(n, cur); queue.push(n); }
    }
  }
  return null;
}

function checkCh2Path() {
  const source = ch2.grid.find((c) => c.isSource);
  const gardenCell = ch2.grid.find((c) => c.isDest);
  const sewerCell = ch2.grid.find((c) => c.isSewerDest);
  const wantSewer = ch2.stage === 3 && ch2.qualityFlag === 'contaminated';
  const target = wantSewer ? sewerCell : gardenCell;
  const wrongTarget = ch2.stage === 3 ? (wantSewer ? gardenCell : sewerCell) : null;

  const path = ch2Bfs(source, target);
  if (path) {
    if (ch2.stage >= 2 && !path.some((c) => c.isTrap)) {
      setObjective('Your pipe reaches the destination, but there\'s no <b>filter trap</b> in the line yet. Stand on a placed pipe and press <b>F</b> to add one.');
      return;
    }
    ch2.solvedPath = path;
    ch2Complete();
    return;
  }

  if (wrongTarget) {
    const wrongPath = ch2Bfs(source, wrongTarget);
    if (wrongPath) {
      showDialogue(
        wantSewer
          ? 'Pipe-Fitter Pete: "Wait — that load has bleach in it! Routing it to the garden could harm your plants. Redirect it to the sewer instead."'
          : 'Pipe-Fitter Pete: "This load is perfectly safe — sending it to the sewer wastes good water! Redirect it to the garden."',
        4.5, 'npc2'
      );
      AudioSys.corrective();
    }
  }
}

const flowMarker = new THREE.Mesh(
  new THREE.SphereGeometry(0.28, 12, 12),
  new THREE.MeshStandardMaterial({ color: 0x4fb0f0, emissive: 0x1a4a7a, emissiveIntensity: 0.4 })
);
flowMarker.position.y = 0.35;
flowMarker.visible = false;
scene.add(flowMarker);
let flowProgress = 0;

function updateCh2Flow(dt) {
  if (ch2.state !== 'complete' || !ch2.solvedPath || ch2.solvedPath.length < 2) return;
  flowMarker.visible = true;
  flowProgress += dt * 0.6;
  const segments = ch2.solvedPath.length - 1;
  const total = flowProgress % 1;
  const segFloat = total * segments;
  const segIdx = Math.min(segments - 1, Math.floor(segFloat));
  const segT = segFloat - segIdx;
  const a = ch2.solvedPath[segIdx], b = ch2.solvedPath[segIdx + 1];
  flowMarker.position.x = a.x + (b.x - a.x) * segT;
  flowMarker.position.z = a.z + (b.z - a.z) * segT;
}

registerNpcInteractable(npc2, () => ch2.state, ch2Start);

function ch2Start() {
  ch2.state = 'active';
  ch2.budget = ch2Budget();
  ch2.solvedPath = null;
  flowMarker.visible = false;
  ch2.grid.forEach((c) => {
    if (!c.isSource && !c.isDest && !c.isSewerDest) {
      c.hasPipe = false; c.pipeMesh.visible = false;
      c.isTrap = false; c.trapMesh.visible = false;
    }
  });
  gardenMesh.scale.set(1, 1, 1);
  gardenMesh.material.color.set(0x6b4a2a);

  if (ch2.stage === 1) {
    showDialogue(`Pipe-Fitter Pete: "${greet()}Stage 1 — Walk onto a tile and press E to lay a pipe segment. Connect the sink to the garden efficiently, no gaps allowed!"`, 7, 'npc2');
    setObjective('<b>Stage 1/3.</b> Press <b>E</b> on grid tiles to lay pipe from the sink to the garden. Limited segments — plan a direct route.');
  } else if (ch2.stage === 2) {
    ch2.qualityFlag = 'safe';
    showDialogue(`Pipe-Fitter Pete: "${greet()}Stage 2 — Nicely routed! Now real greywater needs a filter trap for hair and lint before it reaches the garden. Stand on a pipe and press F to add one."`, 8, 'npc2');
    setObjective('<b>Stage 2/3 — Filter Trap.</b> Route the pipe, then press <b>F</b> on one placed pipe tile to add a lint/hair trap before the garden.');
    unlockFact('Real technique: greywater systems include a simple lint/hair trap (or mesh filter) before water reaches the garden, preventing clogging and buildup of organic debris.');
  } else {
    ch2.qualityFlag = Math.random() < 0.5 ? 'safe' : 'contaminated';
    if (ch2.qualityFlag === 'contaminated') {
      showDialogue(`Pipe-Fitter Pete: "${greet()}Stage 3 — Careful, this load has bleach in it! Divert it to the sewer, not the garden — a diversion valve is how real systems handle this."`, 8, 'npc2');
    } else {
      showDialogue(`Pipe-Fitter Pete: "${greet()}Stage 3 — This load is safe and soap-only. Route it to the garden as usual, with your filter trap in place."`, 8, 'npc2');
    }
    setObjective(`<b>Stage 3/3 — Diversion Valve.</b> This load is <b>${ch2.qualityFlag === 'contaminated' ? 'UNSAFE — route to the Sewer' : 'safe — route to the Garden'}</b>. Include a filter trap.`);
    unlockFact('Real technique: a diversion valve lets a household redirect greywater to the sewer instead of the garden whenever the load contains harsh chemicals (like bleach) that could harm plants and soil.');
  }
  updateCh2Hud();
}

function updateCh2Hud() {
  setInventory(`Pipe segments remaining: ${ch2.budget}`);
}

function ch2Complete() {
  ch2.state = 'complete';
  setInventory(null);
  clearObjective();
  const hitGarden = ch2.solvedPath[ch2.solvedPath.length - 1].isDest;
  if (hitGarden) {
    gardenMesh.material.color.set(0x3fae3f);
    gardenMesh.scale.set(1.3, 1.6, 1.3);
  } else {
    sewerMesh.material.color.set(0x2f8f2f);
  }
  onChallengeComplete(1, ch2.retries, 50);
  advanceStage('ch2');
  unlockFact('Try this at home: redirect your bath or laundry rinse water (unscented, low-sodium soap) onto the garden instead of down the drain.');
  showEndReward(
    `Stage ${ch2.stage > 1 ? ch2.stage - 1 : 1} Complete!`,
    (hitGarden
      ? 'The garden is now irrigated with reused greywater — around 50L/day saved for a typical household.'
      : 'Correctly diverted to the sewer — protecting your garden from a contaminated load.') +
      ` +100 points!\n\n🏠 Try this at home: redirect your bath or laundry rinse water (unscented, low-sodium soap) onto the garden instead of down the drain.`,
    'ch2',
    () => { npc2.challengeGiven = false; ch2.state = 'idle'; }
  );
}

/* ============================================================================
   CHALLENGE 3 — Filtration System Build (FR-03)
   Stage 1: core build-and-filter loop.
   Stage 2: + mandatory disinfection step (real technique — filtration alone
            doesn't guarantee pathogen removal; WHO still recommends
            disinfection afterward).
   Stage 3: + maintenance event (real technique — slow sand filters need
            occasional light raking of the top layer, not full teardown).
   ============================================================================ */

const ch3 = {
  state: 'idle', stage: 1, retries: 0,
  inventory: { coarse: false, fine: false, gravel: false, riverWater: false },
  installed: { coarse: false, fine: false, gravel: false },
  order: ['coarse', 'fine', 'gravel'],
  filtering: false, filterProgress: 0,
  needsDisinfection: false, disinfected: false, awaitingDisinfection: false,
  needsMaintenance: false, clogTriggered: false, clogged: false
};

function makePile(x, z, color, label) {
  const mesh = new THREE.Mesh(
    new THREE.ConeGeometry(0.9, 0.9, 10),
    new THREE.MeshStandardMaterial({ color })
  );
  mesh.position.set(x, 0.45, z);
  scene.add(mesh);
  const l = makeLabel(label);
  l.position.set(x, 1.6, z);
  scene.add(l);
  return mesh;
}

const pileCoarse = makePile(ZONE3.x - 10, ZONE3.z - 4, 0xc2a06b, 'Coarse Sand');
const pileFine = makePile(ZONE3.x - 10, ZONE3.z + 4, 0xe8d9a0, 'Fine Sand');
const pileGravel = makePile(ZONE3.x + 10, ZONE3.z - 4, 0x8a8a8a, 'Gravel');

const riverPond = new THREE.Mesh(
  new THREE.CylinderGeometry(2.2, 2.2, 0.1, 20),
  new THREE.MeshStandardMaterial({ color: 0x6b5230, transparent: true, opacity: 0.9 })
);
riverPond.position.set(ZONE3.x + 10, 0.06, ZONE3.z + 6);
scene.add(riverPond);
scene.add((() => { const l = makeLabel('Muddy River'); l.position.set(riverPond.position.x, 1.4, riverPond.position.z); return l; })());

interactables.push({
  x: riverPond.position.x, z: riverPond.position.z, radius: 2.8,
  getPrompt() {
    if (ch3.state !== 'active' || ch3.inventory.riverWater) return null;
    return 'Press E to collect unfiltered river water';
  },
  interact() {
    if (ch3.state !== 'active' || ch3.inventory.riverWater) return;
    ch3.inventory.riverWater = true;
    gesture(playerRig);
    AudioSys.splash();
    updateCh3Hud();
  }
});

[
  { mesh: pileCoarse, key: 'coarse', name: 'Coarse Sand' },
  { mesh: pileFine, key: 'fine', name: 'Fine Sand' },
  { mesh: pileGravel, key: 'gravel', name: 'Gravel' }
].forEach(({ mesh, key, name }) => {
  interactables.push({
    x: mesh.position.x, z: mesh.position.z, radius: 2.2,
    getPrompt() {
      if (ch3.state !== 'active') return null;
      if (ch3.inventory[key]) return null;
      return `Press E to collect ${name}`;
    },
    interact() {
      if (ch3.state !== 'active' || ch3.inventory[key]) return;
      ch3.inventory[key] = true;
      gesture(playerRig);
      AudioSys.pickup();
      updateCh3Hud();
    }
  });
});

// Filter station: 3 stacked pots
const potGroup = new THREE.Group();
potGroup.position.set(ZONE3.x, 0, ZONE3.z - 12);
scene.add(potGroup);

function makePot(y, radiusTop) {
  const pot = new THREE.Mesh(
    new THREE.CylinderGeometry(radiusTop, radiusTop * 0.85, 0.9, 16, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x8b6a4a, side: THREE.DoubleSide })
  );
  pot.position.y = y;
  potGroup.add(pot);
  return pot;
}
makePot(2.2, 1.1);
makePot(1.1, 0.95);
makePot(0.15, 0.8);

const layerCoarseMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.15, 16), new THREE.MeshStandardMaterial({ color: 0xc2a06b }));
layerCoarseMesh.position.set(0, 1.9, 0);
layerCoarseMesh.visible = false;
potGroup.add(layerCoarseMesh);

const layerFineMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.15, 16), new THREE.MeshStandardMaterial({ color: 0xe8d9a0 }));
layerFineMesh.position.set(0, 2.15, 0);
layerFineMesh.visible = false;
potGroup.add(layerFineMesh);

const layerGravelMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.2, 16), new THREE.MeshStandardMaterial({ color: 0x8a8a8a }));
layerGravelMesh.position.set(0, 0.9, 0);
layerGravelMesh.visible = false;
potGroup.add(layerGravelMesh);

// Murky input water, poured on top once all layers are installed
const inputWaterMesh = new THREE.Mesh(
  new THREE.CylinderGeometry(0.95, 0.95, 0.5, 16),
  new THREE.MeshStandardMaterial({ color: 0x6b5230, transparent: true, opacity: 0.88 })
);
inputWaterMesh.position.set(0, 2.55, 0);
inputWaterMesh.visible = false;
potGroup.add(inputWaterMesh);

// Filtered output water, colour transitions from murky to clear as it filters through
const outputWater = new THREE.Mesh(
  new THREE.CylinderGeometry(0.7, 0.7, 0.05, 16),
  new THREE.MeshStandardMaterial({ color: 0x6b5230, transparent: true, opacity: 0.9 })
);
outputWater.position.set(0, 0.05, 0);
potGroup.add(outputWater);

const layerMeshByKey = { coarse: layerCoarseMesh, fine: layerFineMesh, gravel: layerGravelMesh };
const MURKY_COLOR = new THREE.Color(0x6b5230);
const CLEAR_COLOR = new THREE.Color(0x4aa8e8);
const START_TURBIDITY = 220; // illustrative starting value for murky river water
const TARGET_TURBIDITY = 4;  // within WHO guideline of <5 NTU

interactables.push({
  x: potGroup.position.x, z: potGroup.position.z, radius: 3,
  getPrompt() {
    if (ch3.state !== 'active') return null;
    if (ch3.clogged) return 'Press E to rake the clogged top layer clean';
    if (ch3.awaitingDisinfection) return 'Press E to add disinfection (chlorine/boil) before drinking';
    if (ch3.filtering) return null;
    const nextKey = ch3.order.find((k) => !ch3.installed[k]);
    if (nextKey) return `Press E to install ${nextKey === 'coarse' ? 'Coarse Sand' : nextKey === 'fine' ? 'Fine Sand' : 'Gravel'} layer`;
    return 'Press E to pour in the river water';
  },
  interact() {
    if (ch3.state !== 'active') return;

    if (ch3.clogged) {
      ch3.clogged = false;
      gesture(playerRig);
      AudioSys.pipePlace();
      unlockFact('Real technique: slow sand filters grow a thin biological layer (schmutzdecke) on top that does much of the cleaning work — it just needs occasional light raking when flow slows, not full replacement.');
      showDialogue('You gently raked the top layer clean — flow resumes. This light maintenance keeps real slow sand filters working for months.', 4, 'npc3');
      updateCh3Hud();
      return;
    }

    if (ch3.awaitingDisinfection) {
      ch3.disinfected = true;
      ch3.awaitingDisinfection = false;
      gesture(playerRig);
      AudioSys.splash();
      unlockFact('Real technique: even well-filtered water should still be disinfected (boiled or chlorinated) before drinking — filtration reduces particles and some microbes, but WHO (2017) notes it doesn\'t guarantee full pathogen removal on its own.');
      ch3Complete();
      return;
    }

    if (ch3.filtering) return;

    const nextKey = ch3.order.find((k) => !ch3.installed[k]);
    if (nextKey) {
      if (!ch3.inventory[nextKey]) {
        const name = nextKey === 'coarse' ? 'Coarse Sand' : nextKey === 'fine' ? 'Fine Sand' : 'Gravel';
        showDialogue(`You need to collect ${name} first — the layers must go in order: coarse sand, then fine sand, then gravel.`, 3.5, 'npc3');
        AudioSys.corrective();
        return;
      }
      ch3.installed[nextKey] = true;
      layerMeshByKey[nextKey].visible = true;
      gesture(playerRig);
      AudioSys.pipePlace();
      updateCh3Hud();
      return;
    }

    if (!ch3.inventory.riverWater) {
      showDialogue('Filter Fundi: "The filter is built, but you\'ll need to fetch some unfiltered water from the river before we can test it!"', 3.5, 'npc3');
      AudioSys.corrective();
      return;
    }
    ch3.inventory.riverWater = false;
    startFiltering();
  }
});

registerNpcInteractable(npc3, () => ch3.state, ch3Start);

function ch3Start() {
  ch3.state = 'active';
  ch3.inventory = { coarse: false, fine: false, gravel: false, riverWater: false };
  ch3.installed = { coarse: false, fine: false, gravel: false };
  ch3.needsDisinfection = ch3.stage >= 2;
  ch3.disinfected = false;
  ch3.awaitingDisinfection = false;
  ch3.needsMaintenance = ch3.stage >= 3;
  ch3.clogTriggered = false;
  ch3.clogged = false;
  layerCoarseMesh.visible = false;
  layerFineMesh.visible = false;
  layerGravelMesh.visible = false;
  inputWaterMesh.visible = false;
  inputWaterMesh.scale.y = 1;
  outputWater.scale.y = 1;
  outputWater.material.color.copy(MURKY_COLOR);

  if (ch3.stage === 1) {
    showDialogue(`Filter Fundi: "${greet()}Stage 1 — Collect coarse sand, fine sand and gravel, build the layers in that order, then fetch river water to test it!"`, 8, 'npc3');
  } else if (ch3.stage === 2) {
    showDialogue(`Filter Fundi: "${greet()}Stage 2 — Well filtered! But clear doesn\'t always mean safe. This time you\'ll need to disinfect the water after filtering, before it\'s truly drinkable."`, 8, 'npc3');
    unlockFact('Real technique: WHO (2017) recommends disinfection (boiling or chlorination) even after filtration, since filtering alone doesn\'t guarantee all pathogens are removed.');
  } else {
    showDialogue(`Filter Fundi: "${greet()}Stage 3 — Master level! Watch for clogging partway through — real filters need the occasional gentle rake to keep flowing."`, 8, 'npc3');
  }
  updateCh3Hud();
}

function updateCh3Objective() {
  if (ch3.clogged) { setObjective('The top sand layer is clogging! Press <b>E</b> at the filter station to gently rake it clean.'); return; }
  if (ch3.awaitingDisinfection) { setObjective('Filtering complete — press <b>E</b> at the station to add disinfection before the water is truly safe to drink.'); return; }
  if (ch3.filtering) { setObjective('Watch the turbidity reading drop as the murky water filters through your sand and gravel layers.'); return; }
  if (!ch3.installed.coarse) {
    setObjective(`<b>Stage ${ch3.stage}/3.</b> Collect <b>Coarse Sand</b>, <b>Fine Sand</b> and <b>Gravel</b> from the piles around the zone, then bring them to the filter station.`);
  } else if (!ch3.order.every((k) => ch3.installed[k])) {
    const nextKey = ch3.order.find((k) => !ch3.installed[k]);
    const name = nextKey === 'coarse' ? 'Coarse Sand' : nextKey === 'fine' ? 'Fine Sand' : 'Gravel';
    setObjective(`Return to the filter station and press <b>E</b> to install the next layer: <b>${name}</b>.`);
  } else if (!ch3.inventory.riverWater) {
    setObjective('Your filter is built! Now walk to the <b>Muddy River</b> and press <b>E</b> to collect unfiltered water.');
  } else {
    setObjective('Bring the river water back to the filter station and press <b>E</b> to pour it in.');
  }
}

function updateCh3Hud() {
  const inv = (k, n) => ch3.inventory[k] ? `✓ ${n}` : `◻ ${n}`;
  if (ch3.clogged) {
    setInventory('⚠ Top layer clogged — press E at the station to rake it clean.');
  } else if (ch3.awaitingDisinfection) {
    setInventory('Filtered — awaiting disinfection before it\'s safe to drink.');
  } else if (ch3.filtering) {
    const ntu = Math.round(START_TURBIDITY - (START_TURBIDITY - TARGET_TURBIDITY) * Math.min(1, ch3.filterProgress));
    setInventory(`Filtering river water... Turbidity: ${ntu} NTU (illustrative) — WHO safe guideline is under 5 NTU`);
  } else {
    setInventory(`${inv('coarse', 'Coarse Sand')} &nbsp; ${inv('fine', 'Fine Sand')} &nbsp; ${inv('gravel', 'Gravel')} &nbsp; ${inv('riverWater', 'River Water')}`);
  }
  updateCh3Objective();
}

function startFiltering() {
  ch3.filtering = true;
  ch3.filterProgress = 0;
  inputWaterMesh.visible = true;
  AudioSys.splash();
  showDialogue('Filter Fundi pours in the unfiltered river water — watch the turbidity drop as it filters through the sand and gravel!', 4, 'npc3');
  updateCh3Objective();
}

function ch3Complete() {
  ch3.state = 'complete';
  ch3.filtering = false;
  setInventory(null);
  clearObjective();
  onChallengeComplete(2, ch3.retries, 20);
  advanceStage('ch3');
  unlockFact('Try this at home: if your area has a boil-water advisory, remember filtering (like this 3-pot method) reduces particles but you should still disinfect (boil or treat) before drinking.');
  showEndReward(
    `Stage ${ch3.stage > 1 ? ch3.stage - 1 : 1} Complete!`,
    `Your 3-pot slow sand filter dropped turbidity from ~${START_TURBIDITY} NTU to ${TARGET_TURBIDITY} NTU — within the WHO guideline of under 5 NTU.` +
      (ch3.disinfected ? ' You also correctly disinfected it afterward — the fully real-world-correct process.' : '') +
      ` +100 points!\n\n🏠 Try this at home: if your area has a boil-water advisory, remember filtering reduces particles but you should still disinfect (boil or treat) before drinking.`,
    'ch3',
    () => { npc3.challengeGiven = false; ch3.state = 'idle'; }
  );
}

function updateCh3(dt) {
  if (ch3.filtering && !ch3.clogged && !ch3.awaitingDisinfection) {
    ch3.filterProgress += dt / 4;
    const p = Math.min(1, ch3.filterProgress);

    if (ch3.needsMaintenance && !ch3.clogTriggered && p >= 0.5) {
      ch3.clogTriggered = true;
      ch3.clogged = true;
      showDialogue('Filter Fundi: "Flow\'s slowing down — the top layer needs a gentle rake. This happens in real systems too!"', 4, 'npc3');
      AudioSys.corrective();
      updateCh3Hud();
      return;
    }

    inputWaterMesh.scale.y = Math.max(0.02, 1 - p);
    inputWaterMesh.position.y = 2.55 - (1 - inputWaterMesh.scale.y) * 0.25;
    if (p >= 1) inputWaterMesh.visible = false;

    outputWater.scale.y = Math.min(6, 1 + p * 5);
    outputWater.position.y = 0.05 + (outputWater.scale.y - 1) * 0.025;
    outputWater.material.color.copy(MURKY_COLOR).lerp(CLEAR_COLOR, p);

    updateCh3Hud();

    if (p >= 1) {
      if (ch3.needsDisinfection && !ch3.disinfected) {
        ch3.awaitingDisinfection = true;
        updateCh3Hud();
      } else {
        ch3Complete();
      }
    }
  }
}

/* ============================================================================
   Final Evaluation — triggered once all 3 challenges reach Stage 3
   ============================================================================ */

function computeKnowledgeBand() {
  const stats = profile.quizStats;
  const pct = stats.totalAnswered > 0 ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100) : 0;
  let band, critique;
  if (pct >= 90) {
    band = '🏆 Water Champion';
    critique = 'Outstanding grasp of practical water-saving techniques — you consistently applied first-flush diversion, correct greywater routing, and proper filtration/disinfection steps. You clearly understand not just what to do, but why each real-world technique matters.';
  } else if (pct >= 70) {
    band = '🌊 Water Wise';
    critique = 'Solid understanding of the core techniques, with a few gaps. Revisit the Facts Journal (📖) for the explanations behind any quiz questions you missed — the "why" behind each technique is where the real learning value lives.';
  } else if (pct >= 50) {
    band = '💧 Getting There';
    critique = 'You\'ve grasped the basics of each challenge, but several real-world details — like why first-flush water must be discarded, or why greywater needs a diversion valve for unsafe loads — could use reinforcement. Try replaying a challenge stage and reading its Journal facts before the next quiz.';
  } else {
    band = '🚰 Needs Review';
    critique = 'The challenges themselves were completed, but quiz performance suggests the underlying "why" of each technique hasn\'t fully landed yet — completely normal on a first pass. Try reading every signpost, reviewing the Facts Journal, and replaying a stage before attempting its quiz again.';
  }
  return { pct, band, critique };
}

function badgeLabel(id) {
  if (id === 'water_guardian') return 'Water Guardian';
  if (id.startsWith('flawless_')) {
    const idx = parseInt(id.split('_')[1], 10);
    return 'Flawless: ' + CHALLENGE_LABELS[idx];
  }
  const idx = CHALLENGE_NAMES.indexOf(id);
  if (idx >= 0) return CHALLENGE_LABELS[idx];
  return id;
}

function buildCertificateData() {
  const { pct, band, critique } = computeKnowledgeBand();
  const mins = Math.round(profile.totalPlaySeconds / 60);
  return {
    name: profile.playerName || 'Player',
    date: new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }),
    band, pct, critique,
    points: profile.totalPoints,
    badgeCount: profile.badges.length,
    badgeLabels: profile.badges.map(badgeLabel),
    impact: Math.round(profile.totalImpactLitres || 0),
    minutes: mins,
    facts: profile.journalFacts.length,
    techniques: [
      'Rainwater Collection: first-flush diversion + tank overflow management',
      'Greywater Reuse: filter/lint trap + diversion valve decision-making',
      'Filtration System Build: post-filter disinfection + slow sand filter maintenance'
    ]
  };
}

async function saveCertificateFile() {
  if (!window.api || !window.api.saveCertificate) return;
  try {
    showBadgeToast('Generating PDF...');
    const ok = await window.api.saveCertificate(buildCertificateData());
    if (ok) showBadgeToast('Certificate PDF saved!');
  } catch (e) { console.error('Certificate save failed', e); }
}

function triggerFinalEvaluation() {
  profile.finalEvaluationSeen = true;
  saveProfile();

  const { pct, band, critique } = computeKnowledgeBand();
  const mins = Math.round(profile.totalPlaySeconds / 60);
  const name = profile.playerName ? profile.playerName : 'Player';

  el('eval-band').textContent = `${band} — ${pct}% quiz accuracy`;
  el('eval-summary').innerHTML =
    `<div><b>Player:</b> ${name}</div>` +
    `<div><b>Total Points:</b> ${profile.totalPoints}</div>` +
    `<div><b>Badges Earned:</b> ${profile.badges.length}</div>` +
    `<div><b>Quiz Accuracy:</b> ${profile.quizStats.totalCorrect}/${profile.quizStats.totalAnswered} (${pct}%)</div>` +
    `<div><b>Cumulative Water Impact:</b> ~${(profile.totalImpactLitres || 0).toFixed(0)}L</div>` +
    `<div><b>Time Played:</b> ~${mins} minute${mins === 1 ? '' : 's'}</div>` +
    `<div><b>Facts Discovered:</b> ${profile.journalFacts.length}</div>`;
  el('eval-critique').textContent = critique;

  el('evaluation-panel').classList.remove('hidden');
  certificateBtnEl.classList.remove('hidden');
  AudioSys.badge();
}

el('eval-certificate-btn').addEventListener('click', saveCertificateFile);
certificateBtnEl.addEventListener('click', saveCertificateFile);
el('eval-close-btn').addEventListener('click', () => { el('evaluation-panel').classList.add('hidden'); });

/* ============================================================================
   Onboarding (FR-09), Settings menu, i18n refresh, Main loop
   ============================================================================ */

const onboardingEl = el('onboarding');
const settingsPanelEl = el('settings-panel');
let gameStarted = false;

function refreshStaticText() {
  el('onboarding-title').textContent = t('onboardingTitle');
  el('onboarding-intro').textContent = t('onboardingIntro');
  el('onboarding-controls').innerHTML = `<strong>${t('onboardingControls')}</strong>`;
  el('onboarding-start').textContent = t('onboardingBtn');
  el('controls-hint').textContent = t('controlsHint');
  el('settings-title').textContent = t('settingsTitle');
  el('label-speed').textContent = t('settingsSpeed');
  el('label-camera').textContent = t('settingsCamera');
  el('label-volume').textContent = t('settingsVolume');
  el('label-music').textContent = t('settingsMusic');
  el('label-voice').textContent = t('settingsVoice');
  el('label-graphics').textContent = t('settingsGraphics');
  el('label-language').textContent = t('settingsLanguage');
  el('settings-close').textContent = t('settingsClose');
  refreshPointsHud();
  refreshOnlineIndicator();
}

el('onboarding-start').addEventListener('click', () => {
  const nameVal = el('onboarding-name').value.trim();
  if (nameVal) profile.playerName = nameVal.slice(0, 24);
  onboardingEl.classList.add('hidden');
  gameStarted = true;
  AudioSys.unlock();
  AudioSys.startAmbient();
  saveProfile();
});

/* ------------------------------ Settings wiring ----------------------------- */

const speedInput = el('setting-speed');
const cameraInput = el('setting-camera');
const volumeInput = el('setting-volume');
const musicInput = el('setting-music');
const voiceInput = el('setting-voice');
const graphicsInput = el('setting-graphics');
const languageInput = el('setting-language');
const difficultyInput = el('setting-difficulty');
const textSizeInput = el('setting-textsize');

function applySettingsToUI() {
  speedInput.value = settings.speed;
  cameraInput.value = settings.cameraAngle;
  volumeInput.value = settings.volume;
  musicInput.checked = settings.music;
  voiceInput.checked = settings.voice;
  graphicsInput.value = settings.graphics;
  languageInput.value = settings.language;
  difficultyInput.value = settings.difficulty;
  textSizeInput.value = settings.textSize;
}

function applyGraphicsDetail() {
  // minimal: trees/bushes/rocks/birds/villagers hidden (best for low-spec machines)
  // standard: trees + villagers visible, extra decor (rocks/bushes) + birds hidden
  // lush: everything visible
  const tier = settings.graphics;
  const showTrees = tier !== 'minimal';
  const showExtra = tier === 'lush';

  environmentData.foliageForWind.forEach((m) => { m.parent.visible = showTrees; });
  environmentData.extraDecor.forEach((m) => { m.visible = showExtra; });
  villagers.forEach((v) => { v.rig.group.visible = showTrees; });
  birds.forEach((b) => { b.mesh.visible = showExtra; });
}

const uiRootEl = el('ui-root');
function applyTextSize() {
  const zoomMap = { small: 0.85, medium: 1, large: 1.28 };
  if (uiRootEl) uiRootEl.style.zoom = zoomMap[settings.textSize] || 1;
}

function openSettings() { applySettingsToUI(); settingsPanelEl.classList.remove('hidden'); }
function closeSettings() { settingsPanelEl.classList.add('hidden'); saveProfile(); }

el('gear-btn').addEventListener('click', openSettings);
el('settings-close').addEventListener('click', closeSettings);
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (settingsPanelEl.classList.contains('hidden')) openSettings();
    else closeSettings();
  }
  if (e.key.toLowerCase() === 'j' && gameStarted && settingsPanelEl.classList.contains('hidden')) {
    toggleJournal();
  }
});

speedInput.addEventListener('input', () => { settings.speed = parseFloat(speedInput.value); });
cameraInput.addEventListener('input', () => { settings.cameraAngle = parseFloat(cameraInput.value); camOffset = computeCamOffset(); });
volumeInput.addEventListener('input', () => { settings.volume = parseFloat(volumeInput.value); AudioSys.setVolume(settings.volume / 100); });
musicInput.addEventListener('change', () => { settings.music = musicInput.checked; AudioSys.setMusic(settings.music); });
voiceInput.addEventListener('change', () => { settings.voice = voiceInput.checked; AudioSys.setVoiceEnabled(settings.voice); });
graphicsInput.addEventListener('change', () => { settings.graphics = graphicsInput.value; applyGraphicsDetail(); });
languageInput.addEventListener('change', () => { settings.language = languageInput.value; setLanguage(settings.language); refreshStaticText(); });
difficultyInput.addEventListener('change', () => { settings.difficulty = difficultyInput.value; });
textSizeInput.addEventListener('change', () => { settings.textSize = textSizeInput.value; applyTextSize(); });

/* ------------------------------- Journal panel ------------------------------ */

const journalPanelEl = el('journal-panel');
const journalListEl = el('journal-list');
const journalCountEl = el('journal-count');

function renderJournal() {
  journalCountEl.textContent = `${profile.journalFacts.length} fact${profile.journalFacts.length === 1 ? '' : 's'} discovered`;
  if (profile.journalFacts.length === 0) {
    journalListEl.innerHTML = '<div class="journal-empty">Explore signposts, complete challenges, and answer quiz questions to fill this journal with real water-saving facts.</div>';
    return;
  }
  journalListEl.innerHTML = profile.journalFacts.map((f) => `<div class="journal-entry">${f}</div>`).join('');
}

function toggleJournal() {
  if (journalPanelEl.classList.contains('hidden')) {
    renderJournal();
    journalPanelEl.classList.remove('hidden');
  } else {
    journalPanelEl.classList.add('hidden');
  }
}

el('journal-btn').addEventListener('click', toggleJournal);
el('journal-close').addEventListener('click', toggleJournal);


/* ---------------------------------- Boot ------------------------------------ */

cartoonifyScene(scene);

(async function boot() {
  const isNew = await loadProfile();
  if (profile.settings) Object.assign(settings, profile.settings);
  setLanguage(settings.language);
  camOffset = computeCamOffset();
  AudioSys.setVolume(settings.volume / 100);
  AudioSys.setMusic(settings.music);
  AudioSys.setVoiceEnabled(settings.voice);
  applyGraphicsDetail();
  applyTextSize();
  refreshStaticText();
  if (profile.badges.length && !document.hidden) certificateBtnEl.classList.toggle('hidden', !profile.badges.includes('water_guardian'));

  if (isNew) {
    onboardingEl.classList.remove('hidden');
  } else {
    el('onboarding-name').value = profile.playerName || '';
    gameStarted = true;
    const name = profile.playerName ? `, ${profile.playerName}` : '';
    showDialogue(`Welcome back${name}! Points: ${profile.totalPoints}, Badges: ${profile.badges.length}. Head to any NPC to continue.`, 5);
  }
})();

// Persist settings alongside the profile on every save
const _originalSaveProfile = saveProfile;
saveProfile = async function patchedSave() {
  profile.settings = settings;
  return _originalSaveProfile();
};

let lastTime = performance.now();
let minimapTimer = 0;

function update(dt, elapsed) {
  // Movement
  let dx = 0, dz = 0;
  if (keys['a'] || keys['arrowleft']) dx -= 1;
  if (keys['d'] || keys['arrowright']) dx += 1;
  if (keys['w'] || keys['arrowup']) dz -= 1;
  if (keys['s'] || keys['arrowdown']) dz += 1;

  let moving = false;
  if (dx !== 0 || dz !== 0) {
    const len = Math.hypot(dx, dz);
    dx /= len; dz /= len;
    player.x = clamp(player.x + dx * settings.speed * dt, -95, 95);
    player.z = clamp(player.z + dz * settings.speed * dt, -80, 70);
    player.facing = Math.atan2(dx, dz);
    moving = true;

    player.footstepTimer -= dt;
    if (player.footstepTimer <= 0) {
      AudioSys.footstep();
      player.footstepTimer = 0.32;
    }
  }
  playerRig.group.position.set(player.x, 0, player.z);
  playerRig.group.rotation.y = player.facing;
  facingArrowPivot.position.set(player.x, 0.05, player.z);
  facingArrowPivot.rotation.y = player.facing;
  animateRig(playerRig, elapsed, moving, dt);

  animateRig(npc1.rig, elapsed, false, dt);
  animateRig(npc2.rig, elapsed, false, dt);
  animateRig(npc3.rig, elapsed, false, dt);
  updateVillagerWanderers(villagers, dt, elapsed, animateRig);
  updateBirds(birds, elapsed);
  updateEnvironment(environmentData.foliageForWind, elapsed);

  updateCamera(dt);

  // Interaction
  const nearest = findNearestInteractable();
  const prompt = nearest ? nearest.getPrompt() : null;
  setPrompt(prompt);
  if (prompt && interactJustPressed && nearest) { nearest.interact(); hintTimer = 0; hintsGivenThisAttempt = 0; }
  interactJustPressed = false;

  updateCh2TrapKey();
  trapKeyJustPressed = false;

  if (dialogueTimer > 0) {
    dialogueTimer -= dt;
    if (dialogueTimer <= 0) dialogueEl.textContent = '';
  }
  if (badgeToastTimer > 0) {
    badgeToastTimer -= dt;
    if (badgeToastTimer <= 0) badgeToastEl.classList.add('hidden');
  }

  updateCh1(dt, elapsed);
  updateCh2Flow(dt);
  updateCh3(dt);
  updateHintSystem(dt);
  profile.totalPlaySeconds += dt;

  minimapTimer -= dt;
  if (minimapTimer <= 0) {
    drawMinimap();
    updateCompassHint();
    minimapTimer = 0.15;
  }
}

function loop(now) {
  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;
  const elapsed = now / 1000;

  if (gameStarted) {
    if (settingsPanelEl.classList.contains('hidden')) {
      update(dt, elapsed);
    } else {
      // Gameplay is paused, but the camera must still respond live so the
      // player can actually see the effect of dragging the camera-angle slider.
      updateCamera(dt);
      animateRig(playerRig, elapsed, false, dt);
    }
  }
  renderer.render(scene, camera);

  requestAnimationFrame(loop);
}

requestAnimationFrame((t) => {
  lastTime = t;
  requestAnimationFrame(loop);
});
