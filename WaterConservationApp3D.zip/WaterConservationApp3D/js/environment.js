/* =========================================================================
   Environment — procedural low-poly trees, flowers, and a small rural
   village (houses) so the world feels lived-in. Also spawns decorative
   "villager" humanoids that wander gently for atmosphere (no game logic
   attached to them — purely cosmetic life in the scene).
   ========================================================================= */

function distFromAreas(x, z, keepClearAreas) {
  return keepClearAreas.some((a) => Math.hypot(x - a.x, z - a.z) < a.radius);
}

function randomPointInBounds(minX, maxX, minZ, maxZ, keepClearAreas, maxTries) {
  for (let i = 0; i < maxTries; i++) {
    const x = minX + Math.random() * (maxX - minX);
    const z = minZ + Math.random() * (maxZ - minZ);
    if (!distFromAreas(x, z, keepClearAreas)) return { x, z };
  }
  return null;
}

function makeTree(scene, x, z) {
  const group = new THREE.Group();
  const trunkH = 1.4 + Math.random() * 0.8;
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.14, 0.2, trunkH, 6),
    new THREE.MeshStandardMaterial({ color: 0x6b4a2a })
  );
  trunk.position.y = trunkH / 2;
  group.add(trunk);

  const greens = [0x3f8f3f, 0x4aa34a, 0x357a35];
  const foliageMeshes = [];
  const clusters = 2 + Math.floor(Math.random() * 2);
  for (let i = 0; i < clusters; i++) {
    const size = 0.75 + Math.random() * 0.45;
    const foliage = new THREE.Mesh(
      new THREE.IcosahedronGeometry(size, 0),
      new THREE.MeshStandardMaterial({ color: greens[Math.floor(Math.random() * greens.length)] })
    );
    foliage.position.set((Math.random() - 0.5) * 0.6, trunkH + size * 0.55 + i * 0.35, (Math.random() - 0.5) * 0.6);
    group.add(foliage);
    foliageMeshes.push(foliage);
  }

  group.position.set(x, 0, z);
  group.rotation.y = Math.random() * Math.PI * 2;
  scene.add(group);
  return foliageMeshes;
}

function makeFlowerPatch(scene, x, z) {
  const colors = [0xe85f8a, 0xf2c94c, 0xe85f3a, 0xffffff, 0x9b6fd4];
  const group = new THREE.Group();
  const count = 4 + Math.floor(Math.random() * 5);
  for (let i = 0; i < count; i++) {
    const bloom = new THREE.Mesh(
      new THREE.SphereGeometry(0.09, 6, 6),
      new THREE.MeshStandardMaterial({ color: colors[Math.floor(Math.random() * colors.length)] })
    );
    const stem = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015, 0.015, 0.22, 4),
      new THREE.MeshStandardMaterial({ color: 0x3f8f3f })
    );
    const fx = (Math.random() - 0.5) * 1.4, fz = (Math.random() - 0.5) * 1.4;
    stem.position.set(fx, 0.11, fz);
    bloom.position.set(fx, 0.24, fz);
    group.add(stem, bloom);
  }
  group.position.set(x, 0, z);
  scene.add(group);
}

function makeHouse(scene, x, z, rot) {
  const group = new THREE.Group();
  const wallColors = [0xe8dcc0, 0xd9c9a0, 0xecdcc8, 0xd8cbb0];
  const roofColors = [0xa8503a, 0x8a4530, 0xb56a42];

  const w = 3.2 + Math.random() * 1.4;
  const d = 3.0 + Math.random() * 1.2;
  const h = 2.0;

  const walls = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshStandardMaterial({ color: wallColors[Math.floor(Math.random() * wallColors.length)] })
  );
  walls.position.y = h / 2;
  group.add(walls);

  const roof = new THREE.Mesh(
    new THREE.ConeGeometry(Math.max(w, d) * 0.78, 1.3, 4),
    new THREE.MeshStandardMaterial({ color: roofColors[Math.floor(Math.random() * roofColors.length)] })
  );
  roof.rotation.y = Math.PI / 4;
  roof.position.y = h + 0.6;
  group.add(roof);

  const door = new THREE.Mesh(
    new THREE.BoxGeometry(0.7, 1.3, 0.06),
    new THREE.MeshStandardMaterial({ color: 0x5a3c22 })
  );
  door.position.set(0, 0.65, d / 2 + 0.03);
  group.add(door);

  group.position.set(x, 0, z);
  group.rotation.y = rot || 0;
  scene.add(group);
}

function makeRock(scene, x, z) {
  const rock = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.25 + Math.random() * 0.3, 0),
    new THREE.MeshStandardMaterial({ color: 0x8a8a86 })
  );
  rock.position.set(x, 0.15, z);
  rock.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
  scene.add(rock);
  return rock;
}

function makeBush(scene, x, z) {
  const bush = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.4 + Math.random() * 0.25, 0),
    new THREE.MeshStandardMaterial({ color: 0x4a8a3a })
  );
  bush.position.set(x, 0.3, z);
  bush.scale.y = 0.7;
  scene.add(bush);
  return bush;
}

function makeGardenPatch(scene, x, z) {
  const group = new THREE.Group();
  const soil = new THREE.Mesh(
    new THREE.BoxGeometry(4, 0.1, 3),
    new THREE.MeshStandardMaterial({ color: 0x4a3420 })
  );
  soil.position.y = 0.05;
  group.add(soil);

  for (let row = -1; row <= 1; row++) {
    for (let col = -1.5; col <= 1.5; col++) {
      const crop = new THREE.Mesh(
        new THREE.ConeGeometry(0.14, 0.4, 6),
        new THREE.MeshStandardMaterial({ color: 0x3f9f3f })
      );
      crop.position.set(col * 1.1, 0.3, row * 0.9);
      group.add(crop);
    }
  }
  group.position.set(x, 0, z);
  scene.add(group);
}

/**
 * Scatters trees, flower patches, rocks, bushes, and a small rural house
 * cluster (with a garden patch) around the world while avoiding the
 * gameplay zones. Returns groups of decoration for tiered detail settings.
 */
function buildEnvironment(scene, keepClearAreas) {
  const foliageForWind = [];
  const extraDecor = [];

  for (let i = 0; i < 55; i++) {
    const p = randomPointInBounds(-95, 95, -85, 65, keepClearAreas, 8);
    if (p) foliageForWind.push(...makeTree(scene, p.x, p.z));
  }

  for (let i = 0; i < 30; i++) {
    const p = randomPointInBounds(-95, 95, -85, 65, keepClearAreas, 6);
    if (p) makeFlowerPatch(scene, p.x, p.z);
  }

  for (let i = 0; i < 22; i++) {
    const p = randomPointInBounds(-95, 95, -85, 65, keepClearAreas, 6);
    if (p) extraDecor.push(makeRock(scene, p.x, p.z));
  }

  for (let i = 0; i < 26; i++) {
    const p = randomPointInBounds(-95, 95, -85, 65, keepClearAreas, 6);
    if (p) extraDecor.push(makeBush(scene, p.x, p.z));
  }

  // Small rural village cluster near spawn, giving a "lived-in community" feel
  const villageSpots = [
    { x: -18, z: 12, rot: 0.4 }, { x: -24, z: 4, rot: -0.3 }, { x: -14, z: 20, rot: 1.1 },
    { x: 18, z: -8, rot: -0.6 }, { x: 24, z: -2, rot: 0.8 }, { x: 15, z: -18, rot: 0.2 }
  ];
  villageSpots.forEach((s) => makeHouse(scene, s.x, s.z, s.rot));

  // A small vegetable garden — ties the village to the conservation theme:
  // saved water is what keeps these crops alive.
  makeGardenPatch(scene, -20, -6);

  return { foliageForWind, extraDecor };
}

function updateEnvironment(foliageForWind, elapsed) {
  foliageForWind.forEach((mesh, i) => {
    mesh.rotation.z = Math.sin(elapsed * 0.6 + i) * 0.05;
  });
}

/**
 * Spawns decorative villagers who wander slowly within a small radius of
 * their home point. Purely cosmetic — no interaction, no game state.
 */
function createVillagerWanderers(scene, humanoidFactory, spots) {
  const villagerColors = [0x6a4fb0, 0xc06b3a, 0x4f9dbf, 0xbf4f6b, 0x7fbf4f];
  return spots.map((spot, i) => {
    const rig = humanoidFactory(villagerColors[i % villagerColors.length]);
    rig.group.position.set(spot.x, 0, spot.z);
    scene.add(rig.group);
    return {
      rig,
      home: spot,
      target: { x: spot.x, z: spot.z },
      waitTimer: Math.random() * 3
    };
  });
}

function updateVillagerWanderers(villagers, dt, elapsed, animateRigFn) {
  villagers.forEach((v) => {
    const dx = v.target.x - v.rig.group.position.x;
    const dz = v.target.z - v.rig.group.position.z;
    const d = Math.hypot(dx, dz);
    let moving = false;

    if (d > 0.3) {
      const speed = 1.2;
      v.rig.group.position.x += (dx / d) * speed * dt;
      v.rig.group.position.z += (dz / d) * speed * dt;
      v.rig.group.rotation.y = Math.atan2(dx, dz);
      moving = true;
    } else {
      v.waitTimer -= dt;
      if (v.waitTimer <= 0) {
        v.target = {
          x: v.home.x + (Math.random() - 0.5) * 8,
          z: v.home.z + (Math.random() - 0.5) * 8
        };
        v.waitTimer = 2 + Math.random() * 4;
      }
    }
    animateRigFn(v.rig, elapsed + villagers.indexOf(v), moving, dt);
  });
}

/**
 * Spawns a handful of simple low-poly birds that loop slowly overhead —
 * purely decorative ambient life, cheap to render.
 */
function createBirds(scene, count) {
  const birds = [];
  for (let i = 0; i < count; i++) {
    const body = new THREE.Mesh(
      new THREE.ConeGeometry(0.12, 0.5, 4),
      new THREE.MeshStandardMaterial({ color: 0x2a2a2a })
    );
    body.rotation.x = Math.PI / 2;
    scene.add(body);
    birds.push({
      mesh: body,
      centerX: (Math.random() - 0.5) * 150,
      centerZ: (Math.random() - 0.5) * 150,
      radius: 8 + Math.random() * 14,
      height: 14 + Math.random() * 10,
      speed: 0.25 + Math.random() * 0.2,
      phase: Math.random() * Math.PI * 2
    });
  }
  return birds;
}

function updateBirds(birds, elapsed) {
  birds.forEach((b) => {
    const angle = elapsed * b.speed + b.phase;
    const x = b.centerX + Math.cos(angle) * b.radius;
    const z = b.centerZ + Math.sin(angle) * b.radius;
    b.mesh.position.set(x, b.height, z);
    b.mesh.rotation.y = -angle + Math.PI / 2;
  });
}
