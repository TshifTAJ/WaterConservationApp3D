/* =========================================================================
   Audio — all sound is procedurally generated via Web Audio API (no
   external audio files, no licensing concerns, fully offline). Spoken
   instructions use the browser's built-in offline TTS (Web Speech API)
   where the OS provides voices.
   ========================================================================= */

const AudioSys = (() => {
  let ctx = null;
  let masterGain = null;
  let musicNodes = null;
  const settings = { volume: 0.6, musicOn: true, voiceOn: true };

  function ensureCtx() {
    if (!ctx) {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      masterGain = ctx.createGain();
      masterGain.gain.value = settings.volume;
      masterGain.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function setVolume(v) {
    settings.volume = v;
    if (masterGain) masterGain.gain.value = v;
  }

  function noiseBurst(duration, filterFreq, gainPeak) {
    const c = ensureCtx();
    const bufferSize = c.sampleRate * duration;
    const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);

    const src = c.createBufferSource();
    src.buffer = buffer;
    const filter = c.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = filterFreq;
    const gain = c.createGain();
    gain.gain.setValueAtTime(gainPeak, c.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration);

    src.connect(filter).connect(gain).connect(masterGain);
    src.start();
  }

  function tone(freq, duration, type, gainPeak, delay) {
    const c = ensureCtx();
    const osc = c.createOscillator();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    const gain = c.createGain();
    const t0 = c.currentTime + (delay || 0);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(gainPeak, t0 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + duration + 0.05);
  }

  function footstep() { noiseBurst(0.09, 300, 0.22); }
  function splash() { noiseBurst(0.35, 1800, 0.35); }
  function pipePlace() { tone(220, 0.12, 'square', 0.15); }
  function pickup() { tone(660, 0.1, 'triangle', 0.2); tone(880, 0.1, 'triangle', 0.15, 0.08); }
  function corrective() { tone(180, 0.25, 'sawtooth', 0.15); }
  function success() {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.28, 'triangle', 0.22, i * 0.11));
  }
  function fail() { tone(200, 0.4, 'sawtooth', 0.18); tone(140, 0.5, 'sawtooth', 0.15, 0.15); }
  function badge() {
    [784, 988, 1318].forEach((f, i) => tone(f, 0.22, 'sine', 0.2, i * 0.09));
  }

  let ambientStarted = false;
  function startAmbient() {
    if (ambientStarted || !settings.musicOn) return;
    ambientStarted = true;
    const c = ensureCtx();
    const gain = c.createGain();
    gain.gain.value = 0.05;
    gain.connect(masterGain);

    const notes = [130.8, 164.8, 196.0, 246.9]; // soft pad chord
    const oscs = notes.map((f) => {
      const o = c.createOscillator();
      o.type = 'sine';
      o.frequency.value = f;
      const lfo = c.createOscillator();
      lfo.frequency.value = 0.05 + Math.random() * 0.05;
      const lfoGain = c.createGain();
      lfoGain.gain.value = 3;
      lfo.connect(lfoGain).connect(o.detune);
      lfo.start();
      o.connect(gain);
      o.start();
      return o;
    });
    musicNodes = { gain, oscs };
  }

  function setMusic(on) {
    settings.musicOn = on;
    if (musicNodes) musicNodes.gain.gain.value = on ? 0.05 : 0;
    if (on) startAmbient();
  }

  /* ------------------------------ Rain loop ------------------------------ */

  let rainNode = null;
  function startRain() {
    if (rainNode) return;
    const c = ensureCtx();
    const bufferSize = c.sampleRate * 2;
    const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * 0.5;

    const src = c.createBufferSource();
    src.buffer = buffer;
    src.loop = true;
    const filter = c.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 3200;
    filter.Q.value = 0.6;
    const gain = c.createGain();
    gain.gain.value = 0.09;

    src.connect(filter).connect(gain).connect(masterGain);
    src.start();
    rainNode = { src, gain };
  }
  function stopRain() {
    if (!rainNode) return;
    try { rainNode.src.stop(); } catch (e) { /* already stopped */ }
    rainNode = null;
  }

  /* --------------------------- Text-to-speech --------------------------- */

  const npcVoiceProfiles = {
    npc1: { pitch: 0.75, rate: 0.95 }, // Water Warden — lower, measured
    npc2: { pitch: 1.05, rate: 1.05 }, // Pipe-Fitter Pete — brisk
    npc3: { pitch: 1.2, rate: 0.98 }   // Filter Fundi — brighter
  };

  function speak(text, npcKey) {
    if (!settings.voiceOn || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      const profile = npcVoiceProfiles[npcKey] || { pitch: 1, rate: 1 };
      utter.pitch = profile.pitch;
      utter.rate = profile.rate;
      utter.volume = settings.volume;
      window.speechSynthesis.speak(utter);
    } catch (e) { /* TTS not available on this system — silently skip */ }
  }

  function setVoiceEnabled(on) {
    settings.voiceOn = on;
    if (!on && window.speechSynthesis) window.speechSynthesis.cancel();
  }

  return {
    unlock: ensureCtx, setVolume, footstep, splash, pipePlace, pickup,
    corrective, success, fail, badge, startAmbient, setMusic, speak, setVoiceEnabled,
    startRain, stopRain,
    get settings() { return settings; }
  };
})();
