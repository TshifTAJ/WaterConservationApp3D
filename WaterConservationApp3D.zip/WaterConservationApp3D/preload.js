const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  saveProfile: (data) => ipcRenderer.invoke('save-profile', data),
  loadProfile: () => ipcRenderer.invoke('load-profile'),
  saveCertificate: (text) => ipcRenderer.invoke('save-certificate', text)
});
