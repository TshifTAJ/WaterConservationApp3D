const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;

function profilePath() {
  return path.join(app.getPath('userData'), 'player-profile.json');
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1000,
    minHeight: 680,
    title: 'Water Conservation Challenge',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.handle('save-profile', (event, data) => {
  try {
    fs.writeFileSync(profilePath(), JSON.stringify(data, null, 2));
    return true;
  } catch (e) {
    console.error('Failed to save profile:', e);
    return false;
  }
});

ipcMain.handle('load-profile', () => {
  try {
    const raw = fs.readFileSync(profilePath(), 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
});

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function buildCertificateHtml(d) {
  const badgeList = (d.badgeLabels && d.badgeLabels.length)
    ? d.badgeLabels.map((b) => `<span class="badge-chip">${esc(b)}</span>`).join('')
    : '<span class="badge-chip muted">None yet</span>';

  const techniques = (d.techniques || []).map((t) => `<li>${esc(t)}</li>`).join('');

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<style>
  @page { size: A4; margin: 0; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: Georgia, 'Times New Roman', serif;
    background: #f7f3e8;
    color: #23321f;
  }
  .sheet {
    width: 210mm;
    height: 297mm;
    padding: 14mm;
    position: relative;
  }
  .border-outer {
    border: 2px solid #8a6a2a;
    padding: 6mm;
    height: 100%;
  }
  .border-inner {
    border: 1px solid #8a6a2a;
    height: 100%;
    padding: 12mm 16mm;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .kicker {
    letter-spacing: 3px;
    font-size: 11px;
    color: #6a8a5a;
    text-transform: uppercase;
    margin-bottom: 6px;
  }
  h1 {
    font-size: 30px;
    margin: 0 0 4px;
    color: #2c4a26;
    letter-spacing: 1px;
  }
  .subtitle { font-size: 14px; color: #5a6a52; margin-bottom: 18px; }
  .presented-to { font-size: 13px; color: #6a6a5a; margin-top: 10px; }
  .player-name {
    font-family: 'Brush Script MT', 'Segoe Script', cursive, Georgia, serif;
    font-style: italic;
    font-size: 40px;
    color: #1a3a6a;
    margin: 6px 0 14px;
    border-bottom: 1px solid #8a6a2a;
    padding-bottom: 8px;
    min-width: 320px;
  }
  .band-line { font-size: 20px; font-weight: bold; color: #a86a1a; margin-bottom: 4px; }
  .band-sub { font-size: 12px; color: #6a6a5a; margin-bottom: 18px; }
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px 22px;
    width: 100%;
    max-width: 460px;
    margin: 8px 0 18px;
    font-size: 12px;
  }
  .stat-box { text-align: center; }
  .stat-value { font-size: 18px; font-weight: bold; color: #2c4a26; }
  .stat-label { color: #6a6a5a; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; }

  .badges-row { margin-bottom: 16px; }
  .badge-chip {
    display: inline-block;
    background: #eadfba;
    border: 1px solid #a8863a;
    color: #5a4420;
    font-size: 10px;
    padding: 3px 10px;
    border-radius: 12px;
    margin: 2px 3px;
  }
  .badge-chip.muted { background: transparent; border-style: dashed; color: #9a9a8a; }

  .techniques {
    text-align: left;
    max-width: 420px;
    font-size: 11px;
    color: #3a4a35;
    margin-bottom: 18px;
  }
  .techniques h3 {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #6a8a5a;
    margin-bottom: 6px;
    text-align: center;
  }
  .techniques ul { margin: 0; padding-left: 18px; line-height: 1.6; }

  .critique {
    font-size: 11px;
    font-style: italic;
    color: #5a5a4a;
    max-width: 440px;
    line-height: 1.5;
    margin-bottom: 20px;
  }

  .footer {
    margin-top: auto;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    padding-top: 14px;
    border-top: 1px solid #cabf9a;
    font-size: 10px;
    color: #6a6a5a;
  }
  .footer .col { text-align: left; }
  .footer .col.right { text-align: right; }
  .footer .line { font-weight: bold; color: #2c4a26; margin-bottom: 2px; }
</style>
</head>
<body>
  <div class="sheet">
    <div class="border-outer">
      <div class="border-inner">
        <div class="kicker">Water Conservation Challenge</div>
        <h1>Certificate of Achievement</h1>
        <div class="subtitle">NWU Educational Water Conservation Simulation</div>

        <div class="presented-to">This certifies that</div>
        <div class="player-name">${esc(d.name || 'Player')}</div>
        <div class="presented-to">has completed all three challenges at Mastery (Stage 3) level and achieved the rank of</div>
        <div class="band-line">${esc(d.band)}</div>
        <div class="band-sub">${esc(d.pct)}% quiz accuracy</div>

        <div class="stats-grid">
          <div class="stat-box"><div class="stat-value">${esc(d.points)}</div><div class="stat-label">Points</div></div>
          <div class="stat-box"><div class="stat-value">${esc(d.badgeCount)}</div><div class="stat-label">Badges</div></div>
          <div class="stat-box"><div class="stat-value">${esc(d.pct)}%</div><div class="stat-label">Quiz Accuracy</div></div>
          <div class="stat-box"><div class="stat-value">~${esc(d.impact)}L</div><div class="stat-label">Water Impact</div></div>
          <div class="stat-box"><div class="stat-value">~${esc(d.minutes)} min</div><div class="stat-label">Time Played</div></div>
          <div class="stat-box"><div class="stat-value">${esc(d.facts)}</div><div class="stat-label">Facts Discovered</div></div>
        </div>

        <div class="badges-row">${badgeList}</div>

        <div class="techniques">
          <h3>Real-World Techniques Mastered</h3>
          <ul>${techniques}</ul>
        </div>

        <div class="critique">"${esc(d.critique)}"</div>

        <div class="footer">
          <div class="col">
            <div class="line">Tshifhiwa AJ Tshitaka (28457315)</div>
            <div>Project Manager &amp; Lead Developer — NWU Project</div>
          </div>
          <div class="col right">
            <div class="line">${esc(d.date)}</div>
            <div>Client: Dr Dumani Kunjuzwa</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>`;
}

ipcMain.handle('save-certificate', async (event, data) => {
  let pdfWin = null;
  try {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'Save Certificate',
      defaultPath: `WaterConservation_Certificate_${(data.name || 'Player').replace(/[^a-z0-9]/gi, '_')}.pdf`,
      filters: [{ name: 'PDF Document', extensions: ['pdf'] }]
    });
    if (result.canceled || !result.filePath) return false;

    pdfWin = new BrowserWindow({ show: false });
    const html = buildCertificateHtml(data);
    await pdfWin.loadURL('data:text/html;charset=UTF-8,' + encodeURIComponent(html));

    const pdfBuffer = await pdfWin.webContents.printToPDF({
      printBackground: true,
      pageSize: 'A4',
      margins: { marginType: 'none' }
    });

    fs.writeFileSync(result.filePath, pdfBuffer);
    return true;
  } catch (e) {
    console.error('Failed to save certificate:', e);
    return false;
  } finally {
    if (pdfWin) pdfWin.close();
  }
});

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
